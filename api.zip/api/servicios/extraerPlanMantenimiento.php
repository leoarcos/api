<?php

include_once '../DTO/consultasGes_DTO.php';

//print_r($_POST['datos']);

$inst=new consultasGes_DTO();

$dataOut = $inst->ExtraerPlanMantenimiento($_POST['datos']);



echo json_encode($dataOut);

?>