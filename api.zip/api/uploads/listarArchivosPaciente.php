<?php


require_once("../db/Database.php");

$inst=new Database();
$sql="SELECT * FROM `filesupload` WHERE id_paciente=".intval($_POST['id_paciente'])." ORDER BY fecha_subida DESC";
$data=$inst->get_data($sql);
echo JSON_encode($data);

 
?>