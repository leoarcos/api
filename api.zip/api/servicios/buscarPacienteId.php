<?php
include_once '../DTO/pacientes_DTO.php';


$inst = new pacientes_DTO();
$dataOut= $inst->buscarPacienteID($_POST['id']);

echo json_encode($dataOut);
?>