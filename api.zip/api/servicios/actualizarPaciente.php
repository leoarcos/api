<?php
include_once '../DTO/pacientes_DTO.php';

$inst=new pacientes_DTO();
$dataOut = $inst->actualizarPaciente($_POST['datos']);

echo json_encode($dataOut);
?>