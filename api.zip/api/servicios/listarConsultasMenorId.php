<?php

include_once '../DTO/consultasM_DTO.php';





$inst = new consultasM_DTO();

$dataOut= $inst->listarConsultasId($_POST['id']);




echo json_encode($dataOut);

?>