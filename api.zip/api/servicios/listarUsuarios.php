<?php

include_once '../DTO/usuarios_DTO.php';

 


$inst = new usuarios_DTO();

$dataOut= $inst->listarUsuarios($_POST['institucion']);



echo json_encode($dataOut);

?>