<?php

include '../db/Database.php';

class pacientes_DAO {

    function __construct() {
        
    }

  

    public function listarPacientes( ){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql = "SELECT DISTINCT `idJSON`, `tipoidRegPac`, `idRegPac`, `otroDocumRep`, `nombres`, `papellido`, `sapellido`, `estCivil`, `sexo`, `fecNac`, `paisProcedencia`, `dptoProcedencia`, `mnpoProcedencia`, `paisResidencia`, `dptoResidencia`, `mnpoResidencia`, `direccionResidencia`, `zonaResidencia`, `telefono`, `status_migratorio`, `perfilPacie`, `movilidadPacie`, `tipoMoviliPAc`, `BDUA`, `eapb`, `tipoPoblacion`, `regimen`, `perEtnica`, `pueIndigena`, `fecha_registro`, `usuario_regitraid`, `usuario_regitratipoid`, `correoElec`, `OtraDireccion`, `acepta`, `tiemrpoingresoColo`, `remitidoP`, `remitidoPDesc`, `usuario_registrainst`, `hora_registro`, `estado` FROM `pacientes`";
        $result = array();
        $res = $instance->get_data($sql);
        if ($res['STATUS']=="OK" ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
        }
        return $result;
        

    }
    
    public function buscarPaciente($cc, $id){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql = "SELECT * FROM pacientes WHERE tipoidRegPac='".$cc."' AND idRegPac='".$id."'";
        $result = array();
        $res = $instance->get_data($sql);
        if ($res['STATUS']=="OK" ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
        }
        return $result;
        

    }
    public function buscarPacienteID($id){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql = "SELECT * FROM pacientes WHERE id=".intVal($id);
        $result = array();
        $res = $instance->get_data($sql);
        if ($res['STATUS']=="OK" ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
        }
        return $result;
        

    }
    
    public function registrarPaciente($data){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }

        
        if(isset($data['paisProcedencia'])){
            $data['paisProcedencia']=$data['paisProcedencia'];
        }else{

            $data['paisProcedencia']='';
        }

        if(isset($data['dptoProcedencia'])){
            $data['dptoProcedencia']=$data['dptoProcedencia'];
        }else{

            $data['dptoProcedencia']='';
        }

        if(isset($data['mnpoProcedencia'])){
            $data['mnpoProcedencia']=$data['mnpoProcedencia'];
        }else{

            $data['mnpoProcedencia']='';
        }

        if(isset($data['paisResidencia'])){
            $data['paisResidencia']=$data['paisResidencia'];
        }else{

            $data['paisResidencia']='';
        }

        if(isset($data['dptoResidencia'])){
            $data['dptoResidencia']=$data['dptoResidencia'];
        }else{

            $data['dptoResidencia']='';
        }

        if(isset($data['mnpoResidencia'])){
            $data['mnpoResidencia']=$data['mnpoResidencia'];
        }else{

            $data['mnpoResidencia']='';
        }

        if(isset($data['direccionResidencia'])){
            $data['direccionResidencia']=$data['direccionResidencia'];
        }else{

            $data['direccionResidencia']='';
        }

        if(isset($data['zonaResidencia'])){
            $data['zonaResidencia']=$data['zonaResidencia'];
        }else{

            $data['zonaResidencia']='';
        }

        if(isset($data['telefono'])){
            $data['telefono']=$data['telefono'];
        }else{

            $data['telefono']='';
        }

        if(isset($data['status_migratorio'])){
            $data['status_migratorio']=$data['status_migratorio'];
        }else{

            $data['status_migratorio']='';
        }
        if(isset($data['perfilPacie'])){
            $data['perfilPacie']=$data['perfilPacie'];
        }else{

            $data['perfilPacie']='';
        }
        if(isset($data['movilidadPacie'])){
            $data['movilidadPacie']=$data['movilidadPacie'];
        }else{

            $data['movilidadPacie']='';
        }
        if(isset($data['tipoMoviliPAc'])){
            $data['tipoMoviliPAc']=$data['tipoMoviliPAc'];
        }else{

            $data['tipoMoviliPAc']='';
        }
        if(isset($data['BDUA'])){
            $data['BDUA']=$data['BDUA'];
        }else{

            $data['BDUA']='';
        }
        if(isset($data['eapb'])){
            $data['eapb']=$data['eapb'];
        }else{

            $data['eapb']='';
        }
        if(isset($data['tipoPoblacion'])){
            $data['tipoPoblacion']=$data['tipoPoblacion'];
        }else{

            $data['tipoPoblacion']='';
        }
        if(isset($data['regimen'])){
            $data['regimen']=$data['regimen'];
        }else{

            $data['regimen']='';
        }
        if(isset($data['perEtnica'])){
            $data['perEtnica']=$data['perEtnica'];
        }else{

            $data['perEtnica']='';
        }
        if(isset($data['pueIndigena'])){
            $data['pueIndigena']=$data['pueIndigena'];
        }else{

            $data['pueIndigena']='';
        }
        if(isset($data['correoElec'])){
            $data['correoElec']=$data['correoElec'];
        }else{

            $data['correoElec']='';
        }
        if(isset($data['OtraDireccion'])){
            $data['OtraDireccion']=$data['OtraDireccion'];
        }else{

            $data['OtraDireccion']='';
        }
        if(isset($data['aceptaTerminos'])){
            $data['aceptaTerminos']=$data['aceptaTerminos'];
        }else{

            $data['aceptaTerminos']='';
        }
        if(isset($data['tiemrpoingresoColo'])){
            $data['tiemrpoingresoColo']=$data['tiemrpoingresoColo'];
        }else{

            $data['tiemrpoingresoColo']='';
        }
        if(isset($data['remitidoP'])){
            $data['remitidoP']=$data['remitidoP'];
        }else{

            $data['remitidoP']='';
        }
        if(isset($data['remitidoPDesc'])){
            $data['remitidoPDesc']=$data['remitidoPDesc'];
        }else{

            $data['remitidoPDesc']='';
        }
        if(isset($data['fecNac'])){
            $data['fecNac']=$data['fecNac'];
        }else{

            $data['fecNac']='';
        }
        if(isset($data['sexo'])){
            $data['sexo']=$data['sexo'];
        }else{

            $data['sexo']='';
        } 


        $sql="INSERT INTO `pacientes`(`idJSON`, `tipoidRegPac`, `idRegPac`, `otroDocumRep`, `nombres`, `papellido`, `sapellido`, `estCivil`, `sexo`, `fecNac`, `paisProcedencia`, `dptoProcedencia`, `mnpoProcedencia`, `paisResidencia`, `dptoResidencia`, `mnpoResidencia`, `direccionResidencia`, `zonaResidencia`, `telefono`, `status_migratorio`, `perfilPacie`, `movilidadPacie`, `tipoMoviliPAc`, `BDUA`, `eapb`, `tipoPoblacion`, `regimen`, `perEtnica`, `pueIndigena`, `fecha_registro`, `usuario_regitraid`, `usuario_regitratipoid`,  `correoElec`, `OtraDireccion`, `acepta`, `tiemrpoingresoColo`, `remitidoP`, `remitidoPDesc`, `usuario_registrainst`) VALUES ('".$data['idJSON']."', '".$data['tipoidRegPac']."', '".$data['idRegPac']."', '".$data['otroDocumRep']."', '".$data['nombres']."', '".$data['papellido']."', '".$data['sapellido']."', '".$data['estCivil']."', '".$data['sexo']."', '".$data['fecNac']."', '".$data['paisProcedencia']."', '".$data['dptoProcedencia']."', '".$data['mnpoProcedencia']."', '".$data['paisResidencia']."', '".$data['dptoResidencia']."', '".$data['mnpoResidencia']."', '".$data['direccionResidencia']."', '".$data['zonaResidencia']."', '".$data['telefono']."', '".$data['status_migratorio']."','".$data['perfilPacie']."','".$data['movilidadPacie']."','".$data['tipoMoviliPAc']."','".$data['BDUA']."','".$data['eapb']."','".$data['tipoPoblacion']."','".$data['regimen']."', '".$data['perEtnica']."', '".$data['pueIndigena']."', '".$data['fecha_registro']."',  '".$data['usuario_regitraid']."', '".$data['usuario_regitratipoid']."', '".$data['correoElec']."', '".$data['OtraDireccion']."', '".$data['aceptaTerminos']."', '".$data['tiemrpoingresoColo']."', '".$data['remitidoP']."', '".$data['remitidoPDesc']."', '".$data['usuario_registrainst']."')"; 
        $result = array();
        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];
            $result['DATA']=$data;
            /*
            if($data['aceptaTerminos']==true){
                $to = $data['correoElec'];
                $subject = "AUTORIZACION DE DATOS";
                $message = "Haz aceptado la politica de uso de datos .
                Con el registro de sus datos personales en este aplicativo, usted está manifestando su consentimiento libre, expreso e informado, en los términos de la ley de protección de datos personales (Ley 1581 de 2012) y su decretos reglamentarios, para que ".$data['usuario_registrainst']." almacene, administre y utilice los datos que tiene como finalidad, enviarle información relacionada con citas, actividades relacionadas con su salud o cualquier otra información relacionada con temas de nuestra institución.
    
                Si usted no esta de acuerdo con el contenido de este aviso legal, le solicitamos abstenerse de registrar sus datos personales y comunicarse directamente para solicitar información.";
                
                mail($to, $subject, $message);

            }
            */
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    }
    
    public function actualizarPaciente($data){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        } 
        $sql="UPDATE `pacientes` SET `tipoidRegPac`='".$data['tipoidRegPac']."', `idRegPac`='".$data['idRegPac']."',`nombres`='".$data['nombres']."',`papellido`='".$data['papellido']."', `sapellido`='".$data['sapellido']."',`estCivil`='".$data['estCivil']."',`sexo`='".$data['sexo']."',
        `fecNac`='".$data['fecNac']."',`paisProcedencia`='".$data['paisProcedencia']."',
        `dptoProcedencia`='".$data['dptoProcedencia']."',`mnpoProcedencia`='".$data['mnpoProcedencia']."',
        `paisResidencia`='".$data['paisResidencia']."',`dptoResidencia`='".$data['dptoResidencia']."',
        `mnpoResidencia`='".$data['mnpoResidencia']."', `direccionResidencia`='".$data['direccionResidencia']."', `zonaResidencia`='".$data['zonaResidencia']."',`eapb`='".$data['eapb']."',
        `status_migratorio`='".$data['status_migratorio']."',`regimen`='".$data['regimen']."',
        `telefono`='".$data['telefono']."',`perEtnica`='".$data['perEtnica']."',
        `pueIndigena`='".$data['pueIndigena']."'
        WHERE `id`=".$data['id']." AND `idJSON`='".$data['idJSON']."'";
         
        $result = array();
        $res = $instance->exec($sql);
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    }
    
    public function registrarSeguimientoPaciente($data){
        
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql="INSERT INTO `seguimientos`(`tipoid_pac`, `numid_pac`, `nota_seguimiento`, `inst`, `numid_registra`, `nombre_registra`) VALUES ('".$data['tipoid_pac']."', '".$data['numid_pac']."', '".$data['nota_seguimiento']."', '".$data['inst']."', '".$data['numid_registra']."', '".$data['nombre_registra']."')"; 
         
        $result = array();
        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];
            $result['DATA']=$data;
           
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
         
        

    }
    
    
    public function listarSeguimientoPaciente($data){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql = "SELECT * FROM seguimientos WHERE tipoid_pac='".$data['tipoid_pac']."' AND numid_pac='".$data['numid_pac']."'";
        $result = array();
        $res = $instance->get_data($sql);
        if ($res['STATUS']=="OK" ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
        }
        return $result;
        

    }
    
    public function listarSeguimientos($data){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql = "SELECT * FROM seguimientos WHERE inst='".$data."'";
        $result = array();
        $res = $instance->get_data($sql);
        if ($res['STATUS']=="OK" ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
        }
        return $result;
        

    }
   
   
}
