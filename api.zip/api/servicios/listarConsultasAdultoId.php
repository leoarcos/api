<?php

include_once '../DTO/consultasG_DTO.php';





$inst = new consultasG_DTO();

$dataOut= $inst->listarConsultasId($_POST['id']);



echo json_encode($dataOut);

?>