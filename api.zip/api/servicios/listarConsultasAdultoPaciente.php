<?php

include_once '../DTO/consultasG_DTO.php';





$inst = new consultasG_DTO();

$dataOut= $inst->listarConsultasPaciente($_POST['tipoid'], $_POST['numid']);



echo json_encode($dataOut);

?>