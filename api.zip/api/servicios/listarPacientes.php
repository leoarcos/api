<?php

include_once '../DTO/pacientes_DTO.php';





$inst = new pacientes_DTO();

$dataOut= $inst->listarPacientes();
  
echo json_encode($dataOut);
?>