<?php

include_once '../DTO/usuarios_DTO.php';





$inst = new usuarios_DTO();

$dataOut= $inst->registrarUsuario($_POST['datos']);



echo json_encode($dataOut);

?>