<?php
include_once '../DAO/usuarios_DAO.php';

class usuarios_DTO
{
	
	function __construct()
	{
		# code...
	}
	
	public function listarUsuarios($isnt){
		
		$inst= new usuarios_DAO();
		$dataOut=$inst->listarUsuarios($isnt);
        
		return $dataOut;
    } 
	public function listarUsuario($data){
		
		$inst= new usuarios_DAO();
		$dataOut=$inst->listarUsuario($data);
        
		return $dataOut;
    } 
    public function registrarUsuario($data){
        
		$inst= new usuarios_DAO();
		$dataOut=$inst->registrarUsuario($data);
        
		return $dataOut;
    }   
}
//new app_DTO()->listarMunicipios();


