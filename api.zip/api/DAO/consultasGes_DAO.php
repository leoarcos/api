<?php



include '../db/Database.php';



class consultasGes_DAO {



    function __construct() {

        

    }


    public function listarConsultasId($id){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT gr.* , pc.* FROM consultas_prenatales gr, pacientes pc WHERE (pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac) AND id_consulta=".intVal($id)."";
        //$sql = "SELECT * FROM consultasEnfermeria";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }


    public function registerPregnantConsultation($data){
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

 
        if(isset($data['ObserVExFisico'])){
            $data['ObserVExFisico']=$data['ObserVExFisico'];
        }else{
            $data['ObserVExFisico']='';
        }
        
        
        if(isset($data['GestanteAntMovilidadDientes'])){
            $data['GestanteAntMovilidadDientes']=$data['GestanteAntMovilidadDientes'];
        }else{
            $data['GestanteAntMovilidadDientes']='';
        }
        
        if(isset($data['causaCesareasAnt'])){
            $data['causaCesareasAnt']=$data['causaCesareasAnt'];
        }else{
            $data['causaCesareasAnt']='';
        }
        
        if(isset($data['GestanteAntTranstornosMentales'])){
            $data['GestanteAntTranstornosMentales']=$data['GestanteAntTranstornosMentales'];
        }else{
            $data['GestanteAntTranstornosMentales']='';
        }
        
       $sql="INSERT INTO `consultas_prenatales`(`idJSON_consulta`, `numid_pac`, `tipoid_pac`, `id_registra`, `tipoid_registra`, `insitucion`, `fechaConsulta`, `horaConsulta`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `embraActuaPlanea`, `embraActuaDesead`, `deseaInterrumEmbara`, `GestanteAntDiabetes`, `GestanteAntHipertensionArterial`, `GestanteAntCirugiaPelvica`, `GestanteAntOtrasCirugias`, `GestanteAntPreeclamsia`, `GestanteAntEclamsia`, `GestanteAntFactorRH`, `GestanteAntTransfusiones`, `GestanteAntAltTiroideas`, `GestanteAntNutiPrevDefic`, `GestanteAntEnfRenalCronica`, `GestanteAntTtoInfertilidad`, `GestanteAntDifLactancia`, `GestanteAntAlergias`, `GestanteAntAlergiassCuales`, `GestanteAntTraumaticos`, `GestanteAntOtrasTBC`, `GestanteAntPsicofarm`, `GestanteAntOtrasCigarrilloAlcohol`, `GestanteAnIrradiacion`, `GestanteVIHSIDA`, `GestanteAntExpoToxicos`, `GestanteAntExpoToxicosCuales`, `GestanteAntMedicamentos`, `GestanteAntMedicamentosCuales`, `GestanteAntUsaCepillo`, `GestanteAntUsaCrema`, `GestanteAntUsaSeda`, `GestanteAntVecesCepilla`, `GestanteAntSangranEncias`, `GestanteAntDolorRuidosATM`, `GestanteAntMovilidadDientes`, `GestanteAntLimitacionAbrirBoca`, `GestanteAntFechaUConsO`, `GestanteAntEdadMenarquia`, `GestanteSexarquia`, `GestanteAntFechaFum`, `GestanteAntConfiableFUM`, `GestanteAntCiclosIrregulares`, `GestanteAntPatronCicloI`, `GestanteAntPatronCicloII`, `GestanteAntFEchaUltParto`, `GestanteAntFechaFPP`, `GestanteAntparejasSexuales`, `GestanteAntVihRprueba`, `GestanteAntTtoInfertilidadG`, `GestanteAntTtoInfertilidadGTipo`, `GestanteAntMetodoPlanifica`, `GestanteAntFechaSusMetodoPlan`, `GestanteAntEmbarazos`, `GestanteAntAbortoHabitu`, `GestanteAntGineG`, `GestanteAntGineP`, `GestanteAntGineC`, `GestanteAntGineA`, `GestanteAntGineE`, `GestanteAntGineV`, `GestanteAntGineM`, `GestanteAntObservaObst`, `GestanteAntLeucorreas`, `GestanteAntLeucorreasDescr`, `GestanteAntETS`, `GestanteAntFechaCITOLOGIAUtl`, `GestanteAntCOLPOSCOPIA`, `GestanteAntPerioINTERGENESICO`, `GestanteAntPerioINTERGENESICOUME`, `GestanteAntRCIU`, `GestanteAntAmenaPartoPrematuro`, `GestanteAntPartoPREMATURO`, `GestanteAntEmbaraMultiple`, `GestanteAntEmbaraMultipleDesc`, `GestanteAntMALFORMACIONES`, `GestanteAntMOLAS`, `GestanteAntPLACPREVIA`, `GestanteAntABRUPTIO`, `GestanteAntRetePlacenta`, `GestanteAntRupturaPreMembra`, `GestanteAntOLIGOHIDRAMNIOS`, `GestanteAntOLIGOAMNIOS`, `GestanteHemorraObst`, `GestanteTransfucciones`, `GestanteAntEmbProlongado`, `GestanteAntGineOtros`, `GestanteAntGineOtrosCuales`, `GestanteAntAmenazaAborto`, `GestanteAntInfeccPostParto`, `GestanteAntMacromsiaFetal`, `GestanteAntMuertePerinatal`, `GestanteAntMuertePerinatalCausa`, `GestanteAntPsicosisPostParto`, `causaCesareasAnt`, `GestanteAntDiabetesfamiliar`, `GestanteAntHtaFamiliar`, `GestanteAntPreeclamsiaFamiliares`, `GestanteAntEclamsiaFamiliares`, `GestanteAntGemelaresFamiliares`, `GestanteAntCardiopatiaFamiliares`, `GestanteAntEnfTROMBOFILIAS`, `GestanteAntTBCFamiliares`, `GestanteAntTranstornosMentales`, `GestanteAntEpilepsia`, `GestanteAntAutoinmune`, `GestanteAntNeoplasias`, `GestanteAntDiscapacidadFamiliares`, `GestanteAntOtrosFamiliares`, `GestanteAntOtrosFamiliaresCuales`, `GestanteAntBiopssicuno`, `GestanteAntBiopssicdos`, `GestanteAntBiopssictres`, `BiopEdad`, `BioPari`, `abprhabinfer`, `retencPlacent`, `pesobebemayor`, `pesobebemenor`, `htaIndEmbara`, `EmbaGemelarCesara`, `mortinatoMuerto`, `TPProlongada`, `OXgineolgica`, `EnferReanlCronic`, `diabetGesta`, `diabetesMellitus`, `EnfermCardiaca`, `EnfermedadInfeccios`, `enfeAutoInmunes`, `anemiaHB10gl`, `hemorragia20ms`, `vaginal2oss`, `Epronlogadoante`, `htaantecdepr`, `anteRpm`, `polidraminiosAntEmbaActual`, `RCIUAntecente`, `embMultipleatne`, `MalaPresenta`, `isoirh`, `GestanteAntBiopssiccuator`, `GestanteAntBiopssiccinco`, `GestanteAntBiopssicseis`, `ControPrenaacieLis`, `GestanteVacu1ra`, `GestanteVacu2ra`, `GestanteVacu1`, `GestanteVacu2`, `GestanteVacu3`, `GestanteAnaRieMa1`, `GestanteAnaRieNi1`, `GestanteAnaRieMa2`, `GestanteAnaRieNi2`, `GestanteAnaRieMa3`, `GestanteAnaRieNi3`, `gestanteEntrPreTem1`, `gestanteEntrPreTem2`, `gestanteEntrPreTem3`, `gestanteEntrPreTem4`, `gestanteEntrPreTem5`, `gestanteEntrPreFec1`, `gestanteEntrPreFec2`, `gestanteEntrPreFec3`, `gestanteEntrPreFec4`, `gestanteEntrPreFec5`, `GestanteFactProct`, `GestanteEstimFetal`, `GestanteLactMater`, `GestanteVincuAfec`, `GestantePreveAutom`, `GestanteConTaba`, `GestanteSignAlar`, `gestanteOtroEduInd`, `GestnteGrupoSa`, `GestanteclasRh`, `examHemogesta`, `echoasgesta`, `GestanteCitolVag`, `GestanteFechaultCito`, `GestanteNormSatis`, `GestanteCamBeni`, `GestanteAnorPlant`, `GestanteColscopPl`, `listadoCIEPa`, `tipoDiagnosPrinc`, `medAsigCons`, `notasEvolucion`, `recomNotas`, `ordenMedCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `IpsServicioReferir`, `IpsProcedeimientoReferir`,`ObserVExFisico`) VALUES ('".$data['idJSON_consulta']."', '".$data['numid_pac']."', '".$data['tipoid_pac']."', '".$data['id_registra']."', '".$data['tipoid_registra']."', '".$data['insitucion']."', '".$data['fechaConsulta']."', '".$data['horaConsulta']."', '".$data['tipoConsulta']."', '".$data['finalidadConsulta']."', '".$data['causaExternaConsulta']."', '".$data['motivoConsulta']."', '".$data['enfermedadActualConsulta']."', '".$data['embraActuaPlanea']."', '".$data['embraActuaDesead']."', '".$data['deseaInterrumEmbara']."', '".$data['GestanteAntDiabetes']."', '".$data['GestanteAntHipertensionArterial']."', '".$data['GestanteAntCirugiaPelvica']."', '".$data['GestanteAntOtrasCirugias']."', '".$data['GestanteAntPreeclamsia']."', '".$data['GestanteAntEclamsia']."', '".$data['GestanteAntFactorRH']."', '".$data['GestanteAntTransfusiones']."', '".$data['GestanteAntAltTiroideas']."', '".$data['GestanteAntNutiPrevDefic']."', '".$data['GestanteAntEnfRenalCronica']."', '".$data['GestanteAntTtoInfertilidad']."', '".$data['GestanteAntDifLactancia']."', '".$data['GestanteAntAlergias']."', '".$data['GestanteAntAlergiassCuales']."', '".$data['GestanteAntTraumaticos']."', '".$data['GestanteAntOtrasTBC']."', '".$data['GestanteAntPsicofarm']."', '".$data['GestanteAntOtrasCigarrilloAlcohol']."', '".$data['GestanteAnIrradiacion']."', '".$data['GestanteVIHSIDA']."', '".$data['GestanteAntExpoToxicos']."', '".$data['GestanteAntExpoToxicosCuales']."', '".$data['GestanteAntMedicamentos']."', '".$data['GestanteAntMedicamentosCuales']."', '".$data['GestanteAntUsaCepillo']."', '".$data['GestanteAntUsaCrema']."', '".$data['GestanteAntUsaSeda']."', '".$data['GestanteAntVecesCepilla']."', '".$data['GestanteAntSangranEncias']."', '".$data['GestanteAntDolorRuidosATM']."', '".$data['GestanteAntMovilidadDientes']."', '".$data['GestanteAntLimitacionAbrirBoca']."', '".$data['GestanteAntFechaUConsO']."', '".$data['GestanteAntEdadMenarquia']."', '".$data['GestanteSexarquia']."', '".$data['GestanteAntFechaFum']."', '".$data['GestanteAntConfiableFUM']."', '".$data['GestanteAntCiclosIrregulares']."', '".$data['GestanteAntPatronCicloI']."', '".$data['GestanteAntPatronCicloII']."', '".$data['GestanteAntFEchaUltParto']."', '".$data['GestanteAntFechaFPP']."', '".$data['GestanteAntparejasSexuales']."', '".$data['GestanteAntVihRprueba']."', '".$data['GestanteAntTtoInfertilidadG']."', '".$data['GestanteAntTtoInfertilidadGTipo']."', '".$data['GestanteAntMetodoPlanifica']."', '".$data['GestanteAntFechaSusMetodoPlan']."', '".$data['GestanteAntEmbarazos']."', '".$data['GestanteAntAbortoHabitu']."', '".$data['GestanteAntGineG']."', '".$data['GestanteAntGineP']."', '".$data['GestanteAntGineC']."', '".$data['GestanteAntGineA']."', '".$data['GestanteAntGineE']."', '".$data['GestanteAntGineV']."', '".$data['GestanteAntGineM']."', '".$data['GestanteAntObservaObst']."', '".$data['GestanteAntLeucorreas']."', '".$data['GestanteAntLeucorreasDescr']."', '".$data['GestanteAntETS']."', '".$data['GestanteAntFechaCITOLOGIAUtl']."', '".$data['GestanteAntCOLPOSCOPIA']."', '".$data['GestanteAntPerioINTERGENESICO']."', '".$data['GestanteAntPerioINTERGENESICOUME']."', '".$data['GestanteAntRCIU']."', '".$data['GestanteAntAmenaPartoPrematuro']."', '".$data['GestanteAntPartoPREMATURO']."', '".$data['GestanteAntEmbaraMultiple']."', '".$data['GestanteAntEmbaraMultipleDesc']."', '".$data['GestanteAntMALFORMACIONES']."', '".$data['GestanteAntMOLAS']."', '".$data['GestanteAntPLACPREVIA']."', '".$data['GestanteAntABRUPTIO']."', '".$data['GestanteAntRetePlacenta']."', '".$data['GestanteAntRupturaPreMembra']."', '".$data['GestanteAntOLIGOHIDRAMNIOS']."', '".$data['GestanteAntOLIGOAMNIOS']."', '".$data['GestanteHemorraObst']."', '".$data['GestanteTransfucciones']."', '".$data['GestanteAntEmbProlongado']."', '".$data['GestanteAntGineOtros']."', '".$data['GestanteAntGineOtrosCuales']."', '".$data['GestanteAntAmenazaAborto']."', '".$data['GestanteAntInfeccPostParto']."', '".$data['GestanteAntMacromsiaFetal']."', '".$data['GestanteAntMuertePerinatal']."', '".$data['GestanteAntMuertePerinatalCausa']."', '".$data['GestanteAntPsicosisPostParto']."', '".$data['causaCesareasAnt']."', '".$data['GestanteAntDiabetesfamiliar']."', '".$data['GestanteAntHtaFamiliar']."', '".$data['GestanteAntPreeclamsiaFamiliares']."', '".$data['GestanteAntEclamsiaFamiliares']."', '".$data['GestanteAntGemelaresFamiliares']."', '".$data['GestanteAntCardiopatiaFamiliares']."', '".$data['GestanteAntEnfTROMBOFILIAS']."', '".$data['GestanteAntTBCFamiliares']."', '".$data['GestanteAntTranstornosMentales']."', '".$data['GestanteAntEpilepsia']."', '".$data['GestanteAntAutoinmune']."', '".$data['GestanteAntNeoplasias']."', '".$data['GestanteAntDiscapacidadFamiliares']."', '".$data['GestanteAntOtrosFamiliares']."', '".$data['GestanteAntOtrosFamiliaresCuales']."', '".$data['GestanteAntBiopssicuno']."', '".$data['GestanteAntBiopssicdos']."', '".$data['GestanteAntBiopssictres']."', '".$data['BiopEdad']."', '".$data['BioPari']."', '".$data['abprhabinfer']."', '".$data['retencPlacent']."', '".$data['pesobebemayor']."', '".$data['pesobebemenor']."', '".$data['htaIndEmbara']."', '".$data['EmbaGemelarCesara']."', '".$data['mortinatoMuerto']."', '".$data['TPProlongada']."', '".$data['OXgineolgica']."', '".$data['EnferReanlCronic']."', '".$data['diabetGesta']."', '".$data['diabetesMellitus']."', '".$data['EnfermCardiaca']."', '".$data['EnfermedadInfeccios']."', '".$data['enfeAutoInmunes']."', '".$data['anemiaHB10gl']."', '".$data['hemorragia20ms']."', '".$data['vaginal2oss']."', '".$data['Epronlogadoante']."', '".$data['htaantecdepr']."', '".$data['anteRpm']."', '".$data['polidraminiosAntEmbaActual']."', '".$data['RCIUAntecente']."', '".$data['embMultipleatne']."', '".$data['MalaPresenta']."', '".$data['isoirh']."', '".$data['GestanteAntBiopssiccuator']."', '".$data['GestanteAntBiopssiccinco']."', '".$data['GestanteAntBiopssicseis']."', '".$data['ControPrenaacieLis']."', '".$data['GestanteVacu1ra']."', '".$data['GestanteVacu2ra']."', '".$data['GestanteVacu1']."', '".$data['GestanteVacu2']."', '".$data['GestanteVacu3']."', '".$data['GestanteAnaRieMa1']."', '".$data['GestanteAnaRieNi1']."', '".$data['GestanteAnaRieMa2']."', '".$data['GestanteAnaRieNi2']."', '".$data['GestanteAnaRieMa3']."', '".$data['GestanteAnaRieNi3']."', '".$data['gestanteEntrPreTem1']."', '".$data['gestanteEntrPreTem2']."', '".$data['gestanteEntrPreTem3']."', '".$data['gestanteEntrPreTem4']."', '".$data['gestanteEntrPreTem5']."', '".$data['gestanteEntrPreFec1']."', '".$data['gestanteEntrPreFec2']."', '".$data['gestanteEntrPreFec3']."', '".$data['gestanteEntrPreFec4']."', '".$data['gestanteEntrPreFec5']."', '".$data['GestanteFactProct']."', '".$data['GestanteEstimFetal']."', '".$data['GestanteLactMater']."', '".$data['GestanteVincuAfec']."', '".$data['GestantePreveAutom']."', '".$data['GestanteConTaba']."', '".$data['GestanteSignAlar']."', '".$data['gestanteOtroEduInd']."', '".$data['GestnteGrupoSa']."', '".$data['GestanteclasRh']."', '".$data['examHemogesta']."', '".$data['echoasgesta']."', '".$data['GestanteCitolVag']."', '".$data['GestanteFechaultCito']."', '".$data['GestanteNormSatis']."', '".$data['GestanteCamBeni']."', '".$data['GestanteAnorPlant']."', '".$data['GestanteColscopPl']."', '".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."', '".$data['medAsigCons']."', '".$data['notasEvolucion']."', '".$data['recomNotas']."', '".$data['ordenMedCons']."', '".$data['ordenMedConsRef']."', '".$data['ordenMedConsRefPro']."', '".$data['tipoSerRef']."', '".$data['obseSerRef']."', '".$data['IpsServicioReferir']."', '".$data['IpsProcedeimientoReferir']."', '".$data['ObserVExFisico']."')";
        
        $result = array();

        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {

            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';
            $result['SQL']=$sql;

        }

        return $result;
       
    
    }


    public function registrarGestacion($data){
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

 
        
        $sql="INSERT INTO `controles_gestantes`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `id_registra`, `tipoid_registra`, `fecha_Inicio`,`hora_Consulta`,`abierto`, `institucion`) VALUES 
        ('".$data['idJSON_consulta']."', '".$data['id_paciente']."', '".$data['idJSON_paciente']."', '".$data['numid_pac']."','".$data['tipoid_pac']."','".$data['id_registra']."','".$data['tipoid_registra']."','".$data['fecha_Inicio']."','".$data['hora_Consulta']."', '".$data['abierto']."','".$data['institucion']."')";
        
        $result = array();

        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {

            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';
            $result['SQL']=$sql;

        }

        return $result;
       
    
    }


    
    public function registrarConsultaA($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }


        $sql="INSERT INTO pregnant_consultation(`idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`,`tipoid_pac`,`numid_pac`,`num`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `embraActuaPlanea`, `embraActuaDesead`, `deseaInterrumEmbara`) VALUES (".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['tipoid_pac']."','".$data['numid_pac']."','".$data['num']."','".$data['id_registra']."','".$data['tipoid_registra']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['tipoConsulta']."','".$data['finalidadConsulta']."','".$data['causaExternaConsulta']."','".$data['motivoConsulta']."','".$data['enfermedadActualConsulta']."','".$data['embraActuaPlanea']."','".$data['embraActuaDesead']."','".$data['deseaInterrumEmbara']."')";
        //$sql="INSERT INTO consultas_gestanteA(`idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`,`num`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `embraActuaPlanea`, `embraActuaDesead`, `deseaInterrumEmbara`) VALUES (".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['num']."','".$data['id_registra']."','".$data['tipoid_registra']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['tipoConsulta']."','".$data['finalidadConsulta']."','".$data['causaExternaConsulta']."','".$data['motivoConsulta']."','".$data['enfermedadActualConsulta']."','".$data['embraActuaPlanea']."','".$data['embraActuaDesead']."','".$data['deseaInterrumEmbara']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaB($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE pregnant_consultation SET data1='".$data['data']."' WHERE id_consulta=".intVal($data['iddb']);
        //$sql="INSERT INTO consultas_gestanteB(`idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`,   `GestanteAntDiabetes`, `GestanteAntHipertensionArterial`, `GestanteAntCirugiaPelvica`, `GestanteAntOtrasCirugias`, `GestanteAntPreeclamsia`, `GestanteAntEclamsia`, `GestanteAntFactorRH`, `GestanteAntTransfusiones`, `GestanteAntAltTiroideas`, `GestanteAntNutiPrevDefic`, `GestanteAntEnfRenalCronica`, `GestanteAntTtoInfertilidad`, `GestanteAntDifLactancia`, `GestanteAntAlergias`, `GestanteAntTraumaticos`, `GestanteAntOtrasTBC`, `GestanteAntPsicofarm`, `GestanteAntOtrasCigarrilloAlcohol`, `GestanteAnIrradiacion`, `GestanteVIHSIDA`, `GestanteAntExpoToxicos`, `GestanteAntExpoToxicosCuales`, `GestanteAntMedicamentos`, `GestanteAntMedicamentosCuales`, `GestanteAntUsaCepillo`, `GestanteAntUsaCrema`, `GestanteAntUsaSeda`, `GestanteAntVecesCepilla`, `GestanteAntOtrosHabitosHigieneOral`, `GestanteAntOtrosHabitosHigieneOralCuales`, `GestanteAntSangranEncias`, `GestanteAntDolorRuidosATM`, `GestanteAntLimitacionAbrirBoca`, `GestanteAntFechaUConsO`, `GestanteAntEdadMenarquia`, `GestanteSexarquia`, `GestanteAntFechaFum`, `GestanteAntConfiableFUM`, `GestanteAntCiclosIrregulares`, `GestanteAntPatronCicloI`, `GestanteAntPatronCicloII`, `GestanteAntFEchaUltParto`, `GestanteAntFechaFPP`, `GestanteAntparejasSexuales`, `GestanteAntVihRprueba`, `GestanteAntTtoInfertilidadG`, `GestanteAntTtoInfertilidadGTipo`, `GestanteAntMetodoPlanifica`, `GestanteAntFechaSusMetodoPlan`, `GestanteAntEmbarazos`, `GestanteAntAbortoHabitu`, `GestanteAntGineG`, `GestanteAntGineP`, `GestanteAntGineC`, `GestanteAntGineA`, `GestanteAntGineE`, `GestanteAntGineV`, `GestanteAntGineM`, `GestanteAntObservaObst`, `GestanteAntLeucorreas`, `GestanteAntLeucorreasDescr`, `GestanteAntETS`, `GestanteAntFechaCITOLOGIAUtl`, `GestanteAntCOLPOSCOPIA`, `GestanteAntPerioINTERGENESICO`, `GestanteAntPerioINTERGENESICOUME`, `GestanteAntRCIU`, `GestanteAntAmenaPartoPrematuro`, `GestanteAntPartoPREMATURO`, `GestanteAntEmbaraMultiple`, `GestanteAntEmbaraMultipleDesc`, `GestanteAntMALFORMACIONES`, `GestanteAntMOLAS`, `GestanteAntPLACPREVIA`, `GestanteAntABRUPTIO`, `GestanteAntRetePlacenta`, `GestanteAntRupturaPreMembra`, `GestanteAntOLIGOHIDRAMNIOS`, `GestanteAntOLIGOAMNIOS`, `GestanteHemorraObst`, `GestanteTransfucciones`, `GestanteAntEmbProlongado`, `GestanteAntGineOtros`, `GestanteAntGineOtrosCuales`, `GestanteAntAmenazaAborto`, `GestanteAntInfeccPostParto`, `GestanteAntMacromsiaFetal`, `GestanteAntMuertePerinatal`, `GestanteAntMuertePerinatalCausa`, `GestanteAntPsicosisPostParto`, `GestanteAntOtrasCausasCesareasCuales`, `GestanteAntDiabetesfamiliar`, `GestanteAntHtaFamiliar`, `GestanteAntPreeclamsiaFamiliares`, `GestanteAntEclamsiaFamiliares`, `GestanteAntGemelaresFamiliares`, `GestanteAntCardiopatiaFamiliares`, `GestanteAntEnfTROMBOFILIAS`, `GestanteAntTBCFamiliares`, `GestanteAntTranstornosMentales`, `GestanteAntEpilepsia`, `GestanteAntAutoinmune`, `GestanteAntNeoplasias`, `GestanteAntDiscapacidadFamiliares`, `GestanteAntOtrosFamiliares`, `GestanteAntOtrosFamiliaresCuales`, `GestanteAntBiopssicuno`, `GestanteAntBiopssicdos`, `GestanteAntBiopssictres`, `BiopEdad`, `BioPari`, `abprhabinfer`, `retencPlacent`, `pesobebemayor`, `pesobebemenor`, `htaIndEmbara`, `EmbaGemelarCesara`, `mortinatoMuerto`, `TPProlongada`, `OXgineolgica`, `EnferReanlCronic`, `diabetGesta`, `diabetesMellitus`, `EnfermCardiaca`, `EnfermedadInfeccios`, `enfeAutoInmunes`, `anemiaHB10gl`, `hemorragia20ms`, `vaginal2oss`, `Epronlogadoante`, `htaantecdepr`, `anteRpm`, `polidraminiosAntEmbaActual`, `RCIUAntecente`, `embMultipleatne`, `MalaPresenta`, `isoirh`, `GestanteAntBiopssiccuator`, `GestanteAntBiopssiccinco`, `GestanteAntBiopssicseis`, `GestanteAntAlergiassCuales`, `num`, `GestanteAntMovilidadDientes`) VALUES (".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['GestanteAntDiabetes']."','".$data['GestanteAntHipertensionArterial']."','".$data['GestanteAntCirugiaPelvica']."','".$data['GestanteAntOtrasCirugias']."','".$data['GestanteAntPreeclamsia']."','".$data['GestanteAntEclamsia']."','".$data['GestanteAntFactorRH']."','".$data['GestanteAntTransfusiones']."','".$data['GestanteAntAltTiroideas']."','".$data['GestanteAntNutiPrevDefic']."','".$data['GestanteAntEnfRenalCronica']."','".$data['GestanteAntTtoInfertilidad']."','".$data['GestanteAntDifLactancia']."','".$data['GestanteAntAlergias']."','".$data['GestanteAntTraumaticos']."','".$data['GestanteAntOtrasTBC']."','".$data['GestanteAntPsicofarm']."','".$data['GestanteAntOtrasCigarrilloAlcohol']."','".$data['GestanteAnIrradiacion']."','".$data['GestanteVIHSIDA']."','".$data['GestanteAntExpoToxicos']."','".$data['GestanteAntExpoToxicosCuales']."','".$data['GestanteAntMedicamentos']."','".$data['GestanteAntMedicamentosCuales']."','".$data['GestanteAntUsaCepillo']."','".$data['GestanteAntUsaCrema']."','".$data['GestanteAntUsaSeda']."','".$data['GestanteAntVecesCepilla']."','".$data['GestanteAntOtrosHabitosHigieneOral']."','".$data['GestanteAntOtrosHabitosHigieneOralCuales']."','".$data['GestanteAntSangranEncias']."','".$data['GestanteAntDolorRuidosATM']."','".$data['GestanteAntLimitacionAbrirBoca']."','".$data['GestanteAntFechaUConsO']."','".$data['GestanteAntEdadMenarquia']."','".$data['GestanteSexarquia']."','".$data['GestanteAntFechaFum']."','".$data['GestanteAntConfiableFUM']."','".$data['GestanteAntCiclosIrregulares']."','".$data['GestanteAntPatronCicloI']."','".$data['GestanteAntPatronCicloII']."','".$data['GestanteAntFEchaUltParto']."','".$data['GestanteAntFechaFPP']."','".$data['GestanteAntparejasSexuales']."','".$data['GestanteAntVihRprueba']."','".$data['GestanteAntTtoInfertilidadG']."','".$data['GestanteAntTtoInfertilidadGTipo']."','".$data['GestanteAntMetodoPlanifica']."','".$data['GestanteAntFechaSusMetodoPlan']."','".$data['GestanteAntEmbarazos']."','".$data['GestanteAntAbortoHabitu']."','".$data['GestanteAntGineG']."','".$data['GestanteAntGineP']."','".$data['GestanteAntGineC']."','".$data['GestanteAntGineA']."','".$data['GestanteAntGineE']."','".$data['GestanteAntGineV']."','".$data['GestanteAntGineM']."','".$data['GestanteAntObservaObst']."','".$data['GestanteAntLeucorreas']."','".$data['GestanteAntLeucorreasDescr']."','".$data['GestanteAntETS']."','".$data['GestanteAntFechaCITOLOGIAUtl']."','".$data['GestanteAntCOLPOSCOPIA']."','".$data['GestanteAntPerioINTERGENESICO']."','".$data['GestanteAntPerioINTERGENESICOUME']."','".$data['GestanteAntRCIU']."','".$data['GestanteAntAmenaPartoPrematuro']."','".$data['GestanteAntPartoPREMATURO']."','".$data['GestanteAntEmbaraMultiple']."','".$data['GestanteAntEmbaraMultipleDesc']."','".$data['GestanteAntMALFORMACIONES']."','".$data['GestanteAntMOLAS']."','".$data['GestanteAntPLACPREVIA']."','".$data['GestanteAntABRUPTIO']."','".$data['GestanteAntRetePlacenta']."','".$data['GestanteAntRupturaPreMembra']."','".$data['GestanteAntOLIGOHIDRAMNIOS']."','".$data['GestanteAntOLIGOAMNIOS']."','".$data['GestanteHemorraObst']."','".$data['GestanteTransfucciones']."','".$data['GestanteAntEmbProlongado']."','".$data['GestanteAntGineOtros']."','".$data['GestanteAntGineOtrosCuales']."','".$data['GestanteAntAmenazaAborto']."','".$data['GestanteAntInfeccPostParto']."','".$data['GestanteAntMacromsiaFetal']."','".$data['GestanteAntMuertePerinatal']."','".$data['GestanteAntMuertePerinatalCausa']."','".$data['GestanteAntPsicosisPostParto']."','".$data['GestanteAntOtrasCausasCesareasCuales']."','".$data['GestanteAntDiabetesfamiliar']."','".$data['GestanteAntHtaFamiliar']."','".$data['GestanteAntPreeclamsiaFamiliares']."','".$data['GestanteAntEclamsiaFamiliares']."','".$data['GestanteAntGemelaresFamiliares']."','".$data['GestanteAntCardiopatiaFamiliares']."','".$data['GestanteAntEnfTROMBOFILIAS']."','".$data['GestanteAntTBCFamiliares']."','".$data['GestanteAntTranstornosMentales']."','".$data['GestanteAntEpilepsia']."','".$data['GestanteAntAutoinmune']."','".$data['GestanteAntNeoplasias']."','".$data['GestanteAntDiscapacidadFamiliares']."','".$data['GestanteAntOtrosFamiliares']."','".$data['GestanteAntOtrosFamiliaresCuales']."','".$data['GestanteAntBiopssicuno']."','".$data['GestanteAntBiopssicdos']."','".$data['GestanteAntBiopssictres']."','".$data['BiopEdad']."','".$data['BioPari']."','".$data['abprhabinfer']."','".$data['retencPlacent']."','".$data['pesobebemayor']."','".$data['pesobebemenor']."','".$data['htaIndEmbara']."','".$data['EmbaGemelarCesara']."','".$data['mortinatoMuerto']."','".$data['TPProlongada']."','".$data['OXgineolgica']."','".$data['EnferReanlCronic']."','".$data['diabetGesta']."','".$data['diabetesMellitus']."','".$data['EnfermCardiaca']."','".$data['EnfermedadInfeccios']."','".$data['enfeAutoInmunes']."','".$data['anemiaHB10gl']."','".$data['hemorragia20ms']."','".$data['vaginal2oss']."','".$data['Epronlogadoante']."','".$data['htaantecdepr']."','".$data['anteRpm']."','".$data['polidraminiosAntEmbaActual']."','".$data['RCIUAntecente']."','".$data['embMultipleatne']."','".$data['MalaPresenta']."','".$data['isoirh']."','".$data['GestanteAntBiopssiccuator']."','".$data['GestanteAntBiopssiccinco']."','".$data['GestanteAntBiopssicseis']."','".$data['GestanteAntAlergiassCuales']."','".$data['num']."','".$data['GestanteAntMovilidadDientes']."')";
              
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaC($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE pregnant_consultation SET data3='".$data['data']."' WHERE id_consulta=".intVal($data['iddb']);
        //$sql="INSERT INTO consultas_gestanteC(`idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`,  `vaControPrenaacieLisr`, `GestanteVacu1ra`, `GestanteVacu2ra`, `GestanteVacu1`, `GestanteVacu2`, `GestanteVacu3`, `GestanteAnaRieMa1`, `GestanteAnaRieNi1`, `GestanteAnaRieMa2`, `GestanteAnaRieNi2`, `GestanteAnaRieMa3`, `GestanteAnaRieNi3`, `gestanteEntrPreTem1`, `gestanteEntrPreTem2`, `gestanteEntrPreTem3`, `gestanteEntrPreTem4`, `gestanteEntrPreTem5`, `gestanteEntrPreFec1`, `gestanteEntrPreFec2`, `gestanteEntrPreFec3`, `gestanteEntrPreFec4`, `gestanteEntrPreFec5`, `num`) VALUES (".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['ControPrenaacieLis']."','".$data['GestanteVacu1ra']."','".$data['GestanteVacu2ra']."','".$data['GestanteVacu1']."','".$data['GestanteVacu2']."','".$data['GestanteVacu3']."','".$data['GestanteAnaRieMa1']."','".$data['GestanteAnaRieNi1']."','".$data['GestanteAnaRieMa2']."','".$data['GestanteAnaRieNi2']."','".$data['GestanteAnaRieMa3']."','".$data['GestanteAnaRieNi3']."','".$data['gestanteEntrPreTem1']."','".$data['gestanteEntrPreTem2']."','".$data['gestanteEntrPreTem3']."','".$data['gestanteEntrPreTem4']."','".$data['gestanteEntrPreTem5']."','".$data['gestanteEntrPreFec1']."','".$data['gestanteEntrPreFec2']."','".$data['gestanteEntrPreFec3']."','".$data['gestanteEntrPreFec4']."','".$data['gestanteEntrPreFec5']."', '".$data['num']."')";
       
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
 

    public function registrarConsultaD($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE pregnant_consultation SET data2='".$data['data']."' WHERE id_consulta=".intVal($data['iddb']);
        //$sql="INSERT INTO consultas_gestanteD(`idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`,  `GestanteFactProct`, `GestanteEstimFetal`, `GestanteLactMater`, `GestanteVincuAfec`, `GestantePreveAutom`, `GestanteConTaba`, `GestanteSignAlar`, `gestanteOtroEduInd`, `num`) VALUES (".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['GestanteFactProct']."','".$data['GestanteEstimFetal']."','".$data['GestanteLactMater']."','".$data['GestanteVincuAfec']."','".$data['GestantePreveAutom']."','".$data['GestanteConTaba']."','".$data['GestanteSignAlar']."','".$data['gestanteOtroEduInd']."','".$data['num']."')";
       
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

    
    public function registrarConsultaE($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }
 

        $sql="UPDATE pregnant_consultation SET data5='".$data['data']."' WHERE id_consulta=".intVal($data['iddb']);
        //$sql="INSERT INTO consultas_gestanteE(`idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`, `num`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `listadoCIEPa`,`tipoDiagnosPrinc`) VALUES (".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['num']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."')";
         
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


    public function registrarConsultaF($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        

        $sql="UPDATE pregnant_consultation SET data6='".$data['data']."' WHERE id_consulta=".intVal($data['iddb']);
        //$sql="INSERT INTO consultas_gestanteF(  `idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`, `num`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `medAsigCons`, `notasEvolucion`, `recomNotas`, `OrdAsigCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `IpsServicioReferir`, `IpsProcedeimientoReferir`) VALUES (".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['num']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['medAsigCons']."','".$data['notasEvolucion']."','".$data['recomNotas']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."','".$data['IpsServicioReferir']."','".$data['IpsProcedeimientoReferir']."')";
         
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


    public function registrarConsultaPlan($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }
 
        $sql="UPDATE pregnant_consultation SET data4='".$data['data']."' WHERE id_consulta=".intVal($data['iddb']);
        //$sql="INSERT INTO `consultas_gestantePlan`(`idJSON_consulta`, `id_gestacion`, `id_gestacionJSON`, `num`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `GestnteGrupoSa`, `GestanteclasRh`,  `GestanteCitolVag`, `GestanteFechaultCito`, `GestanteNormSatis`, `GestanteCamBeni`, `GestanteAnorPlant`, `GestanteColscopPl`,  `examHemogesta`, `echoasgesta`) VALUES 
        //(".$data['idJSON_consulta'].",'".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['num']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['GestnteGrupoSa']."','".$data['GestanteclasRh']."','".$data['GestanteCitolVag']."','".$data['GestanteFechaultCito']."','".$data['GestanteNormSatis']."','".$data['GestanteCamBeni']."','".$data['GestanteAnorPlant']."','".$data['GestanteColscopPl']."', '".$data['examHemogesta']."','".$data['echoasgesta']."')";
          
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


    public function registrarPlanMantenimiento($data){
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

 
        
        $sql="INSERT INTO `plan_mantenimiento`(`id_planJSON`, `id_gestacion`, `id_gestacionJSON`, `GestnteGrupoSa`, `GestanteclasRh`, `GestanteHEMOGRAMA1Fec`, `GestanteHEMOGRAMA1Desc`, `GestanteHEMOGRAMA1`, `GestanteHEMOGRAMA2Fec`, `GestanteHEMOGRAMA2Desc`, `GestanteHEMOGRAMA2`, `GestanteHEMOGRAMA3Fec`, `GestanteHEMOGRAMA3Desc`, `GestanteHEMOGRAMA3`, `GestanteVDRL1Fecha`, `GestanteVDRL1Res`, `GestanteVDRL1`, `GestanteVDRL2Fecha`, `GestanteVDRL2Res`, `GestanteVDRL2`, `GestanteVDRL3Fecha`, `GestanteVDRL3Res`, `GestanteVDRL3`, `GestanteUROANALISIS1Fecha`, `GestanteUROANALISIS1Res`, `GestanteUROANALISIS1`, `GestanteUROANALISIS2Fecha`, `GestanteUROANALISIS2Res`, `GestanteUROANALISIS2`, `GestanteUROANALISIS3Fecha`, `GestanteUROANALISIS3Res`, `GestanteUROANALISIS3`, `GestanteGLICEMIA1Fecha`, `GestanteGLICEMIA1Res`, `GestanteGLICEMIA1`, `GestanteGLICEMIA2Fecha`, `GestanteGLICEMIA2Res`, `GestanteGLICEMIA2`, `GestanteGLICEMIA3Fecha`, `GestanteGLICEMIA3Res`, `GestanteGLICEMIA3`, `GestanteHIV1Fecha`, `GestanteHIV1Res`, `GestanteHIV1`, `GestanteHIV2Fecha`, `gestanteHIV2Res`, `GestanteHIV2`, `GestanteHIV3Fecha`, `GestanteHIV3Res`, `GestanteHIV3`, `GestanteHBSAg1Fecha`, `GestanteHBSAg1Res`, `GestanteHBSAg1`, `GestanteHBSAg2Fecha`, `GestanteHBSAg2Res`, `GestanteHBSAg2`, `GestanteHBSAg3Fecha`, `GestanteHBSAg3Res`, `GestanteHBSAg3`, `GestanteFROTISVAGINAL1Fecha`, `GestanteFROTISVAGINAL1Res`, `GestanteFROTISVAGINAL1`, `GestanteFROTISVAGINAL2Fecha`, `GestanteFROTISVAGINAL2Res`, `GestanteFROTISVAGINAL2`, `GestanteFROTISVAGINAL3Fecha`, `GestanteFROTISVAGINAL3Res`, `GestanteFROTISVAGINAL3`, `GestanteTOXOlgG1Fecha`, `GestanteTOXOlgG1Res`, `GestanteTOXOlgG1`, `GestanteTOXOlgG2Fecha`, `GestanteTOXOlgG2Res`, `GestanteTOXOlgG2`, `GestanteTOXOlgG3Fecha`, `GestanteTOXOlgG3Res`, `GestanteTOXOlgG3`, `GestanteTOXOlgM1Fecha`, `GestanteTOXOlgM1Res`, `GestanteTOXOlgM1`, `GestanteTOXOlgM2Fecha`, `GestanteTOXOlgM2Res`, `GestanteTOXOlgM2`, `GestanteTOXOlgM3Fecha`, `GestanteTOXOlgM3Res`, `GestanteTOXOlgM3`, `GestantePrueto1Fecha`, `GestantePrueto1Res`, `GestantePrueto1`, `GestantePrueto2Fecha`, `GestantePrueto2Res`, `GestantePrueto2`, `GestantePrueto3Fecha`, `GestantePrueto3Res`, `GestantePrueto3`, `coombsIndi1Fecha`, `coombsIndi1Res`, `coombsIndi1`, `coombsIndi2Fecha`, `coombsIndi2Res`, `coombsIndi2`, `coombsIndi3Fecha`, `coombsIndi3Res`, `coombsIndi3`, `GestanteCitolVag`, `GestanteFechaultCito`, `GestanteNormSatis`, `GestanteFechEco1`, `GestanteObsEco1`, `GestanteNormEco1`, `GestanteCamBeni`, `GestanteFechEco2`, `GestanteObsEco2`, `GestanteNormEco2`, `GestanteAnorPlant`, `GestanteFechEco3`, `GestanteObsEco3`, `GestanteNormEco3`, `GestanteColscopPl`, `GestanteFechEco4`, `GestanteObsEco4`, `GestanteNormEco4`, `id_registra`, `tipoid_registra`, `institucion`) VALUES ('".$data['id_planJSON']."','".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['GestnteGrupoSa']."','".$data['GestanteclasRh']."','".$data['GestanteHEMOGRAMA1Fec']."','".$data['GestanteHEMOGRAMA1Desc']."','".$data['GestanteHEMOGRAMA1']."','".$data['GestanteHEMOGRAMA2Fec']."','".$data['GestanteHEMOGRAMA2Desc']."','".$data['GestanteHEMOGRAMA2']."','".$data['GestanteHEMOGRAMA3Fec']."','".$data['GestanteHEMOGRAMA3Desc']."','".$data['GestanteHEMOGRAMA3']."','".$data['GestanteVDRL1Fecha']."','".$data['GestanteVDRL1Res']."','".$data['GestanteVDRL1']."','".$data['GestanteVDRL2Fecha']."','".$data['GestanteVDRL2Res']."','".$data['GestanteVDRL2']."','".$data['GestanteVDRL3Fecha']."','".$data['GestanteVDRL3Res']."','".$data['GestanteVDRL3']."','".$data['GestanteUROANALISIS1Fecha']."','".$data['GestanteUROANALISIS1Res']."','".$data['GestanteUROANALISIS1']."','".$data['GestanteUROANALISIS2Fecha']."','".$data['GestanteUROANALISIS2Res']."','".$data['GestanteUROANALISIS2']."','".$data['GestanteUROANALISIS3Fecha']."','".$data['GestanteUROANALISIS3Res']."','".$data['GestanteUROANALISIS3']."','".$data['GestanteGLICEMIA1Fecha']."','".$data['GestanteGLICEMIA1Res']."','".$data['GestanteGLICEMIA1']."','".$data['GestanteGLICEMIA2Fecha']."','".$data['GestanteGLICEMIA2Res']."','".$data['GestanteGLICEMIA2']."','".$data['GestanteGLICEMIA3Fecha']."','".$data['GestanteGLICEMIA3Res']."','".$data['GestanteGLICEMIA3']."','".$data['GestanteHIV1Fecha']."','".$data['GestanteHIV1Res']."','".$data['GestanteHIV1']."','".$data['GestanteHIV2Fecha']."','".$data['GestanteHIV2Res']."','".$data['GestanteHIV2']."','".$data['GestanteHIV3Fecha']."','".$data['GestanteHIV3Res']."','".$data['GestanteHIV3']."','".$data['GestanteHBSAg1Fecha']."','".$data['GestanteHBSAg1Res']."','".$data['GestanteHBSAg1']."','".$data['GestanteHBSAg2Fecha']."','".$data['GestanteHBSAg2Res']."','".$data['GestanteHBSAg2']."','".$data['GestanteHBSAg3Fecha']."','".$data['GestanteHBSAg3Res']."','".$data['GestanteHBSAg3']."','".$data['GestanteFROTISVAGINAL1Fecha']."','".$data['GestanteFROTISVAGINAL1Res']."','".$data['GestanteFROTISVAGINAL1']."','".$data['GestanteFROTISVAGINAL2Fecha']."','".$data['GestanteFROTISVAGINAL2Res']."','".$data['GestanteFROTISVAGINAL2']."','".$data['GestanteFROTISVAGINAL3Fecha']."','".$data['GestanteFROTISVAGINAL3Res']."','".$data['GestanteFROTISVAGINAL3']."','".$data['GestanteTOXOlgG1Fecha']."','".$data['GestanteTOXOlgG1Res']."','".$data['GestanteTOXOlgG1']."','".$data['GestanteTOXOlgG2Fecha']."','".$data['GestanteTOXOlgG2Res']."','".$data['GestanteTOXOlgG2']."','".$data['GestanteTOXOlgG3Fecha']."','".$data['id_planJSON']."','".$data['GestanteTOXOlgG3']."','".$data['GestanteTOXOlgM1Fecha']."','".$data['GestanteTOXOlgM1Res']."','".$data['GestanteTOXOlgM1']."','".$data['GestanteTOXOlgM2Fecha']."','".$data['GestanteTOXOlgM2Res']."','".$data['GestanteTOXOlgM2']."','".$data['GestanteTOXOlgM3Fecha']."','".$data['GestanteTOXOlgM3Res']."','".$data['GestanteTOXOlgM3']."','".$data['GestantePrueto1Fecha']."','".$data['GestantePrueto1Res']."','".$data['GestantePrueto1']."','".$data['GestantePrueto2Fecha']."','".$data['GestantePrueto2Res']."','".$data['GestantePrueto2']."','".$data['GestantePrueto3Fecha']."','".$data['GestantePrueto3Res']."','".$data['GestantePrueto3']."','".$data['coombsIndi1Fecha']."','".$data['coombsIndi1Res']."','".$data['coombsIndi1']."','".$data['coombsIndi2Fecha']."','".$data['coombsIndi2Res']."','".$data['coombsIndi2']."','".$data['coombsIndi3Fecha']."','".$data['coombsIndi3Res']."','".$data['coombsIndi3']."','".$data['GestanteCitolVag']."','".$data['GestanteFechaultCito']."','".$data['GestanteNormSatis']."','".$data['GestanteFechEco1']."','".$data['GestanteObsEco1']."','".$data['GestanteNormEco1']."','".$data['GestanteCamBeni']."','".$data['GestanteFechEco2']."','".$data['GestanteObsEco2']."','".$data['GestanteNormEco2']."','".$data['GestanteAnorPlant']."','".$data['GestanteFechEco3']."','".$data['GestanteObsEco3']."','".$data['GestanteNormEco3']."','".$data['GestanteColscopPl']."','".$data['GestanteFechEco4']."','".$data['GestanteObsEco4']."','".$data['GestanteNormEco4']."','".$data['id_registra']."','".$data['tipoid_registra']."','".$data['institucion']."')";
        
        $result = array();

        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {

            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';
            $result['SQL']=$sql;

        }

        return $result;

    
    }

    public function actualizarPlanMantenimiento($data){
        $instance = Database::getInstance(); 
        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }


        $sqlDelete='DELETE FROM plan_mantenimiento WHERE `id_plan`='.$data['id_plan'];
        
        $sqlInsert="INSERT INTO `plan_mantenimiento`(`id_plan`,`id_planJSON`, `id_gestacion`, `id_gestacionJSON`, `GestnteGrupoSa`, `GestanteclasRh`, `GestanteHEMOGRAMA1Fec`, `GestanteHEMOGRAMA1Desc`, `GestanteHEMOGRAMA1`, `GestanteHEMOGRAMA2Fec`, `GestanteHEMOGRAMA2Desc`, `GestanteHEMOGRAMA2`, `GestanteHEMOGRAMA3Fec`, `GestanteHEMOGRAMA3Desc`, `GestanteHEMOGRAMA3`, `GestanteVDRL1Fecha`, `GestanteVDRL1Res`, `GestanteVDRL1`, `GestanteVDRL2Fecha`, `GestanteVDRL2Res`, `GestanteVDRL2`, `GestanteVDRL3Fecha`, `GestanteVDRL3Res`, `GestanteVDRL3`, `GestanteUROANALISIS1Fecha`, `GestanteUROANALISIS1Res`, `GestanteUROANALISIS1`, `GestanteUROANALISIS2Fecha`, `GestanteUROANALISIS2Res`, `GestanteUROANALISIS2`, `GestanteUROANALISIS3Fecha`, `GestanteUROANALISIS3Res`, `GestanteUROANALISIS3`, `GestanteGLICEMIA1Fecha`, `GestanteGLICEMIA1Res`, `GestanteGLICEMIA1`, `GestanteGLICEMIA2Fecha`, `GestanteGLICEMIA2Res`, `GestanteGLICEMIA2`, `GestanteGLICEMIA3Fecha`, `GestanteGLICEMIA3Res`, `GestanteGLICEMIA3`, `GestanteHIV1Fecha`, `GestanteHIV1Res`, `GestanteHIV1`, `GestanteHIV2Fecha`, `gestanteHIV2Res`, `GestanteHIV2`, `GestanteHIV3Fecha`, `GestanteHIV3Res`, `GestanteHIV3`, `GestanteHBSAg1Fecha`, `GestanteHBSAg1Res`, `GestanteHBSAg1`, `GestanteHBSAg2Fecha`, `GestanteHBSAg2Res`, `GestanteHBSAg2`, `GestanteHBSAg3Fecha`, `GestanteHBSAg3Res`, `GestanteHBSAg3`, `GestanteFROTISVAGINAL1Fecha`, `GestanteFROTISVAGINAL1Res`, `GestanteFROTISVAGINAL1`, `GestanteFROTISVAGINAL2Fecha`, `GestanteFROTISVAGINAL2Res`, `GestanteFROTISVAGINAL2`, `GestanteFROTISVAGINAL3Fecha`, `GestanteFROTISVAGINAL3Res`, `GestanteFROTISVAGINAL3`, `GestanteTOXOlgG1Fecha`, `GestanteTOXOlgG1Res`, `GestanteTOXOlgG1`, `GestanteTOXOlgG2Fecha`, `GestanteTOXOlgG2Res`, `GestanteTOXOlgG2`, `GestanteTOXOlgG3Fecha`, `GestanteTOXOlgG3Res`, `GestanteTOXOlgG3`, `GestanteTOXOlgM1Fecha`, `GestanteTOXOlgM1Res`, `GestanteTOXOlgM1`, `GestanteTOXOlgM2Fecha`, `GestanteTOXOlgM2Res`, `GestanteTOXOlgM2`, `GestanteTOXOlgM3Fecha`, `GestanteTOXOlgM3Res`, `GestanteTOXOlgM3`, `GestantePrueto1Fecha`, `GestantePrueto1Res`, `GestantePrueto1`, `GestantePrueto2Fecha`, `GestantePrueto2Res`, `GestantePrueto2`, `GestantePrueto3Fecha`, `GestantePrueto3Res`, `GestantePrueto3`, `coombsIndi1Fecha`, `coombsIndi1Res`, `coombsIndi1`, `coombsIndi2Fecha`, `coombsIndi2Res`, `coombsIndi2`, `coombsIndi3Fecha`, `coombsIndi3Res`, `coombsIndi3`, `GestanteCitolVag`, `GestanteFechaultCito`, `GestanteNormSatis`, `GestanteFechEco1`, `GestanteObsEco1`, `GestanteNormEco1`, `GestanteCamBeni`, `GestanteFechEco2`, `GestanteObsEco2`, `GestanteNormEco2`, `GestanteAnorPlant`, `GestanteFechEco3`, `GestanteObsEco3`, `GestanteNormEco3`, `GestanteColscopPl`, `GestanteFechEco4`, `GestanteObsEco4`, `GestanteNormEco4`, `id_registra`, `tipoid_registra`, `institucion`) VALUES (".$data['id_plan'].",'".$data['id_planJSON']."','".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['GestnteGrupoSa']."','".$data['GestanteclasRh']."','".$data['GestanteHEMOGRAMA1Fec']."','".$data['GestanteHEMOGRAMA1Desc']."','".$data['GestanteHEMOGRAMA1']."','".$data['GestanteHEMOGRAMA2Fec']."','".$data['GestanteHEMOGRAMA2Desc']."','".$data['GestanteHEMOGRAMA2']."','".$data['GestanteHEMOGRAMA3Fec']."','".$data['GestanteHEMOGRAMA3Desc']."','".$data['GestanteHEMOGRAMA3']."','".$data['GestanteVDRL1Fecha']."','".$data['GestanteVDRL1Res']."','".$data['GestanteVDRL1']."','".$data['GestanteVDRL2Fecha']."','".$data['GestanteVDRL2Res']."','".$data['GestanteVDRL2']."','".$data['GestanteVDRL3Fecha']."','".$data['GestanteVDRL3Res']."','".$data['GestanteVDRL3']."','".$data['GestanteUROANALISIS1Fecha']."','".$data['GestanteUROANALISIS1Res']."','".$data['GestanteUROANALISIS1']."','".$data['GestanteUROANALISIS2Fecha']."','".$data['GestanteUROANALISIS2Res']."','".$data['GestanteUROANALISIS2']."','".$data['GestanteUROANALISIS3Fecha']."','".$data['GestanteUROANALISIS3Res']."','".$data['GestanteUROANALISIS3']."','".$data['GestanteGLICEMIA1Fecha']."','".$data['GestanteGLICEMIA1Res']."','".$data['GestanteGLICEMIA1']."','".$data['GestanteGLICEMIA2Fecha']."','".$data['GestanteGLICEMIA2Res']."','".$data['GestanteGLICEMIA2']."','".$data['GestanteGLICEMIA3Fecha']."','".$data['GestanteGLICEMIA3Res']."','".$data['GestanteGLICEMIA3']."','".$data['GestanteHIV1Fecha']."','".$data['GestanteHIV1Res']."','".$data['GestanteHIV1']."','".$data['GestanteHIV2Fecha']."','".$data['GestanteHIV2Res']."','".$data['GestanteHIV2']."','".$data['GestanteHIV3Fecha']."','".$data['GestanteHIV3Res']."','".$data['GestanteHIV3']."','".$data['GestanteHBSAg1Fecha']."','".$data['GestanteHBSAg1Res']."','".$data['GestanteHBSAg1']."','".$data['GestanteHBSAg2Fecha']."','".$data['GestanteHBSAg2Res']."','".$data['GestanteHBSAg2']."','".$data['GestanteHBSAg3Fecha']."','".$data['GestanteHBSAg3Res']."','".$data['GestanteHBSAg3']."','".$data['GestanteFROTISVAGINAL1Fecha']."','".$data['GestanteFROTISVAGINAL1Res']."','".$data['GestanteFROTISVAGINAL1']."','".$data['GestanteFROTISVAGINAL2Fecha']."','".$data['GestanteFROTISVAGINAL2Res']."','".$data['GestanteFROTISVAGINAL2']."','".$data['GestanteFROTISVAGINAL3Fecha']."','".$data['GestanteFROTISVAGINAL3Res']."','".$data['GestanteFROTISVAGINAL3']."','".$data['GestanteTOXOlgG1Fecha']."','".$data['GestanteTOXOlgG1Res']."','".$data['GestanteTOXOlgG1']."','".$data['GestanteTOXOlgG2Fecha']."','".$data['GestanteTOXOlgG2Res']."','".$data['GestanteTOXOlgG2']."','".$data['GestanteTOXOlgG3Fecha']."','".$data['id_planJSON']."','".$data['GestanteTOXOlgG3']."','".$data['GestanteTOXOlgM1Fecha']."','".$data['GestanteTOXOlgM1Res']."','".$data['GestanteTOXOlgM1']."','".$data['GestanteTOXOlgM2Fecha']."','".$data['GestanteTOXOlgM2Res']."','".$data['GestanteTOXOlgM2']."','".$data['GestanteTOXOlgM3Fecha']."','".$data['GestanteTOXOlgM3Res']."','".$data['GestanteTOXOlgM3']."','".$data['GestantePrueto1Fecha']."','".$data['GestantePrueto1Res']."','".$data['GestantePrueto1']."','".$data['GestantePrueto2Fecha']."','".$data['GestantePrueto2Res']."','".$data['GestantePrueto2']."','".$data['GestantePrueto3Fecha']."','".$data['GestantePrueto3Res']."','".$data['GestantePrueto3']."','".$data['coombsIndi1Fecha']."','".$data['coombsIndi1Res']."','".$data['coombsIndi1']."','".$data['coombsIndi2Fecha']."','".$data['coombsIndi2Res']."','".$data['coombsIndi2']."','".$data['coombsIndi3Fecha']."','".$data['coombsIndi3Res']."','".$data['coombsIndi3']."','".$data['GestanteCitolVag']."','".$data['GestanteFechaultCito']."','".$data['GestanteNormSatis']."','".$data['GestanteFechEco1']."','".$data['GestanteObsEco1']."','".$data['GestanteNormEco1']."','".$data['GestanteCamBeni']."','".$data['GestanteFechEco2']."','".$data['GestanteObsEco2']."','".$data['GestanteNormEco2']."','".$data['GestanteAnorPlant']."','".$data['GestanteFechEco3']."','".$data['GestanteObsEco3']."','".$data['GestanteNormEco3']."','".$data['GestanteColscopPl']."','".$data['GestanteFechEco4']."','".$data['GestanteObsEco4']."','".$data['GestanteNormEco4']."','".$data['id_registra']."','".$data['tipoid_registra']."','".$data['institucion']."')";
        
        $resultDelete= array();
        $resDelete = $instance->exec($sqlDelete); 
        if ($resDelete['STATUS']=='OK' ) {
            $result = array();

            $res = $instance->exec($sqlInsert); 
            if ($res['STATUS']=='OK' ) {
    
                $result['STATUS'] = 'OK';
                $result['ID'] = $res['ID'];
    
            } else { 
    
                $result['STATUS'] = 'ERROR';
                $result['SQL']=$sql;
    
            }
    
          

        } else { 

            $result['STATUS'] = 'ERROR';
            $result['SQL']=$sql;

        }
        
        return $result;

    
    }

    public function registrarEntrenamiento($data){
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

 
        
        $sql="INSERT INTO `entrenamiento`( `id_entreJSON`, `id_gestacion`, `id_gestacionJSON`, `gestanteEntrPreTem1`, `gestanteEntrPreTem2`, `gestanteEntrPreTem3`, `gestanteEntrPreTem4`, `gestanteEntrPreTem5`, `gestanteEntrPreFec1`, `gestanteEntrPreFec2`, `gestanteEntrPreFec3`, `gestanteEntrPreFec4`, `gestanteEntrPreFec5`, `id_registra`, `tipoid_registra`, `institucion`) VALUES ('".$data['id_entreJSON']."','".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['gestanteEntrPreTem1']."','".$data['gestanteEntrPreTem2']."','".$data['gestanteEntrPreTem3']."','".$data['gestanteEntrPreTem4']."','".$data['gestanteEntrPreTem5']."','".$data['gestanteEntrPreFec1']."','".$data['gestanteEntrPreFec2']."','".$data['gestanteEntrPreFec3']."','".$data['gestanteEntrPreFec4']."','".$data['gestanteEntrPreFec5']."','".$data['id_registra']."','".$data['tipoid_registra']."','".$data['institucion']."')";
        
        $result = array();

        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {

            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';
            $result['SQL']=$sql;

        }

        return $result;

    
    }

    public function actualizarEntrenamiento($data){
        $instance = Database::getInstance(); 
        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        } 

        $sqlDelete='DELETE FROM entrenamiento WHERE `id_entre`='.$data['id_entre'];
        
        $sqlInsert="INSERT INTO `entrenamiento`( `id_entre`, `id_entreJSON`, `id_gestacion`, `id_gestacionJSON`, `gestanteEntrPreTem1`, `gestanteEntrPreTem2`, `gestanteEntrPreTem3`, `gestanteEntrPreTem4`, `gestanteEntrPreTem5`, `gestanteEntrPreFec1`, `gestanteEntrPreFec2`, `gestanteEntrPreFec3`, `gestanteEntrPreFec4`, `gestanteEntrPreFec5`, `id_registra`, `tipoid_registra`, `institucion`) VALUES (".$data['id_entre'].",'".$data['id_entreJSON']."','".$data['id_gestacion']."','".$data['id_gestacionJSON']."','".$data['gestanteEntrPreTem1']."','".$data['gestanteEntrPreTem2']."','".$data['gestanteEntrPreTem3']."','".$data['gestanteEntrPreTem4']."','".$data['gestanteEntrPreTem5']."','".$data['gestanteEntrPreFec1']."','".$data['gestanteEntrPreFec2']."','".$data['gestanteEntrPreFec3']."','".$data['gestanteEntrPreFec4']."','".$data['gestanteEntrPreFec5']."','".$data['id_registra']."','".$data['tipoid_registra']."','".$data['institucion']."')";
        
        $resultDelete= array();
        $resDelete = $instance->exec($sqlDelete); 
        if ($resDelete['STATUS']=='OK' ) {
            $result = array();

            $res = $instance->exec($sqlInsert); 
            if ($res['STATUS']=='OK' ) {
    
                $result['STATUS'] = 'OK';
                $result['ID'] = $res['ID'];
    
            } else { 
    
                $result['STATUS'] = 'ERROR';
                $result['SQL']=$sqlInsert;
    
            }
    
          

        } else { 

            $result['STATUS'] = 'ERROR';
            $result['SQL']=$sql;

        }
        
        return $result;

    
    }



    public function ExtraerPlanMantenimiento($data){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT * FROM plan_mantenimiento WHERE ";

        $result = array();
        
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {

            $result['DATA'] = $res['DATA'];
            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }
    public function listarConsultas(){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        $sql = "SELECT gr.* , pc.nombres, pc.papellido, pc.sapellido FROM consultas_prenatales gr, pacientes pc WHERE pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac";

        $result = array();
        
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {

            $result['DATA'] = $res['DATA'];
            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }
    public function listarConsultasPaciente($tipoid, $numid){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        $sql = "SELECT gr.* FROM pregnant_consultation gr WHERE gr.tipoid_pac='".$tipoid."' AND gr.numid_pac='".$numid."'";
        $result = array();
        
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {

            $result['DATA'] = $res['DATA'];
            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }


    

    public function registrarConsulta($data){
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

 
        $sql="INSERT INTO `controles_gestaciones`(  `idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `id_gestacion`, `id_gestacionJSON`, `GestantefechaConsulta`, `GestantehoraConsulta`, `GestanteprofAtiende`, `GestanteprofesionAtiende`, `GestanteRegprofesionAtiende`, `nombrPacienteAte`, `GestantenombreAcompana`, `GestanteparentezcoAcompana`, `GestanteAcompanaTelefono`, `GestantenombreResponsable`, `GestanteparentezcoResponsable`, `GestanteResponsableTelefono`, `GestantetipoConsulta`, `GestantefinalidadConsulta`, `GestantecausaExternaConsulta`, `GestantemotivoConsulta`, `GestanteenfermedadActualConsulta`, `GestanteAntDiabetes`, `GestanteAntHipertensionArterial`, `GestanteAntCirugiaPelvica`, `GestanteAntOtrasCirugias`, `GestanteAntPreeclamsia`, `GestanteAntEclamsia`, `GestanteAntFactorRH`, `GestanteAntTransfusiones`, `GestanteAntAltTiroideas`, `GestanteAntNutiPrevDefic`, `GestanteAntEnfRenalCronica`, `GestanteAntTtoInfertilidad`, `GestanteAntDifLactancia`, `GestanteAntAlergias`, `GestanteAntTraumaticos`, `GestanteAntOtrasTBC`, `GestanteAntPsicofarm`, `GestanteAntOtrasCigarrilloAlcohol`, `GestanteAnIrradiacion`, `GestanteVIHSIDA`, `GestanteAntExpoToxicos`, `GestanteAntExpoToxicosCuales`, `GestanteAntMedicamentos`, `GestanteAntMedicamentosCuales`, `GestanteAntUsaCepillo`, `GestanteAntUsaCrema`, `GestanteAntUsaSeda`, `GestanteAntVecesCepilla`, `GestanteAntOtrosHabitosHigieneOral`, `GestanteAntOtrosHabitosHigieneOralCuales`, `GestanteAntSangranEncias`, `GestanteAntDolorRuidosATM`, `GestanteAntLimitacionAbrirBoca`, `GestanteAntFechaUConsO`, `GestanteAntEdadMenarquia`, `GestanteAntCiclosIrregulares`, `GestanteAntPatronCicloI`, `GestanteAntPatronCicloII`, `GestanteAntparejasSexuales`, `GestanteAntFlujoVaginal`, `GestanteAntEnfTransSexual`, `GestanteAntVihRprueba`, `GestanteAntTtoInfertilidadG`, `GestanteAntTtoInfertilidadGTipo`, `GestanteAntMetodoPlanifica`, `GestanteAntFechaSusMetodoPlan`, `GestanteAntFechaFum`, `GestanteAntConfiableFUM`, `GestanteAntEmbarazos`, `GestanteAntFechaFPP`, `GestanteAntAbortoHabitu`, `GestanteAntGineG`, `GestanteAntGineP`, `GestanteAntGineC`, `GestanteAntGineA`, `GestanteAntGineE`, `GestanteAntGineV`, `GestanteAntGineM`, `GestanteAntMENARQUIA`, `GestanteAntCICLOS`, `GestanteAntPLANIFICACIONF`, `GestanteAntLeucorreas`, `GestanteAntETS`, `GestanteAntFechaCITOLOGIAUtl`, `GestanteAntCOLPOSCOPIA`, `GestanteAntPerioINTERGENESICO`, `GestanteAntPerioINTERGENESICOUME`, `GestanteAntRCIU`, `GestanteAntAmenaPartoPrematuro`, `GestanteAntPartoPREMATURO`, `GestanteAntGEMELAR`, `GestanteAntMALFORMACIONES`, `GestanteAntOLIGOHIDRAMNIOS`, `GestanteAntEmbProlongado`, `GestanteAntGineOtros`, `GestanteAntGineOtrosCuales`, `GestanteAntAmenazaAborto`, `GestanteAntFEchaUltParto`, `GestanteAntFEchaUltPartoTiempo`, `GestanteAntNoPartos`, `GestanteAntC`, `GestanteAntCdESC`, `GestanteAntEmbaraMultiple`, `GestanteAntEmbaraMultipleDesc`, `GestanteAntPrematuro`, `GestanteAntPrematuroDEsc`, `GestanteAntATermino`, `GestanteAntPROLONGADO`, `GestanteAntPROLONGADODesc`, `GestanteAntNacidosVivos`, `GestanteAntMORTINATOS`, `GestanteAntMORTINATOSDesc`, `GestanteAntInfeccPostParto`, `GestanteAntMacromsiaFetal`, `GestanteAntMarformaCongenitas`, `GestanteAntMarformaCongenitasDesc`, `GestanteAntMuertePerinatal`, `GestanteAntMuertePerinatalCausa`, `GestanteAntPsicosisPostParto`, `GestanteAntLimitacionDesproCefaloPelvic`, `GestanteAntSufrimientoFetAgudo`, `GestanteAntCausaCesaPartoPREMATURO`, `GestanteAntPresenDistolica`, `GestanteAntRupturaPreMembra`, `GestanteAntHemo3erTrimes`, `GestanteAntHiperxGesta`, `GestanteAntRCIUCe`, `GestanteAntCesareasprevias`, `GestanteAntProlapsCordon`, `GestanteAntOtrasCausasCesareas`, `GestanteAntOtrasCausasCesareasCuales`, `GestanteAntDiabetesfamiliar`, `GestanteAntHtaFamiliar`, `GestanteAntPreeclamsiaFamiliares`, `GestanteAntEclamsiaFamiliares`, `GestanteAntGemelaresFamiliares`, `GestanteAntCardiopatiaFamiliares`, `GestanteAntTBCFamiliares`, `GestanteAntDiscapacidadFamiliares`, `GestanteAntOtrosFamiliares`, `GestanteAntOtrosFamiliaresCuales`, `vaControPrenaacieLisr`, `GestanteVacu1ra`, `GestanteVacu2ra`, `GestanteVacu1`, `GestanteVacu2`, `GestanteVacu3`, `GestanteAnaRieMa1`, `GestanteAnaRieNi1`, `GestanteAnaRieMa2`, `GestanteAnaRieNi2`, `GestanteAnaRieMa3`, `GestanteAnaRieNi3`, `GestanteFactProct`, `GestanteEstimFetal`, `GestanteLactMater`, `GestanteVincuAfec`, `GestantePreveAutom`, `GestanteConTaba`, `GestanteSignAlar`, `gestanteOtroEduInd`, `gestanteEntrPreTem1`, `gestanteEntrPreTem2`, `gestanteEntrPreTem3`, `gestanteEntrPreTem4`, `gestanteEntrPreTem5`, `gestanteEntrPreFec1`, `gestanteEntrPreFec2`, `gestanteEntrPreFec3`, `gestanteEntrPreFec4`, `gestanteEntrPreFec5`, `listadoCIEPa`, `tipoDiagnosPrinc`, `medAsigCons`, `ordenMedCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `sexarquia`, `BiopEdad`, `BioPari`, `abprhabinfer`, `retencPlacent`, `pesobebemayor`, `pesobebemenor`, `htaIndEmbara`, `EmbaGemelarCesara`, `mortinatoMuerto`, `TPProlongada`, `OXgineolgica`, `EnferReanlCronic`, `diabetGesta`, `diabetesMellitus`, `EnfermCardiaca`, `EnfermedadInfeccios`, `agudasBacterianas`, `anemiaHB10gl`, `hemorragia20ms`, `vaginal2oss`, `Epronlogadoante`, `htaantecdepr`, `anteRpm`, `polidraminiosAntEmbaActual`, `RCIUAntecente`, `embMultipleatne`, `MalaPresenta`, `isoirh`, `tipoIDUserReg`, `numeroIDUserReg`, `tipoid_pac`, `numid_pac`) values(".intVal($data['idJSON_consulta']).",".intVal($data['id_paciente']).",".intVal($data['idJSON_paciente']).",".intVal($data['id_gestacion']).",".intVal($data['id_gestacionJSON']).",'".$data['GestantefechaConsulta']."','".$data['GestantehoraConsulta']."','".$data['GestanteprofAtiende']."','".$data['GestanteprofesionAtiende']."','".$data['GestanteRegprofesionAtiende']."','".$data['nombrPacienteAte']."','".$data['GestantenombreAcompana']."','".$data['GestanteparentezcoAcompana']."','".$data['GestanteAcompanaTelefono']."','".$data['GestantenombreResponsable']."','".$data['GestanteparentezcoResponsable']."','".$data['GestanteResponsableTelefono']."','".$data['GestantetipoConsulta']."','".$data['GestantefinalidadConsulta']."','".$data['GestantecausaExternaConsulta']."','".$data['GestantemotivoConsulta']."','".$data['GestanteenfermedadActualConsulta']."','".$data['GestanteAntDiabetes']."','".$data['GestanteAntHipertensionArterial']."','".$data['GestanteAntCirugiaPelvica']."','".$data['GestanteAntOtrasCirugias']."','".$data['GestanteAntPreeclamsia']."','".$data['GestanteAntEclamsia']."','".$data['GestanteAntFactorRH']."','".$data['GestanteAntTransfusiones']."','".$data['GestanteAntAltTiroideas']."','".$data['GestanteAntNutiPrevDefic']."','".$data['GestanteAntEnfRenalCronica']."','".$data['GestanteAntTtoInfertilidad']."','".$data['GestanteAntDifLactancia']."','".$data['GestanteAntAlergias']."','".$data['GestanteAntTraumaticos']."','".$data['GestanteAntOtrasTBC']."','".$data['GestanteAntPsicofarm']."','".$data['GestanteAntOtrasCigarrilloAlcohol']."','".$data['GestanteAnIrradiacion']."','".$data['GestanteVIHSIDA']."','".$data['GestanteAntExpoToxicos']."','".$data['GestanteAntExpoToxicosCuales']."','".$data['GestanteAntMedicamentos']."','".$data['GestanteAntMedicamentosCuales']."','".$data['GestanteAntUsaCepillo']."','".$data['GestanteAntUsaCrema']."','".$data['GestanteAntUsaSeda']."','".$data['GestanteAntVecesCepilla']."','".$data['GestanteAntOtrosHabitosHigieneOral']."','".$data['GestanteAntOtrosHabitosHigieneOralCuales']."','".$data['GestanteAntSangranEncias']."','".$data['GestanteAntDolorRuidosATM']."','".$data['GestanteAntLimitacionAbrirBoca']."','".$data['GestanteAntFechaUConsO']."','".$data['GestanteAntEdadMenarquia']."','".$data['GestanteAntCiclosIrregulares']."','".$data['GestanteAntPatronCicloI']."','".$data['GestanteAntPatronCicloII']."','".$data['GestanteAntparejasSexuales']."','".$data['GestanteAntFlujoVaginal']."','".$data['GestanteAntEnfTransSexual']."','".$data['GestanteAntVihRprueba']."','".$data['GestanteAntTtoInfertilidad']."','".$data['GestanteAntTtoInfertilidadTipo']."','".$data['GestanteAntMetodoPlanifica']."','".$data['GestanteAntFechaSusMetodoPlan']."','".$data['GestanteAntFechaFum']."','".$data['GestanteAntConfiableFUM']."','".$data['GestanteAntEmbarazos']."','".$data['GestanteAntFechaFPP']."','".$data['GestanteAntAbortoHabitu']."','".$data['GestanteAntGineG']."','".$data['GestanteAntGineP']."','".$data['GestanteAntGineC']."','".$data['GestanteAntGineA']."','".$data['GestanteAntGineE']."','".$data['GestanteAntGineV']."','".$data['GestanteAntGineM']."','".$data['GestanteAntMENARQUIA']."','".$data['GestanteAntCICLOS']."','".$data['GestanteAntPLANIFICACIONF']."','".$data['GestanteAntLeucorreas']."','".$data['GestanteAntETS']."','".$data['GestanteAntFechaCITOLOGIAUtl']."','".$data['GestanteAntCOLPOSCOPIA']."','".$data['GestanteAntPerioINTERGENESICO']."','".$data['GestanteAntPerioINTERGENESICOUME']."','".$data['GestanteAntRCIU']."','".$data['GestanteAntAmenaPartoPrematuro']."','".$data['GestanteAntPartoPREMATURO']."','".$data['GestanteAntGEMELAR']."','".$data['GestanteAntMALFORMACIONES']."','".$data['GestanteAntOLIGOHIDRAMNIOS']."','".$data['GestanteAntEmbProlongado']."','".$data['GestanteAntGineOtros']."','".$data['GestanteAntGineOtrosCuales']."','".$data['GestanteAntAmenazaAborto']."','".$data['GestanteAntFEchaUltParto']."','".$data['GestanteAntFEchaUltPartoTiempo']."','".$data['GestanteAntNoPartos']."','".$data['GestanteAntC']."','".$data['GestanteAntCdESC']."','".$data['GestanteAntEmbaraMultiple']."','".$data['GestanteAntEmbaraMultipleDesc']."','".$data['GestanteAntPrematuro']."','".$data['GestanteAntPrematuroDEsc']."','".$data['GestanteAntATermino']."','".$data['GestanteAntPROLONGADO']."','".$data['GestanteAntPROLONGADODesc']."','".$data['GestanteAntNacidosVivos']."','".$data['GestanteAntMORTINATOS']."','".$data['GestanteAntMORTINATOSDesc']."','".$data['GestanteAntInfeccPostParto']."','".$data['GestanteAntMacromsiaFetal']."','".$data['GestanteAntMarformaCongenitas']."','".$data['GestanteAntMarformaCongenitasDesc']."','".$data['GestanteAntMuertePerinatal']."','".$data['GestanteAntMuertePerinatalCausa']."','".$data['GestanteAntPsicosisPostParto']."','".$data['GestanteAntLimitacionDesproCefaloPelvic']."','".$data['GestanteAntSufrimientoFetAgudo']."','".$data['GestanteAntCausaCesaPartoPREMATURO']."','".$data['GestanteAntPresenDistolica']."','".$data['GestanteAntRupturaPreMembra']."','".$data['GestanteAntHemo3erTrimes']."','".$data['GestanteAntHiperxGesta']."','".$data['GestanteAntRCIUCe']."','".$data['GestanteAntCesareasprevias']."','".$data['GestanteAntProlapsCordon']."','".$data['GestanteAntOtrasCausasCesareas']."','".$data['GestanteAntOtrasCausasCesareasCuales']."','".$data['GestanteAntDiabetesfamiliar']."','".$data['GestanteAntHtaFamiliar']."','".$data['GestanteAntPreeclamsiaFamiliares']."','".$data['GestanteAntEclamsiaFamiliares']."','".$data['GestanteAntGemelaresFamiliares']."','".$data['GestanteAntCardiopatiaFamiliares']."','".$data['GestanteAntTBCFamiliares']."','".$data['GestanteAntDiscapacidadFamiliares']."','".$data['GestanteAntOtrosFamiliares']."','".$data['GestanteAntOtrosFamiliaresCuales']."','".$data['ControPrenaacieLis']."','".$data['GestanteVacu1ra']."','".$data['GestanteVacu2ra']."','".$data['GestanteVacu1']."','".$data['GestanteVacu2']."','".$data['GestanteVacu3']."','".$data['GestanteAnaRieMa1']."','".$data['GestanteAnaRieNi1']."','".$data['GestanteAnaRieMa2']."','".$data['GestanteAnaRieNi2']."','".$data['GestanteAnaRieMa3']."','".$data['GestanteAnaRieNi3']."','".$data['GestanteFactProct']."','".$data['GestanteEstimFetal']."','".$data['GestanteLactMater']."','".$data['GestanteVincuAfec']."','".$data['GestantePreveAutom']."','".$data['GestanteConTaba']."','".$data['GestanteSignAlar']."','".$data['gestanteOtroEduInd']."','".$data['gestanteEntrPreTem1']."','".$data['gestanteEntrPreTem2']."','".$data['gestanteEntrPreTem3']."','".$data['gestanteEntrPreTem4']."','".$data['gestanteEntrPreTem5']."','".$data['gestanteEntrPreFec1']."','".$data['gestanteEntrPreFec2']."','".$data['gestanteEntrPreFec3']."','".$data['gestanteEntrPreFec4']."','".$data['gestanteEntrPreFec5']."','".$data['listadoCIEPa']."','".$data['tipoDiagnosPrinc']."','".$data['medAsigCons']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."','".$data['GestanteSexarquia']."', '".$data['BiopEdad']."', '".$data['BioPari']."', '".$data['abprhabinfer']."', '".$data['retencPlacent']."', '".$data['pesobebemayor']."', '".$data['pesobebemenor']."', '".$data['htaIndEmbara']."', '".$data['EmbaGemelarCesara']."', '".$data['mortinatoMuerto']."', '".$data['TPProlongada']."', '".$data['OXgineolgica']."', '".$data['EnferReanlCronic']."', '".$data['diabetGesta']."', '".$data['diabetesMellitus']."', '".$data['EnfermCardiaca']."', '".$data['EnfermedadInfeccios']."', '".$data['agudasBacterianas']."', '".$data['anemiaHB10gl']."', '".$data['hemorragia20ms']."', '".$data['vaginal2oss']."', '".$data['Epronlogadoante']."', '".$data['htaantecdepr']."', '".$data['anteRpm']."', '".$data['polidraminiosAntEmbaActual']."', '".$data['RCIUAntecente']."', '".$data['embMultipleatne']."', '".$data['MalaPresenta']."', '".$data['isoirh']."', '".$data['tipoIDUserReg']."','".$data['numeroIDUserReg']."','".$data['tipoid_pac']."','".$data['numid_pac']."')";

        //$sql="INSERT INTO `consultasgestan`(  `idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `GestantefechaConsulta`, `GestantehoraConsulta`, `GestanteprofAtiende`, `GestanteprofesionAtiende`, `GestanteRegprofesionAtiende`, `nombrPacienteAte`, `GestantenombreAcompana`, `GestanteparentezcoAcompana`, `GestanteAcompanaTelefono`, `GestantenombreResponsable`, `GestanteparentezcoResponsable`, `GestanteResponsableTelefono`, `GestantetipoConsulta`, `GestantefinalidadConsulta`, `GestantecausaExternaConsulta`, `GestantemotivoConsulta`, `GestanteenfermedadActualConsulta`, `GestanteAntDiabetes`, `GestanteAntHipertensionArterial`, `GestanteAntCirugiaPelvica`, `GestanteAntOtrasCirugias`, `GestanteAntPreeclamsia`, `GestanteAntEclamsia`, `GestanteAntFactorRH`, `GestanteAntTransfusiones`, `GestanteAntAltTiroideas`, `GestanteAntNutiPrevDefic`, `GestanteAntEnfRenalCronica`, `GestanteAntTtoInfertilidad`, `GestanteAntDifLactancia`, `GestanteAntAlergias`, `GestanteAntTraumaticos`, `GestanteAntOtrasTBC`, `GestanteAntPsicofarm`, `GestanteAntOtrasCigarrilloAlcohol`, `GestanteAnIrradiacion`, `GestanteVIHSIDA`, `GestanteAntExpoToxicos`, `GestanteAntExpoToxicosCuales`, `GestanteAntMedicamentos`, `GestanteAntMedicamentosCuales`, `GestanteAntUsaCepillo`, `GestanteAntUsaCrema`, `GestanteAntUsaSeda`, `GestanteAntVecesCepilla`, `GestanteAntOtrosHabitosHigieneOral`, `GestanteAntOtrosHabitosHigieneOralCuales`, `GestanteAntSangranEncias`, `GestanteAntDolorRuidosATM`, `GestanteAntLimitacionAbrirBoca`, `GestanteAntFechaUConsO`, `GestanteAntEdadMenarquia`, `GestanteAntCiclosIrregulares`, `GestanteAntPatronCicloI`, `GestanteAntPatronCicloII`, `GestanteAntparejasSexuales`, `GestanteAntFlujoVaginal`, `GestanteAntEnfTransSexual`, `GestanteAntVihRprueba`, `GestanteAntTtoInfertilidadG`, `GestanteAntTtoInfertilidadGTipo`, `GestanteAntMetodoPlanifica`, `GestanteAntFechaSusMetodoPlan`, `GestanteAntFechaFum`, `GestanteAntConfiableFUM`, `GestanteAntEmbarazos`, `GestanteAntFechaFPP`, `GestanteAntAbortoHabitu`, `GestanteAntGineG`, `GestanteAntGineP`, `GestanteAntGineC`, `GestanteAntGineA`, `GestanteAntGineE`, `GestanteAntGineV`, `GestanteAntGineM`, `GestanteAntMENARQUIA`, `GestanteAntCICLOS`, `GestanteAntPLANIFICACIONF`, `GestanteAntLeucorreas`, `GestanteAntETS`, `GestanteAntFechaCITOLOGIAUtl`, `GestanteAntCOLPOSCOPIA`, `GestanteAntPerioINTERGENESICO`, `GestanteAntPerioINTERGENESICOUME`, `GestanteAntRCIU`, `GestanteAntAmenaPartoPrematuro`, `GestanteAntPartoPREMATURO`, `GestanteAntGEMELAR`, `GestanteAntMALFORMACIONES`, `GestanteAntOLIGOHIDRAMNIOS`, `GestanteAntEmbProlongado`, `GestanteAntGineOtros`, `GestanteAntGineOtrosCuales`, `GestanteAntAmenazaAborto`, `GestanteAntFEchaUltParto`, `GestanteAntFEchaUltPartoTiempo`, `GestanteAntNoPartos`, `GestanteAntC`, `GestanteAntCdESC`, `GestanteAntEmbaraMultiple`, `GestanteAntEmbaraMultipleDesc`, `GestanteAntPrematuro`, `GestanteAntPrematuroDEsc`, `GestanteAntATermino`, `GestanteAntPROLONGADO`, `GestanteAntPROLONGADODesc`, `GestanteAntNacidosVivos`, `GestanteAntMORTINATOS`, `GestanteAntMORTINATOSDesc`, `GestanteAntInfeccPostParto`, `GestanteAntMacromsiaFetal`, `GestanteAntMarformaCongenitas`, `GestanteAntMarformaCongenitasDesc`, `GestanteAntMuertePerinatal`, `GestanteAntMuertePerinatalCausa`, `GestanteAntPsicosisPostParto`, `GestanteAntLimitacionDesproCefaloPelvic`, `GestanteAntSufrimientoFetAgudo`, `GestanteAntCausaCesaPartoPREMATURO`, `GestanteAntPresenDistolica`, `GestanteAntRupturaPreMembra`, `GestanteAntHemo3erTrimes`, `GestanteAntHiperxGesta`, `GestanteAntRCIUCe`, `GestanteAntCesareasprevias`, `GestanteAntProlapsCordon`, `GestanteAntOtrasCausasCesareas`, `GestanteAntOtrasCausasCesareasCuales`, `GestanteAntDiabetesfamiliar`, `GestanteAntHtaFamiliar`, `GestanteAntPreeclamsiaFamiliares`, `GestanteAntEclamsiaFamiliares`, `GestanteAntGemelaresFamiliares`, `GestanteAntCardiopatiaFamiliares`, `GestanteAntTBCFamiliares`, `GestanteAntDiscapacidadFamiliares`, `GestanteAntOtrosFamiliares`, `GestanteAntOtrosFamiliaresCuales`, `vaControPrenaacieLisr`, `GestanteVacu1ra`, `GestanteVacu2ra`, `GestanteVacu1`, `GestanteVacu2`, `GestanteVacu3`, `GestnteGrupoSa`, `GestanteclasRh`, `GestanteAnaRieMa1`, `GestanteAnaRieNi1`, `GestanteAnaRieMa2`, `GestanteAnaRieNi2`, `GestanteAnaRieMa3`, `GestanteAnaRieNi3`, `GestanteHEMOGRAMA1Fec`, `GestanteHEMOGRAMA1Desc`, `GestanteHEMOGRAMA1`, `GestanteHEMOGRAMA2Fec`, `GestanteHEMOGRAMA2Desc`, `GestanteHEMOGRAMA2`, `GestanteHEMOGRAMA3Fec`, `GestanteHEMOGRAMA3Desc`, `GestanteHEMOGRAMA3`, `GestanteVDRL1Fecha`, `GestanteVDRL1Res`, `GestanteVDRL1`, `GestanteVDRL2Fecha`, `GestanteVDRL2Res`, `GestanteVDRL2`, `GestanteVDRL3Fecha`, `GestanteVDRL3Res`, `GestanteVDRL3`, `GestanteUROANALISIS1Fecha`, `GestanteUROANALISIS1Res`, `GestanteUROANALISIS1`, `GestanteUROANALISIS2Fecha`, `GestanteUROANALISIS2Res`, `GestanteUROANALISIS2`, `GestanteUROANALISIS3Fecha`, `GestanteUROANALISIS3Res`, `GestanteUROANALISIS3`, `GestanteGLICEMIA1Fecha`, `GestanteGLICEMIA1Res`, `GestanteGLICEMIA1`, `GestanteGLICEMIA2Fecha`, `GestanteGLICEMIA2Res`, `GestanteGLICEMIA2`, `GestanteGLICEMIA3Fecha`, `GestanteGLICEMIA3Res`, `GestanteGLICEMIA3`, `GestanteHIV1Fecha`, `GestanteHIV1Res`, `GestanteHIV1`, `GestanteHIV2Fecha`, `gestanteHIV2Res`, `GestanteHIV2`, `GestanteHIV3Fecha`, `GestanteHIV3Res`, `GestanteHIV3`, `GestanteHBSAg1Fecha`, `GestanteHBSAg1Res`, `GestanteHBSAg1`, `GestanteHBSAg2Fecha`, `GestanteHBSAg2Res`, `GestanteHBSAg2`, `GestanteHBSAg3Fecha`, `GestanteHBSAg3Res`, `GestanteHBSAg3`, `GestanteFROTISVAGINAL1Fecha`, `GestanteFROTISVAGINAL1Res`, `GestanteFROTISVAGINAL1`, `GestanteFROTISVAGINAL2Fecha`, `GestanteFROTISVAGINAL2Res`, `GestanteFROTISVAGINAL2`, `GestanteFROTISVAGINAL3Fecha`, `GestanteFROTISVAGINAL3Res`, `GestanteFROTISVAGINAL3`, `GestanteTOXOlgG1Fecha`, `GestanteTOXOlgG1Res`, `GestanteTOXOlgG1`, `GestanteTOXOlgG2Fecha`, `GestanteTOXOlgG2Res`, `GestanteTOXOlgG2`, `GestanteTOXOlgG3Fecha`, `GestanteTOXOlgG3Res`, `GestanteTOXOlgG3`, `GestanteTOXOlgM1Fecha`, `GestanteTOXOlgM1Res`, `GestanteTOXOlgM1`, `GestanteTOXOlgM2Fecha`, `GestanteTOXOlgM2Res`, `GestanteTOXOlgM2`, `GestanteTOXOlgM3Fecha`, `GestanteTOXOlgM3Res`, `GestanteTOXOlgM3`, `GestantePrueto1Fecha`, `GestantePrueto1Res`, `GestantePrueto1`, `GestantePrueto2Fecha`, `GestantePrueto2Res`, `GestantePrueto2`, `GestantePrueto3Fecha`, `GestantePrueto3Res`, `GestantePrueto3`, `coombsIndi1Fecha`, `coombsIndi1Res`, `coombsIndi1`, `coombsIndi2Fecha`, `coombsIndi2Res`, `coombsIndi2`, `coombsIndi3Fecha`, `coombsIndi3Res`, `coombsIndi3`, `GestanteCitolVag`, `GestanteFechaultCito`, `GestanteNormSatis`, `GestanteFechEco1`, `GestanteObsEco1`, `GestanteNormEco1`, `GestanteCamBeni`, `GestanteFechEco2`, `GestanteObsEco2`, `GestanteNormEco2`, `GestanteAnorPlant`, `GestanteFechEco3`, `GestanteObsEco3`, `GestanteNormEco3`, `GestanteColscopPl`, `GestanteFechEco4`, `GestanteObsEco4`, `GestanteNormEco4`, `GestanteFactProct`, `GestanteEstimFetal`, `GestanteLactMater`, `GestanteVincuAfec`, `GestantePreveAutom`, `GestanteConTaba`, `GestanteSignAlar`, `gestanteOtroEduInd`, `gestanteEntrPreTem1`, `gestanteEntrPreTem2`, `gestanteEntrPreTem3`, `gestanteEntrPreTem4`, `gestanteEntrPreTem5`, `gestanteEntrPreFec1`, `gestanteEntrPreFec2`, `gestanteEntrPreFec3`, `gestanteEntrPreFec4`, `gestanteEntrPreFec5`, `listadoCIEPa`, `tipoDiagnosPrinc`, `medAsigCons`, `ordenMedCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `sexarquia`, `BiopEdad`, `BioPari`, `abprhabinfer`, `retencPlacent`, `pesobebemayor`, `pesobebemenor`, `htaIndEmbara`, `EmbaGemelarCesara`, `mortinatoMuerto`, `TPProlongada`, `OXgineolgica`, `EnferReanlCronic`, `diabetGesta`, `diabetesMellitus`, `EnfermCardiaca`, `EnfermedadInfeccios`, `agudasBacterianas`, `anemiaHB10gl`, `hemorragia20ms`, `vaginal2oss`, `Epronlogadoante`, `htaantecdepr`, `anteRpm`, `polidraminiosAntEmbaActual`, `RCIUAntecente`, `embMultipleatne`, `MalaPresenta`, `isoirh`, `tipoIDUserReg`, `numeroIDUserReg`, `tipoid_pac`, `numid_pac`) values(".intVal($data['idJSON_consulta']).",".intVal($data['id_paciente']).",".intVal($data['idJSON_paciente']).",'".$data['GestantefechaConsulta']."','".$data['GestantehoraConsulta']."','".$data['GestanteprofAtiende']."','".$data['GestanteprofesionAtiende']."','".$data['GestanteRegprofesionAtiende']."','".$data['nombrPacienteAte']."','".$data['GestantenombreAcompana']."','".$data['GestanteparentezcoAcompana']."','".$data['GestanteAcompanaTelefono']."','".$data['GestantenombreResponsable']."','".$data['GestanteparentezcoResponsable']."','".$data['GestanteResponsableTelefono']."','".$data['GestantetipoConsulta']."','".$data['GestantefinalidadConsulta']."','".$data['GestantecausaExternaConsulta']."','".$data['GestantemotivoConsulta']."','".$data['GestanteenfermedadActualConsulta']."','".$data['GestanteAntDiabetes']."','".$data['GestanteAntHipertensionArterial']."','".$data['GestanteAntCirugiaPelvica']."','".$data['GestanteAntOtrasCirugias']."','".$data['GestanteAntPreeclamsia']."','".$data['GestanteAntEclamsia']."','".$data['GestanteAntFactorRH']."','".$data['GestanteAntTransfusiones']."','".$data['GestanteAntAltTiroideas']."','".$data['GestanteAntNutiPrevDefic']."','".$data['GestanteAntEnfRenalCronica']."','".$data['GestanteAntTtoInfertilidad']."','".$data['GestanteAntDifLactancia']."','".$data['GestanteAntAlergias']."','".$data['GestanteAntTraumaticos']."','".$data['GestanteAntOtrasTBC']."','".$data['GestanteAntPsicofarm']."','".$data['GestanteAntOtrasCigarrilloAlcohol']."','".$data['GestanteAnIrradiacion']."','".$data['GestanteVIHSIDA']."','".$data['GestanteAntExpoToxicos']."','".$data['GestanteAntExpoToxicosCuales']."','".$data['GestanteAntMedicamentos']."','".$data['GestanteAntMedicamentosCuales']."','".$data['GestanteAntUsaCepillo']."','".$data['GestanteAntUsaCrema']."','".$data['GestanteAntUsaSeda']."','".$data['GestanteAntVecesCepilla']."','".$data['GestanteAntOtrosHabitosHigieneOral']."','".$data['GestanteAntOtrosHabitosHigieneOralCuales']."','".$data['GestanteAntSangranEncias']."','".$data['GestanteAntDolorRuidosATM']."','".$data['GestanteAntLimitacionAbrirBoca']."','".$data['GestanteAntFechaUConsO']."','".$data['GestanteAntEdadMenarquia']."','".$data['GestanteAntCiclosIrregulares']."','".$data['GestanteAntPatronCicloI']."','".$data['GestanteAntPatronCicloII']."','".$data['GestanteAntparejasSexuales']."','".$data['GestanteAntFlujoVaginal']."','".$data['GestanteAntEnfTransSexual']."','".$data['GestanteAntVihRprueba']."','".$data['GestanteAntTtoInfertilidad']."','".$data['GestanteAntTtoInfertilidadTipo']."','".$data['GestanteAntMetodoPlanifica']."','".$data['GestanteAntFechaSusMetodoPlan']."','".$data['GestanteAntFechaFum']."','".$data['GestanteAntConfiableFUM']."','".$data['GestanteAntEmbarazos']."','".$data['GestanteAntFechaFPP']."','".$data['GestanteAntAbortoHabitu']."','".$data['GestanteAntGineG']."','".$data['GestanteAntGineP']."','".$data['GestanteAntGineC']."','".$data['GestanteAntGineA']."','".$data['GestanteAntGineE']."','".$data['GestanteAntGineV']."','".$data['GestanteAntGineM']."','".$data['GestanteAntMENARQUIA']."','".$data['GestanteAntCICLOS']."','".$data['GestanteAntPLANIFICACIONF']."','".$data['GestanteAntLeucorreas']."','".$data['GestanteAntETS']."','".$data['GestanteAntFechaCITOLOGIAUtl']."','".$data['GestanteAntCOLPOSCOPIA']."','".$data['GestanteAntPerioINTERGENESICO']."','".$data['GestanteAntPerioINTERGENESICOUME']."','".$data['GestanteAntRCIU']."','".$data['GestanteAntAmenaPartoPrematuro']."','".$data['GestanteAntPartoPREMATURO']."','".$data['GestanteAntGEMELAR']."','".$data['GestanteAntMALFORMACIONES']."','".$data['GestanteAntOLIGOHIDRAMNIOS']."','".$data['GestanteAntEmbProlongado']."','".$data['GestanteAntGineOtros']."','".$data['GestanteAntGineOtrosCuales']."','".$data['GestanteAntAmenazaAborto']."','".$data['GestanteAntFEchaUltParto']."','".$data['GestanteAntFEchaUltPartoTiempo']."','".$data['GestanteAntNoPartos']."','".$data['GestanteAntC']."','".$data['GestanteAntCdESC']."','".$data['GestanteAntEmbaraMultiple']."','".$data['GestanteAntEmbaraMultipleDesc']."','".$data['GestanteAntPrematuro']."','".$data['GestanteAntPrematuroDEsc']."','".$data['GestanteAntATermino']."','".$data['GestanteAntPROLONGADO']."','".$data['GestanteAntPROLONGADODesc']."','".$data['GestanteAntNacidosVivos']."','".$data['GestanteAntMORTINATOS']."','".$data['GestanteAntMORTINATOSDesc']."','".$data['GestanteAntInfeccPostParto']."','".$data['GestanteAntMacromsiaFetal']."','".$data['GestanteAntMarformaCongenitas']."','".$data['GestanteAntMarformaCongenitasDesc']."','".$data['GestanteAntMuertePerinatal']."','".$data['GestanteAntMuertePerinatalCausa']."','".$data['GestanteAntPsicosisPostParto']."','".$data['GestanteAntLimitacionDesproCefaloPelvic']."','".$data['GestanteAntSufrimientoFetAgudo']."','".$data['GestanteAntCausaCesaPartoPREMATURO']."','".$data['GestanteAntPresenDistolica']."','".$data['GestanteAntRupturaPreMembra']."','".$data['GestanteAntHemo3erTrimes']."','".$data['GestanteAntHiperxGesta']."','".$data['GestanteAntRCIUCe']."','".$data['GestanteAntCesareasprevias']."','".$data['GestanteAntProlapsCordon']."','".$data['GestanteAntOtrasCausasCesareas']."','".$data['GestanteAntOtrasCausasCesareasCuales']."','".$data['GestanteAntDiabetesfamiliar']."','".$data['GestanteAntHtaFamiliar']."','".$data['GestanteAntPreeclamsiaFamiliares']."','".$data['GestanteAntEclamsiaFamiliares']."','".$data['GestanteAntGemelaresFamiliares']."','".$data['GestanteAntCardiopatiaFamiliares']."','".$data['GestanteAntTBCFamiliares']."','".$data['GestanteAntDiscapacidadFamiliares']."','".$data['GestanteAntOtrosFamiliares']."','".$data['GestanteAntOtrosFamiliaresCuales']."','".$data['ControPrenaacieLis']."','".$data['GestanteVacu1ra']."','".$data['GestanteVacu2ra']."','".$data['GestanteVacu1']."','".$data['GestanteVacu2']."','".$data['GestanteVacu3']."','".$data['GestanteAnaRieMa1']."','".$data['GestanteAnaRieNi1']."','".$data['GestanteAnaRieMa2']."','".$data['GestanteAnaRieNi2']."','".$data['GestanteAnaRieMa3']."','".$data['GestanteAnaRieNi3']."','".$data['GestnteGrupoSa']."','".$data['GestanteclasRh']."','".$data['GestanteHEMOGRAMA1Fec']."','".$data['GestanteHEMOGRAMA1Desc']."','".$data['GestanteHEMOGRAMA1']."','".$data['GestanteHEMOGRAMA2Fec']."','".$data['GestanteHEMOGRAMA2Desc']."','".$data['GestanteHEMOGRAMA2']."','".$data['GestanteHEMOGRAMA3Fec']."','".$data['GestanteHEMOGRAMA3Desc']."','".$data['GestanteHEMOGRAMA3']."','".$data['GestanteVDRL1Fecha']."','".$data['GestanteVDRL1Res']."','".$data['GestanteVDRL1']."','".$data['GestanteVDRL2Fecha']."','".$data['GestanteVDRL2Res']."','".$data['GestanteVDRL2']."','".$data['GestanteVDRL3Fecha']."','".$data['GestanteVDRL3Res']."','".$data['GestanteVDRL3']."','".$data['GestanteUROANALISIS1Fecha']."','".$data['GestanteUROANALISIS1Res']."','".$data['GestanteUROANALISIS1']."','".$data['GestanteUROANALISIS2Fecha']."','".$data['GestanteUROANALISIS2Res']."','".$data['GestanteUROANALISIS2']."','".$data['GestanteUROANALISIS3Fecha']."','".$data['GestanteUROANALISIS3Res']."','".$data['GestanteUROANALISIS3']."','".$data['GestanteGLICEMIA1Fecha']."','".$data['GestanteGLICEMIA1Res']."','".$data['GestanteGLICEMIA1']."','".$data['GestanteGLICEMIA2Fecha']."','".$data['GestanteGLICEMIA2Res']."','".$data['GestanteGLICEMIA2']."','".$data['GestanteGLICEMIA3Fecha']."','".$data['GestanteGLICEMIA3Res']."','".$data['GestanteGLICEMIA3']."','".$data['GestanteHIV1Fecha']."','".$data['GestanteHIV1Res']."','".$data['GestanteHIV1']."','".$data['GestanteHIV2Fecha']."','".$data['GestanteHIV2Res']."','".$data['GestanteHIV2']."','".$data['GestanteHIV3Fecha']."','".$data['GestanteHIV3Res']."','".$data['GestanteHIV3']."','".$data['GestanteHBSAg1Fecha']."','".$data['GestanteHBSAg1Res']."','".$data['GestanteHBSAg1']."','".$data['GestanteHBSAg2Fecha']."','".$data['GestanteHBSAg2Res']."','".$data['GestanteHBSAg2']."','".$data['GestanteHBSAg3Fecha']."','".$data['GestanteHBSAg3Res']."','".$data['GestanteHBSAg3']."','".$data['GestanteFROTISVAGINAL1Fecha']."','".$data['GestanteFROTISVAGINAL1Res']."','".$data['GestanteFROTISVAGINAL1']."','".$data['GestanteFROTISVAGINAL2Fecha']."','".$data['GestanteFROTISVAGINAL2Res']."','".$data['GestanteFROTISVAGINAL2']."','".$data['GestanteFROTISVAGINAL3Fecha']."','".$data['GestanteFROTISVAGINAL3Res']."','".$data['GestanteFROTISVAGINAL3']."','".$data['GestanteTOXOlgG1Fecha']."','".$data['GestanteTOXOlgG1Res']."','".$data['GestanteTOXOlgG1']."','".$data['GestanteTOXOlgG2Fecha']."','".$data['GestanteTOXOlgG2Res']."','".$data['GestanteTOXOlgG2']."','".$data['GestanteTOXOlgG3Fecha']."','".$data['GestanteTOXOlgG3Res']."','".$data['GestanteTOXOlgG3']."','".$data['GestanteTOXOlgM1Fecha']."','".$data['GestanteTOXOlgM1Res']."','".$data['GestanteTOXOlgM1']."','".$data['GestanteTOXOlgM2Fecha']."','".$data['GestanteTOXOlgM2Res']."','".$data['GestanteTOXOlgM2']."','".$data['GestanteTOXOlgM3Fecha']."','".$data['GestanteTOXOlgM3Res']."','".$data['GestanteTOXOlgM3']."','".$data['GestantePrueto1Fecha']."','".$data['GestantePrueto1Res']."','".$data['GestantePrueto1']."','".$data['GestantePrueto2Fecha']."','".$data['GestantePrueto2Res']."','".$data['GestantePrueto2']."','".$data['GestantePrueto3Fecha']."','".$data['GestantePrueto3Res']."','".$data['GestantePrueto3']."','".$data['coombsIndi1Fecha']."','".$data['coombsIndi1Res']."','".$data['coombsIndi1']."','".$data['coombsIndi2Fecha']."','".$data['coombsIndi2Res']."','".$data['coombsIndi2']."','".$data['coombsIndi3Fecha']."','".$data['coombsIndi3Res']."','".$data['coombsIndi3']."','".$data['GestanteCitolVag']."','".$data['GestanteFechaultCito']."','".$data['GestanteNormSatis']."','".$data['GestanteFechEco1']."','".$data['GestanteObsEco1']."','".$data['GestanteNormEco1']."','".$data['GestanteCamBeni']."','".$data['GestanteFechEco2']."','".$data['GestanteObsEco2']."','".$data['GestanteNormEco2']."','".$data['GestanteAnorPlant']."','".$data['GestanteFechEco3']."','".$data['GestanteObsEco3']."','".$data['GestanteNormEco3']."','".$data['GestanteColscopPl']."','".$data['GestanteFechEco4']."','".$data['GestanteObsEco4']."','".$data['GestanteNormEco4']."','".$data['GestanteFactProct']."','".$data['GestanteEstimFetal']."','".$data['GestanteLactMater']."','".$data['GestanteVincuAfec']."','".$data['GestantePreveAutom']."','".$data['GestanteConTaba']."','".$data['GestanteSignAlar']."','".$data['gestanteOtroEduInd']."','".$data['gestanteEntrPreTem1']."','".$data['gestanteEntrPreTem2']."','".$data['gestanteEntrPreTem3']."','".$data['gestanteEntrPreTem4']."','".$data['gestanteEntrPreTem5']."','".$data['gestanteEntrPreFec1']."','".$data['gestanteEntrPreFec2']."','".$data['gestanteEntrPreFec3']."','".$data['gestanteEntrPreFec4']."','".$data['gestanteEntrPreFec5']."','".$data['listadoCIEPa']."','".$data['tipoDiagnosPrinc']."','".$data['medAsigCons']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."','".$data['GestanteSexarquia']."', '".$data['BiopEdad']."', '".$data['BioPari']."', '".$data['abprhabinfer']."', '".$data['retencPlacent']."', '".$data['pesobebemayor']."', '".$data['pesobebemenor']."', '".$data['htaIndEmbara']."', '".$data['EmbaGemelarCesara']."', '".$data['mortinatoMuerto']."', '".$data['TPProlongada']."', '".$data['OXgineolgica']."', '".$data['EnferReanlCronic']."', '".$data['diabetGesta']."', '".$data['diabetesMellitus']."', '".$data['EnfermCardiaca']."', '".$data['EnfermedadInfeccios']."', '".$data['agudasBacterianas']."', '".$data['anemiaHB10gl']."', '".$data['hemorragia20ms']."', '".$data['vaginal2oss']."', '".$data['Epronlogadoante']."', '".$data['htaantecdepr']."', '".$data['anteRpm']."', '".$data['polidraminiosAntEmbaActual']."', '".$data['RCIUAntecente']."', '".$data['embMultipleatne']."', '".$data['MalaPresenta']."', '".$data['isoirh']."', '".$data['tipoIDUserReg']."','".$data['numeroIDUserReg']."','".$data['tipoid_pac']."','".$data['numid_pac']."')";
        
        $result = array();

        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {

            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';
            $result['SQL']=$sql;

        }

        return $result;

         




    }

   

}

