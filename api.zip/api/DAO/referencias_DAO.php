<?php



include '../db/Database.php';



class referencias_DAO {



    function __construct() {


    }

    public function listarReferencias(){

        $instance = Database::getInstance();


        if ($instance == NULL) {



            $db = new Database();

            $instance = $db->getInstance();



        }

        

        $sql = "SELECT * FROM referencias";



        $result = array();

        $res = $instance->get_data($sql);

        

        if ($res['STATUS']=='OK' ) {

            

            $result['DATA'] = $res['DATA'];

             $result['STATUS'] = 'OK';



        } else {



            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];



        }



        return $result;

    }



    



    public function registerReference($data){ 

        $instance = Database::getInstance();
        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();



        }
        

        $sql="INSERT INTO `referencias`(`idJSON`, `nombre_prestador`, `nit_prestador`, `codigo_prestador`, `direccion_prestador`, `munp_prestador`, `indTel_prestador`, `telefono_prestador`, `nombre_paciente`, `tipoid_paciente`, `numid_paciente`, `fechnac_paciente`, `direccion_paciente`, `dpto_paciente`, `mnpo_paciente`, `telefono_paciente`, `nombre_profesional`, `indTel_profesional`, `Tel_profesional`, `celular_profesional`, `sersolicita_profesional`, `serReferencia_profesional`, `anamnesis`, `ta`, `fc`, `fr`, `tem`, `peso`, `examen_fisico`, `exaAux`, `tipoexamen`, `hallazgos`, `fecahex`, `listadoCIEPa`, `complicaciones`, `tto_aplicados`, `motivo`, `estado`                                   ) VALUES ('".$data['idJSON']."', '".$data['nombre_prestador']."', '".$data['nit_prestador']."', '".$data['codigo_prestador']."', '".$data['direccion_prestador']."', '".$data['munp_prestador']."', '".$data['indTel_prestador']."', '".$data['telefono_prestador']."', '".$data['nombre_paciente']."', '".$data['tipoid_paciente']."', '".$data['numid_paciente']."', '".$data['fechnac_paciente']."', '".$data['direccion_paciente']."', '".$data['dpto_paciente']."', '".$data['mnpo_paciente']."', '".$data['telefono_paciente']."', '".$data['nombre_profesional']."', '".$data['indTel_profesional']."', '".$data['Tel_profesional']."', '".$data['celular_profesional']."', '".$data['sersolicita_profesional']."', '".$data['serReferencia_profesional']."', '".$data['anamnesis']."', '".$data['ta']."', '".$data['fc']."', '".$data['fr']."', '".$data['tem']."', '".$data['peso']."', '".$data['examen_fisico']."', '".$data['exaAux']."', '".$data['tipoexamen']."', '".$data['hallazgos']."', '".$data['fecahex']."', '".$data['listadoCIEPa']."', '".$data['complicaciones']."', '".$data['tto_aplicados']."', '".$data['motivo']."', '".$data['estado']."')";



        $result = array();



        $res = $instance->exec($sql);



        if ($res['STATUS']=='OK' ) {

            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];
        } else { 

            $result['STATUS'] = 'ERROR';
            $result['sql'] = $sql;

        }



        return $result;



        





    }

}