<?php



include_once '../DAO/procedimientos_DAO.php';


class procedimientos_DTO

{


	function __construct()



	{



		# code...



	}



	



	public function listarProcedimientos(){



		



		$inst= new procedimientos_DAO();



		$dataOut=$inst->listarProcedimientos();



		return $dataOut;



	} 



	public function registrarProcedimientos($data){

		$inst= new procedimientos_DAO();



		$dataOut=$inst->registrarProcedimientos($data);
		return $dataOut;



	} 

}