<?php



include '../db/Database.php';



class consultasG_DAO {



    function __construct() {

        

    }


    public function listarConsultasId($id){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT gr.* , pc.* FROM consultas_adulto gr, pacientes pc WHERE (pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac) AND id_consulta=".intVal($id)."";
        //$sql = "SELECT * FROM consultasEnfermeria";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }



    public function registerAdultConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }


        $data2=JSON_decode($data['data'], true);
       

        $sql="INSERT INTO `consultas_adulto`( `id_paciente`, `idJSON_consulta`, `fechaConsulta`, `horaConsulta`, `profAtiende`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `infecciosos`, `infecciosos_Desc`, `patologicos`, `patologicos_Desc`, `quirurgicos`, `quirurgicos_Desc`, `alergicos`, `alergicos_Desc`, `traumas`, `traumas_Desc`, `psicologicos`, `psicologicos_Desc`, `otros_Desc`, `gestaciones`, `partos`, `cesareas`, `abortos`, `vivos`, `muertos`, `observacionesGine`, `fecUltimaCitologia`, `planifica`, `planificaMetodo`, `observacionesAnte`, `tempEA`, `pulsoEA`, `pesoEA`, `tallaEA`, `imcEA`, `frecuenciarEA`, `tensionaEA`, `pielyfaneras`, `pielyfaneras_Desc`, `organosSentidos`, `organosSentidos_Desc`, `cavidadBucal`, `cavidadBucal_Desc`, `neurosensorial`, `neurosensorial_Desc`, `locomotor`, `locomotor_Desc`, `cardiovascular`, `cardiovascular_Desc`, `respiratorio`, `respiratorio_Desc`, `gastrointestinal`, `gastrointestinal_Desc`, `genitorunario`, `genitorunario_Desc`, `endoctrino`, `endoctrino_Desc`, `examama`, `examama_Desc`, `piel`, `piel_Desc`, `cabeza`, `cabeza_Desc`, `organosSentidosEA`, `organosSentidosEA_Desc`, `agudezavisual`, `agudezavisual_Desc`, `cavidadoral`, `cavidadoral_Desc`, `torax`, `torax_Desc`, `abdomen`, `abdomen_Desc`, `genitourinaria`, `genitourinaria_Desc`, `extremidades`, `extremidades_Desc`, `neurologico`, `neurologico_Desc`, `osteomuscular`, `osteomuscular_Desc`, `obserConsuAdulto`, `listadoCIEPa`, `tipoDiagnosPrinc`, `medAsigCons`, `ordenMedCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `tipoIDUserReg`, `numeroIDUserReg`, `tipoid_pac`, `numid_pac`, `IpsServicioReferir`, `IpsProcedeimientoReferir`) VALUES ('".$data2['id_paciente']."','".$data2['idJSON_consulta']."','".$data2['fechaConsulta']."','".$data2['horaConsulta']."','".$data2['profAtiende']."','".$data2['tipoConsulta']."','".$data2['finalidadConsulta']."','".$data2['causaExternaConsulta']."','".$data2['motivoConsulta']."','".$data2['enfermedadActualConsulta']."','".$data2['infecciosos']."','".$data2['infecciosos_Desc']."','".$data2['patologicos']."','".$data2['patologicos_Desc']."','".$data2['quirurgicos']."','".$data2['quirurgicos_Desc']."','".$data2['alergicos']."','".$data2['alergicos_Desc']."','".$data2['traumas']."','".$data2['traumas_Desc']."','".$data2['psicologicos']."','".$data2['psicologicos_Desc']."','".$data2['otros_Desc']."','".$data2['gestaciones']."','".$data2['partos']."','".$data2['cesareas']."','".$data2['abortos']."','".$data2['vivos']."','".$data2['muertos']."','".$data2['observacionesGine']."','".$data2['fecUltimaCitologia']."','".$data2['planifica']."','".$data2['planificaMetodo']."','".$data2['observacionesAnte']."','".$data2['tempEA']."','".$data2['pulsoEA']."','".$data2['pesoEA']."','".$data2['tallaEA']."','".$data2['imcEA']."','".$data2['frecuenciarEA']."','".$data2['tensionaEA']."','".$data2['pielyfaneras']."','".$data2['pielyfaneras_Desc']."','".$data2['organosSentidos']."','".$data2['organosSentidos_Desc']."','".$data2['cavidadBucal']."','".$data2['cavidadBucal_Desc']."','".$data2['neurosensorial']."','".$data2['neurosensorial_Desc']."','".$data2['locomotor']."','".$data2['locomotor_Desc']."','".$data2['cardiovascular']."','".$data2['cardiovascular_Desc']."','".$data2['respiratorio']."','".$data2['respiratorio_Desc']."','".$data2['gastrointestinal']."','".$data2['gastrointestinal_Desc']."','".$data2['genitorunario']."','".$data2['genitorunario_Desc']."','".$data2['endoctrino']."','".$data2['endoctrino_Desc']."','".$data2['examama']."','".$data2['examama_Desc']."','".$data2['piel']."','".$data2['piel_Desc']."','".$data2['cabeza']."','".$data2['cabeza_Desc']."','".$data2['organosSentidosEA']."','".$data2['organosSentidosEA_Desc']."','".$data2['agudezavisual']."','".$data2['agudezavisual_Desc']."','".$data2['cavidadoral']."','".$data2['cavidadoral_Desc']."','".$data2['torax']."','".$data2['torax_Desc']."','".$data2['abdomen']."','".$data2['abdomen_Desc']."','".$data2['genitourinaria']."','".$data2['genitourinaria_Desc']."','".$data2['extremidades']."','".$data2['extremidades_Desc']."','".$data2['neurologico']."','".$data2['neurologico_Desc']."','".$data2['osteomuscular']."','".$data2['osteomuscular_Desc']."','".$data2['obserConsuAdulto']."','".$data2['listadoCIEPa']."','".$data2['tipoDiagnosPrinc']."','".$data2['medAsigCons']."','".$data2['ordenMedCons']."','".$data2['ordenMedConsRef']."','".$data2['ordenMedConsRefPro']."','".$data2['tipoSerRef']."','".$data2['obseSerRef']."','".$data2['tipoIDUserReg']."','".$data2['numeroIDUserReg']."','".$data2['tipoid_pac']."','".$data2['numid_pac']."','".$data2['IpsServicioReferir']."','".$data2['IpsProcedeimientoReferir']."')";
        //$sql="INSERT INTO adult_consultation(data, id_paciente, idJSON_paciente, numid_pac, tipoid_pac, institucion) VALUES ('".$data['data']."','".$data['id_paciente']."','".$data['idJSON_paciente']."','".$data['numid_pac']."','".$data['tipoid_pac']."','".$data['institucion']."')";
		 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updateAdultConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE adult_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

  



    public function listarConsultas(){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        
        $sql = "SELECT gr.* , pc.nombres, pc.papellido, pc.sapellido FROM consultas_adulto gr, pacientes pc WHERE pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac";

        $result = array();



        $res = $instance->get_data($sql);

     

        if ($res['STATUS']=='OK' ) {

           

            $result['DATA'] = $res['DATA'];



            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }
    public function listarConsultasPaciente($tipoid, $numid ){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        
        $sql = "SELECT gr.* FROM adult_consultation gr WHERE gr.tipoid_pac='".$tipoid."' AND gr.numid_pac='".$numid."'";

        $result = array();



        $res = $instance->get_data($sql);

     

        if ($res['STATUS']=='OK' ) {

           

            $result['DATA'] = $res['DATA'];



            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }
    public function listarConsultasG(){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        

        $sql = "SELECT * FROM consultasg";

        $result = array();



        $res = $instance->get_data($sql);

     

        if ($res['STATUS']=='OK' ) {

           

            $result['DATA'] = $res['DATA'];



            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }

    

    public function registrarConsultasG($data){

        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultasg (id_paciente, idJSON, fechaConsulta, profAtiende, tipoConsulta, finalidadConsulta, causaExternaConsulta, motivoConsulta, enfermedadActualConsulta, antecedentesConsulta, infecciosos, infecciosos_Desc, patologicos, patologicos_Desc, quirurgicos, quirurgicos_Desc, alergicos, alergicos_Desc, traumas, traumas_Desc, psicologicos, psicologicos_Desc, otros_Desc, gestaciones, partos, cesareas, abortos, vivos, muertos, observacionesGine, fecUltimaCitologia, planifica, planificaMetodo, observacionesAnte, tempEA, pulsoEA, pesoEA, tallaEA, imcEA, frecuenciarEA, tensionaEA, pielyfaneras, pielyfaneras_Desc, organosSentidos, organosSentidos_Desc, cavidadBucal, cavidadBucal_Desc, neurosensorial, neurosensorial_Desc, locomotor, locomotor_Desc, cardiovascular, cardiovascular_Desc, respiratorio, respiratorio_Desc, gastrointestinal, gastrointestinal_Desc, genitorunario, genitorunario_Desc, endoctrino, endoctrino_Desc, examama, examama_Desc, piel, piel_Desc, cabeza, cabeza_Desc, organosSentidosEA, organosSentidosEA_Desc, agudezavisual, agudezavisual_Desc, cavidadoral, cavidadoral_Desc, torax, torax_Desc, abdomen, abdomen_Desc, genitourinaria, genitourinaria_Desc, extremidades, extremidades_Desc, neurologico, neurologico_Desc, osteomuscular, osteomuscular_Desc, listadoCIEPa, tipoDiagnosPrinc, medAsigCons, OrdAsigCons, ordenMedConsRef, ordenMedConsRefPro, tipoSerRef, obseSerRef, tipoIDUserReg, numeroIDUserReg, tipoid_pac, numid_pac)  VALUES (".$data['id_paciente'].", '".$data['idJSON']."', '".$data['fechaConsulta']."', '".$data['profAtiende']."', '".$data['tipoConsulta']."', '".$data['finalidadConsulta']."', '".$data['causaExternaConsulta']."', '".$data['motivoConsulta']."', '".$data['enfermedadActualConsulta']."', '".$data['antecedentesConsulta']."', '".$data['infecciosos']."', '".$data['infecciosos_Desc']."', '".$data['patologicos']."', '".$data['patologicos_Desc']."', '".$data['quirurgicos']."', '".$data['quirurgicos_Desc']."', '".$data['alergicos']."', '".$data['alergicos_Desc']."', '".$data['traumas']."', '".$data['traumas_Desc']."', '".$data['psicologicos']."', '".$data['psicologicos_Desc']."', '".$data['otros_Desc']."', '".$data['gestaciones']."', '".$data['partos']."', '".$data['cesareas']."', '".$data['abortos']."', '".$data['vivos']."', '".$data['muertos']."', '".$data['observacionesGine']."', '".$data['fecUltimaCitologia']."', '".$data['planifica']."', '".$data['planificaMetodo']."', '".$data['observacionesAnte']."', '".$data['tempEA']."', '".$data['pulsoEA']."', '".$data['pesoEA']."', '".$data['tallaEA']."', '".$data['imcEA']."', '".$data['frecuenciarEA']."', '".$data['tensionaEA']."', '".$data['pielyfaneras']."', '".$data['pielyfaneras_Desc']."', '".$data['organosSentidos']."', '".$data['organosSentidos_Desc']."', '".$data['cavidadBucal']."', '".$data['cavidadBucal_Desc']."', '".$data['neurosensorial']."', '".$data['neurosensorial_Desc']."', '".$data['locomotor']."', '".$data['locomotor_Desc']."', '".$data['cardiovascular']."', '".$data['cardiovascular_Desc']."', '".$data['respiratorio']."', '".$data['respiratorio_Desc']."', '".$data['gastrointestinal']."', '".$data['gastrointestinal_Desc']."', '".$data['genitorunario']."', '".$data['genitorunario_Desc']."', '".$data['endoctrino']."', '".$data['endoctrino_Desc']."', '".$data['examama']."', '".$data['examama_Desc']."', '".$data['piel']."', '".$data['piel_Desc']."', '".$data['cabeza']."', '".$data['cabeza_Desc']."', '".$data['organosSentidosEA']."', '".$data['organosSentidosEA_Desc']."', '".$data['agudezavisual']."', '".$data['agudezavisual_Desc']."', '".$data['cavidadoral']."', '".$data['cavidadoral_Desc']."', '".$data['torax']."', '".$data['torax_Desc']."', '".$data['abdomen']."', '".$data['abdomen_Desc']."', '".$data['genitourinaria']."', '".$data['genitourinaria_Desc']."', '".$data['extremidades']."', '".$data['extremidades_Desc']."', '".$data['neurologico']."', '".$data['neurologico_Desc']."', '".$data['osteomuscular']."', '".$data['osteomuscular_Desc']."', '".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."','".$data['medAsigCons']."', '".$data['ordenMedConsRef']."', '".$data['ordenMedConsRefPro']."', '".$data['tipoSerRef']."', '".$data['obseSerRef']."', '".$data['ordenMedCons']."', '".$data['tipoIDUserReg']."', '".$data['numeroIDUserReg']."', '".$data['tipoid_pac']."', '".$data['numid_pac']."');";

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


    
    public function registrarConsultasAdulto($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO `consultas_adulto`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `fecha`, `id_registra`, `tipoid_registra`, `institucion`) VALUES ('".$data['idJSON_consulta']."', '".$data['id_paciente']."', '".$data['idJSON_paciente']."', '".$data['numid_pac']."', '".$data['tipoid_pac']."', '".$data['fecha']."', '".$data['id_registra']."', '".$data['tipoid_registra']."', '".$data['institucion']."')";
    
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasAdultoA($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_adultoA(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `profAtiende`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `antecedentesConsulta`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['tipoConsulta']."','".$data['finalidadConsulta']."','".$data['causaExternaConsulta']."','".$data['motivoConsulta']."','".$data['enfermedadActualConsulta']."','".$data['antecedentesConsulta']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasAdultoB($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_adultoB( `idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `infecciosos`, `infecciosos_Desc`, `patologicos`, `patologicos_Desc`, `quirurgicos`, `quirurgicos_Desc`, `alergicos`, `alergicos_Desc`, `traumas`, `traumas_Desc`, `psicologicos`, `psicologicos_Desc`, `otros_Desc`, `gestaciones`, `partos`, `cesareas`, `abortos`, `vivos`, `muertos`, `observacionesGine`, `fecUltimaCitologia`, `planifica`, `planificaMetodo`, `observacionesAnte`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."', '".$data['infecciosos']."', '".$data['infecciosos_Desc']."', '".$data['patologicos']."', '".$data['patologicos_Desc']."', '".$data['quirurgicos']."', '".$data['quirurgicos_Desc']."', '".$data['alergicos']."', '".$data['alergicos_Desc']."', '".$data['traumas']."', '".$data['traumas_Desc']."', '".$data['psicologicos']."', '".$data['psicologicos_Desc']."', '".$data['otros_Desc']."', '".$data['gestaciones']."', '".$data['partos']."', '".$data['cesareas']."', '".$data['abortos']."', '".$data['vivos']."', '".$data['muertos']."', '".$data['observacionesGine']."', '".$data['fecUltimaCitologia']."', '".$data['planifica']."', '".$data['planificaMetodo']."', '".$data['observacionesAnte']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

    public function registrarConsultasAdultoC($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_adultoC(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`,  `tempEA`, `pulsoEA`, `pesoEA`, `tallaEA`, `imcEA`, `frecuenciarEA`, `tensionaEA`, `pielyfaneras`, `pielyfaneras_Desc`, `organosSentidos`, `organosSentidos_Desc`, `cavidadBucal`, `cavidadBucal_Desc`, `neurosensorial`, `neurosensorial_Desc`, `locomotor`, `locomotor_Desc`, `cardiovascular`, `cardiovascular_Desc`, `respiratorio`, `respiratorio_Desc`, `gastrointestinal`, `gastrointestinal_Desc`, `genitorunario`, `genitorunario_Desc`, `endoctrino`, `endoctrino_Desc`, `examama`, `examama_Desc`, `piel`, `piel_Desc`, `cabeza`, `cabeza_Desc`, `organosSentidosEA`, `organosSentidosEA_Desc`, `agudezavisual`, `agudezavisual_Desc`, `cavidadoral`, `cavidadoral_Desc`, `torax`, `torax_Desc`, `abdomen`, `abdomen_Desc`, `genitourinaria`, `genitourinaria_Desc`, `extremidades`, `extremidades_Desc`, `neurologico`, `neurologico_Desc`, `osteomuscular`, `osteomuscular_Desc`, `observacionesExam`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['tempEA']."', '".$data['pulsoEA']."', '".$data['pesoEA']."', '".$data['tallaEA']."', '".$data['imcEA']."', '".$data['frecuenciarEA']."', '".$data['tensionaEA']."', '".$data['pielyfaneras']."', '".$data['pielyfaneras_Desc']."', '".$data['organosSentidos']."', '".$data['organosSentidos_Desc']."', '".$data['cavidadBucal']."', '".$data['cavidadBucal_Desc']."', '".$data['neurosensorial']."', '".$data['neurosensorial_Desc']."', '".$data['locomotor']."', '".$data['locomotor_Desc']."', '".$data['cardiovascular']."', '".$data['cardiovascular_Desc']."', '".$data['respiratorio']."', '".$data['respiratorio_Desc']."', '".$data['gastrointestinal']."', '".$data['gastrointestinal_Desc']."', '".$data['genitorunario']."', '".$data['genitorunario_Desc']."', '".$data['endoctrino']."', '".$data['endoctrino_Desc']."', '".$data['examama']."', '".$data['examama_Desc']."', '".$data['piel']."', '".$data['piel_Desc']."', '".$data['cabeza']."', '".$data['cabeza_Desc']."', '".$data['organosSentidosEA']."', '".$data['organosSentidosEA_Desc']."', '".$data['agudezavisual']."', '".$data['agudezavisual_Desc']."', '".$data['cavidadoral']."', '".$data['cavidadoral_Desc']."', '".$data['torax']."', '".$data['torax_Desc']."', '".$data['abdomen']."', '".$data['abdomen_Desc']."', '".$data['genitourinaria']."', '".$data['genitourinaria_Desc']."', '".$data['extremidades']."', '".$data['extremidades_Desc']."', '".$data['neurologico']."', '".$data['neurologico_Desc']."', '".$data['osteomuscular']."', '".$data['osteomuscular_Desc']."','".$data['obserConsuAdulto']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasAdultoD($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_adultoD(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `listadoCIEPa`,`tipoDiagnosPrinc`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."')";
        
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasAdultoE($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_adultoE(  `idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `medAsigCons`, `notasEvolucion`, `recomNotas`, `OrdAsigCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['medAsigCons']."','".$data['notasEvolucion']."','".$data['recomNotas']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."')";
        
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


    public function actualizarConsultaG($data){

        

        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE consultasg SET fechaConsulta='".$data['fechaConsulta']."',profAtiende='".$data['profAtiende']."',

        tipoConsulta='".$data['tipoConsulta']."',finalidadConsulta='".$data['finalidadConsulta']."',causaExternaConsulta='".$data['causaExternaConsulta']."',

        motivoConsulta='".$data['motivoConsulta']."',enfermedadActualConsulta='".$data['enfermedadActualConsulta']."',antecedentesConsulta='".$data['antecedentesConsulta']."',

        infecciosos='".$data['infecciosos']."',infecciosos_Desc='".$data['infecciosos_Desc']."',patologicos='".$data['patologicos']."',

        patologicos_Desc='".$data['patologicos_Desc']."',quirurgicos='".$data['quirurgicos']."',quirurgicos_Desc='".$data['quirurgicos_Desc']."',

        alergicos='".$data['alergicos']."',alergicos_Desc='".$data['alergicos_Desc']."',traumas='".$data['traumas']."',traumas_Desc='".$data['traumas_Desc']."',

        psicologicos='".$data['psicologicos']."',psicologicos_Desc='".$data['psicologicos_Desc']."',otros_Desc='".$data['otros_Desc']."',gestaciones='".$data['gestaciones']."',

        partos='".$data['partos']."',cesareas='".$data['cesareas']."',abortos='".$data['abortos']."',vivos='".$data['vivos']."',muertos='".$data['muertos']."',

        observacionesGine='".$data['observacionesGine']."',fecUltimaCitologia='".$data['fecUltimaCitologia']."',planifica='".$data['planifica']."',planificaMetodo='".$data['planificaMetodo']."',

        observacionesAnte='".$data['observacionesAnte']."',tempEA='".$data['tempEA']."',pulsoEA='".$data['pulsoEA']."',pesoEA='".$data['pesoEA']."',tallaEA='".$data['tallaEA']."',

        imcEA='".$data['imcEA']."',frecuenciarEA='".$data['frecuenciarEA']."',tensionaEA='".$data['tensionaEA']."',pielyfaneras='".$data['pielyfaneras']."',

        pielyfaneras_Desc='".$data['pielyfaneras_Desc']."',organosSentidos='".$data['organosSentidos']."',organosSentidos_Desc='".$data['organosSentidos_Desc']."',

        cavidadBucal='".$data['cavidadBucal']."',cavidadBucal_Desc='".$data['cavidadBucal_Desc']."',neurosensorial='".$data['neurosensorial']."',

        neurosensorial_Desc='".$data['neurosensorial_Desc']."',locomotor='".$data['locomotor']."',locomotor_Desc='".$data['locomotor_Desc']."',

        cardiovascular='".$data['cardiovascular']."',cardiovascular_Desc='".$data['cardiovascular_Desc']."',respiratorio='".$data['respiratorio']."',

        respiratorio_Desc='".$data['respiratorio_Desc']."',gastrointestinal='".$data['gastrointestinal']."',gastrointestinal_Desc='".$data['gastrointestinal_Desc']."',

        genitorunario='".$data['genitorunario']."',genitorunario_Desc='".$data['genitorunario_Desc']."',endoctrino='".$data['endoctrino']."',

        endoctrino_Desc='".$data['endoctrino_Desc']."',examama='".$data['examama']."',examama_Desc='".$data['examama_Desc']."',piel='".$data['piel']."',

        piel_Desc='".$data['piel_Desc']."',cabeza='".$data['cabeza']."',cabeza_Desc='".$data['cabeza_Desc']."',organosSentidosEA='".$data['organosSentidosEA']."',

        organosSentidosEA_Desc='".$data['organosSentidosEA_Desc']."',agudezavisual='".$data['agudezavisual']."',agudezavisual_Desc='".$data['agudezavisual_Desc']."',

        cavidadoral='".$data['cavidadoral']."',cavidadoral_Desc='".$data['cavidadoral_Desc']."',torax='".$data['torax']."',torax_Desc='".$data['torax_Desc']."',

        abdomen='".$data['abdomen']."',abdomen_Desc='".$data['abdomen_Desc']."',genitourinaria='".$data['genitourinaria']."',genitourinaria_Desc='".$data['genitourinaria_Desc']."',

        extremidades='".$data['extremidades']."',extremidades_Desc='".$data['extremidades_Desc']."',neurologico='".$data['neurologico']."',neurologico_Desc='".$data['neurologico_Desc']."',

        osteomuscular='".$data['osteomuscular']."',osteomuscular_Desc='".$data['osteomuscular_Desc']."',listadoCIEPa='".$data['listadoCIEPa']."',medAsigCons='".$data['medAsigCons']."',

        OrdAsigCons='".$data['ordenMedCons']."' WHERE id_consulta=".$data['id']."";

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

    

    public function EliminarConsultaG($data){

        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="DELETE FROM consultasg WHERE id_consulta=".$data."";

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

   

}

