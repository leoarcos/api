<?php

include '../db/Database.php';

class usuarios_DAO {

    function __construct() {
        
    }

  

    public function listarUsuarios($inst){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        //$sql = "SELECT * FROM usuarios WHERE institucion='".$inst."'";
        $sql = "SELECT * FROM usuarios";
        $result = array();
        $res = $instance->get_data($sql);
        if ($res['STATUS']=="OK" ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
        }
        return $result;
        

    }

    public function listarUsuario($data){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql = "SELECT * FROM usuarios WHERE user='".$data['user']."' AND pass='".$data['pass']."'";
        $result = array();
        $res = $instance->get_data($sql);
        if ($res['STATUS']=="OK" ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
        }
        return $result;
        

    } 
    public function registrarUsuario($data){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
        $sql="INSERT INTO usuarios(tipoid, numid, nombres, profesion, reg_prof, institucion, user, pass, direccion, permiso_agendar, permiso_hamb, permiso_procedimientos, permiso_informes, permiso_usuarios) VALUES('".$data['tipoid']."', '".$data['numid']."', '".$data['nombres']."', '".$data['profesion']."', '".$data['reg_prof']."', '".$data['institucion']."', '".$data['user']."', '".$data['pass']."', '".$data['direccion']."', ".$data['permiso_agendar'].", ".$data['permiso_registro'].", ".$data['permiso_procedimientos'].", ".$data['permiso_informes'].", ".$data['permiso_usuarios'].") "; 
        $result = array();
        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID']; 
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    }
     
   
   
}
