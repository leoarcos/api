<?php



include '../db/Database.php';



class consultasM_DAO {



    function __construct() {

        

    }
    public function listarConsultasId($id){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT gr.* , pc.nombres, pc.* FROM consultas_menor gr, pacientes pc WHERE (pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac) AND id_consulta=".intVal($id)."";
        //$sql = "SELECT * FROM consultasEnfermeria";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }
    public function registerMenorConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        $data2=JSON_decode($data['data'], true);
       


        $sql="INSERT INTO `consultas_menor`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `tipoIDUserReg`, `numeroIDUserReg`, `institucion`, `id_registra`, `tipoid_registra`, `fechaConsulta`,  `profAtiende`, `MenornombreAcompana`, `MenorAcompanaTelefono`, `MenorparentezcoAcompana`, `Menornombremadre`, `Menornombrepadre`, `MenortipoConsulta`, `MenorfinalidadConsulta`, `MenorcausaExternaConsulta`, `MenormotivoConsulta`, `MenorenfermedadActualConsulta`,   `Menorembarazodesado`, `MenoredadGestacional`, `Menorpatologiasembarazo`, `MenorPesonacer`, `Menortallanacer`, `MenorApgar1min`, `MenorApgar5min`, `MenorpatologiaReciennacido`, `MenorpartoIns`, `MenorProductoUnico`, `MenorTipoParto`, `MenorEdadMadreNacer`, `MenorAlimentacion`, `MenorOtrasleches`, `MenorComplementaria`, `MenorNumhermanos`, `MenorNumhermanosvivos`, `MenorNumhermanosMuertos`, `MenorPatologiasfamiliares`, `MenortempEA`, `MenorpulsoEA`, `MenorpesoEA`, `MenortallaEA`, `MenorimcEA`, `MenorfrecuenciarEA`, `MenorPerimetroCefalico`, `Menorcabeza`, `Menorcabeza_Desc`, `MenorOjos`, `MenorOjos_Desc`, `MenorNariz`, `MenorNariz_Desc`, `MenorOidos`, `MenorOidos_Desc`, `MenorBoca`, `MenorBoca_Desc`, `Menorcuello`, `Menorcuello_Desc`, `MenorcardioRespirat`, `MenorcardioRespirat_Desc`, `Menorabdomen`, `Menorabdomen_Desc`, `Menorgenitourinario`, `Menorgenitourinario_Desc`, `MenorAno`, `MenorAno_Desc`, `MenorExtremidades`, `MenorExtremidades_Desc`, `Menorpiel`, `Menorpiel_Desc`, `Menorsistemanervioso`, `Menorsistemanervioso_Desc`, `MenordolorMascar`, `MenortraumaBoca`, `MenorLimpiamanana`, `MenorLimpiamedioDia`, `MenorLimpiaNoche`, `MenorLimpiaDientesSolo`, `MenorusaCepillo`, `MenorusaCrema`, `MenorusaSeda`, `MenorusaChupoB`, `MenorfechaUConsOdo`, `Menorpesoedad02`, `Menorpesoedad25`, `Menortallaedad018`, `Menorpesotalla018`, `Menorimc05`, `Menorimc518`, `MenorperimetroCefalicoEV`, `MenorTendenciaPeso`, `MenorHemoclasificacion`, `MenorSerologia`, `MenorHipotiroidismo`, `listadoCIEPa`, `tipoDiagnosPrinc`, `medAsigCons`, `ordenMedCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `tipoid_pac`, `numid_pac`, `IpsServicioReferir`, `IpsProcedeimientoReferir`) VALUES ('".$data2['idJSON_consulta']."','".$data2['id_paciente']."','".$data2['idJSON_paciente']."','".$data2['tipoIDUserReg']."','".$data2['numeroIDUserReg']."','".$data2['institucion']."','".$data2['id_registra']."','".$data2['tipoid_registra']."','".$data2['fechaConsulta']."','".$data2['profAtiende']."','".$data2['MenornombreAcompana']."','".$data2['MenorAcompanaTelefono']."','".$data2['MenorparentezcoAcompana']."','".$data2['Menornombremadre']."','".$data2['Menornombrepadre']."','".$data2['MenortipoConsulta']."','".$data2['MenorfinalidadConsulta']."','".$data2['MenorcausaExternaConsulta']."','".$data2['MenormotivoConsulta']."','".$data2['MenorenfermedadActualConsulta']."','".$data2['Menorembarazodesado']."','".$data2['MenoredadGestacional']."','".$data2['Menorpatologiasembarazo']."','".$data2['MenorPesonacer']."','".$data2['Menortallanacer']."','".$data2['MenorApgar1min']."','".$data2['MenorApgar5min']."','".$data2['MenorpatologiaReciennacido']."','".$data2['MenorpartoIns']."','".$data2['MenorProductoUnico']."','".$data2['MenorTipoParto']."','".$data2['MenorEdadMadreNacer']."','".$data2['MenorAlimentacion']."','".$data2['MenorOtrasleches']."','".$data2['MenorComplementaria']."','".$data2['MenorNumhermanos']."','".$data2['MenorNumhermanosvivos']."','".$data2['MenorNumhermanosMuertos']."','".$data2['MenorPatologiasfamiliares']."','".$data2['MenortempEA']."','".$data2['MenorpulsoEA']."','".$data2['MenorpesoEA']."','".$data2['MenortallaEA']."','".$data2['MenorimcEA']."','".$data2['MenorfrecuenciarEA']."','".$data2['MenorPerimetroCefalico']."','".$data2['Menorcabeza']."','".$data2['Menorcabeza_Desc']."','".$data2['MenorOjos']."','".$data2['MenorOjos_Desc']."','".$data2['MenorNariz']."','".$data2['MenorNariz_Desc']."','".$data2['MenorOidos']."','".$data2['MenorOidos_Desc']."','".$data2['MenorBoca']."','".$data2['MenorBoca_Desc']."','".$data2['Menorcuello']."','".$data2['Menorcuello_Desc']."','".$data2['MenorcardioRespirat']."','".$data2['MenorcardioRespirat_Desc']."','".$data2['Menorabdomen']."','".$data2['Menorabdomen_Desc']."','".$data2['Menorgenitourinario']."','".$data2['Menorgenitourinario_Desc']."','".$data2['MenorAno']."','".$data2['MenorAno_Desc']."','".$data2['MenorExtremidades']."','".$data2['MenorExtremidades_Desc']."','".$data2['Menorpiel']."','".$data2['Menorpiel_Desc']."','".$data2['Menorsistemanervioso']."','".$data2['Menorsistemanervioso_Desc']."','".$data2['MenordolorMascar']."','".$data2['MenortraumaBoca']."','".$data2['MenorLimpiamanana']."','".$data2['MenorLimpiamedioDia']."','".$data2['MenorLimpiaNoche']."','".$data2['MenorLimpiaDientesSolo']."','".$data2['MenorusaCepillo']."','".$data2['MenorusaCrema']."','".$data2['MenorusaSeda']."','".$data2['MenorusaChupoB']."','".$data2['MenorfechaUConsOdo']."','".$data2['Menorpesoedad02']."','".$data2['Menorpesoedad25']."','".$data2['Menortallaedad018']."','".$data2['Menorpesotalla018']."','".$data2['Menorimc05']."','".$data2['Menorimc518']."','".$data2['MenorperimetroCefalicoEV']."','".$data2['MenorTendenciaPeso']."','".$data2['MenorHemoclasificacion']."','".$data2['MenorSerologia']."','".$data2['MenorHipotiroidismo']."','".$data2['listadoCIEPa']."','".$data2['tipoDiagnosPrinc']."','".$data2['medAsigCons']."','".$data2['ordenMedCons']."','".$data2['ordenMedConsRef']."','".$data2['ordenMedConsRefPro']."','".$data2['tipoSerRef']."','".$data2['obseSerRef']."','".$data2['tipoid_pac']."','".$data2['numid_pac']."','".$data2['IpsServicioReferir']."','".$data2['IpsProcedeimientoReferir']."')";
       // $sql="INSERT INTO menor_consultation(data, id_paciente, idJSON_paciente, numid_pac, tipoid_pac, institucion) VALUES ('".$data['data']."','".$data['id_paciente']."','".$data['idJSON_paciente']."','".$data['numid_pac']."','".$data['tipoid_pac']."','".$data['institucion']."')";

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updateMenorConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE menor_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


  



    public function listarConsultasM(){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        

        $sql = "SELECT * FROM consultasm";

        $result = array();



        $res = $instance->get_data($sql);

     

        if ($res['STATUS']=='OK' ) {

           

            $result['DATA'] = $res['DATA'];



            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }


    public function listarConsultas(){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        
        $sql = "SELECT gr.* , pc.nombres, pc.papellido, pc.sapellido FROM consultas_menor gr, pacientes pc WHERE pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac";

        $result = array();



        $res = $instance->get_data($sql);

     

        if ($res['STATUS']=='OK' ) {

           

            $result['DATA'] = $res['DATA'];



            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }
    public function listarConsultasPaciente($tipoid, $numid ){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        
        $sql = "SELECT gr.* FROM menor_consultation gr WHERE gr.tipoid_pac='".$tipoid."' AND gr.numid_pac='".$numid."'";

        $result = array();



        $res = $instance->get_data($sql);

     

        if ($res['STATUS']=='OK' ) {

           

            $result['DATA'] = $res['DATA'];



            $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];

        }

        return $result;

        



    }

    

    public function registrarConsultasM($data){

        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO `consultasm`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `MenorfechaConsulta`, `MenorhoraConsulta`, `MenorprofAtiende`, `MenorprofesionAtiende`, `MenorRegprofesionAtiende`,`MenornombreAcompana`, `MenorAcompanaTelefono`, `MenorparentezcoAcompana`, `Menornombremadre`, `Menornombrepadre`, `MenortipoConsulta`, `MenorfinalidadConsulta`, `MenorcausaExternaConsulta`, `MenormotivoConsulta`, `MenorenfermedadActualConsulta`,`MenorantecedentesConsulta`, `Menorembarazodesado`, `MenoredadGestacional`, `Menorpatologiasembarazo`, `MenorPesonacer`, `Menortallanacer`, `MenorApgar1min`,`MenorApgar5min`, `MenorpatologiaReciennacido`, `MenorpartoIns`, `MenorProductoUnico`,`MenorTipoParto`, `MenorEdadMadreNacer`, `MenorAlimentacion`, `MenorOtrasleches`, `MenorComplementaria`, `MenorNumhermanos`, `MenorNumhermanosvivos`, `MenorNumhermanosMuertos`,`MenorPatologiasfamiliares`, `MenortempEA`, `MenorpulsoEA`, `MenorpesoEA`, `MenortallaEA`,`MenorimcEA`, `MenorfrecuenciarEA`, `MenorPerimetroCefalico`, `Menorcabeza`, `Menorcabeza_Desc`, `MenorOjos`, `MenorOjos_Desc`, `MenorNariz`, `MenorNariz_Desc`, `MenorOidos`, `MenorOidos_Desc`,`MenorBoca`, `MenorBoca_Desc`, `Menorcuello`, `Menorcuello_Desc`, `MenorcardioRespirat`,`MenorcardioRespirat_Desc`, `Menorabdomen`, `Menorabdomen_Desc`, `Menorgenitourinario`,`Menorgenitourinario_Desc`, `MenorAno`, `MenorAno_Desc`, `MenorExtremidades`,`MenorExtremidades_Desc`, `Menorpiel`, `Menorpiel_Desc`, `Menorsistemanervioso`,`Menorsistemanervioso_Desc`, `MenordolorMascar`, `MenortraumaBoca`, `MenorLimpiamanana`,`MenorLimpiamedioDia`, `MenorLimpiaNoche`, `MenorLimpiaDientesSolo`, `MenorusaCepillo`,`MenorusaCrema`, `MenorusaSeda`, `MenorusaChupoB`, `MenorfechaUConsOdo`, `Menorpesoedad02`,`Menorpesoedad25`, `Menortallaedad018`, `Menorpesotalla018`, `Menorimc05`, `Menorimc518`,`MenorperimetroCefalicoEV`, `MenorTendenciaPeso`,`MenorHemoclasificacion`,`MenorSerologia`,`MenorHipotiroidismo`, `listadoCIEPaMenor`, `tipoDiagnosPrinc`, `medAsigConsMenor`, `ordenMedConsMenor`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `tipoid_pac`, `numid_pac`) VALUES (".intVal($data['idJSON_consulta']).", ".intVal($data['id_paciente']).", ".intVal($data['idJSON_paciente']).",'".$data['MenorfechaConsulta']."', '".$data['MenorhoraConsulta']."','".$data['MenorprofAtiende']."', '".$data['MenorprofesionAtiende']."', '".$data['MenorRegprofesionAtiende']."','".$data['MenornombreAcompana']."', '".$data['MenorAcompanaTelefono']."', '".$data['MenorparentezcoAcompana']."','".$data['Menornombremadre']."','".$data['Menornombrepadre']."', '".$data['MenortipoConsulta']."', '".$data['MenorfinalidadConsulta']."','".$data['MenorcausaExternaConsulta']."', '".$data['MenormotivoConsulta']."', '".$data['MenorenfermedadActualConsulta']."','".$data['MenorantecedentesConsulta']."', '".$data['Menorembarazodesado']."', '".$data['MenoredadGestacional']."','".$data['Menorpatologiasembarazo']."', '".$data['MenorPesonacer']."', '".$data['Menortallanacer']."','".$data['MenorApgar1min']."', '".$data['MenorApgar5min']."', '".$data['MenorpatologiaReciennacido']."','".$data['MenorpartoIns']."', '".$data['MenorProductoUnico']."', '".$data['MenorTipoParto']."','".$data['MenorEdadMadreNacer']."', '".$data['MenorAlimentacion']."', '".$data['MenorOtrasleches']."','".$data['MenorComplementaria']."', '".$data['MenorNumhermanos']."', '".$data['MenorNumhermanosvivos']."','".$data['MenorNumhermanosMuertos']."', '".$data['MenorPatologiasfamiliares']."', '".$data['MenortempEA']."','".$data['MenorpulsoEA']."', '".$data['MenorpesoEA']."', '".$data['MenortallaEA']."','".$data['MenorimcEA']."', '".$data['MenorfrecuenciarEA']."', '".$data['MenorPerimetroCefalico']."','".$data['Menorcabeza']."', '".$data['Menorcabeza_Desc']."', '".$data['MenorOjos']."','".$data['MenorOjos_Desc']."', '".$data['MenorNariz']."', '".$data['MenorNariz_Desc']."', '".$data['MenorOidos']."','".$data['MenorOidos_Desc']."', '".$data['MenorBoca']."', '".$data['MenorBoca_Desc']."','".$data['Menorcuello']."', '".$data['Menorcuello_Desc']."', '".$data['MenorcardioRespirat']."','".$data['MenorcardioRespirat_Desc']."', '".$data['Menorabdomen']."', '".$data['Menorabdomen_Desc']."','".$data['Menorgenitourinario']."', '".$data['Menorgenitourinario_Desc']."', '".$data['MenorAno']."','".$data['MenorAno_Desc']."', '".$data['MenorExtremidades']."', '".$data['MenorExtremidades_Desc']."','".$data['Menorpiel']."', '".$data['Menorpiel_Desc']."', '".$data['Menorsistemanervioso']."','".$data['Menorsistemanervioso_Desc']."', '".$data['MenordolorMascar']."', '".$data['MenortraumaBoca']."','".$data['MenorLimpiamanana']."', '".$data['MenorLimpiamedioDia']."', '".$data['MenorLimpiaNoche']."','".$data['MenorLimpiaDientesSolo']."', '".$data['MenorusaCepillo']."', '".$data['MenorusaCrema']."','".$data['MenorusaSeda']."', '".$data['MenorusaChupoB']."', '".$data['MenorfechaUConsOdo']."','".$data['Menorpesoedad02']."', '".$data['Menorpesoedad25']."', '".$data['Menortallaedad018']."','".$data['Menorpesotalla018']."', '".$data['Menorimc05']."', '".$data['Menorimc518']."','".$data['MenorperimetroCefalicoEV']."', '".$data['MenorTendenciaPeso']."', '".$data['MenorHemoclasificacion']."','".$data['MenorSerologia']."', '".$data['MenorHipotiroidismo']."', '".$data['listadoCIEPaMenor']."','".$data['tipoDiagnosPrinc']."','".$data['medAsigConsMenor']."', '".$data['ordenMedConsMenor']."', '".$data['ordenMedConsRef']."', '".$data['ordenMedConsRefPro']."', '".$data['tipoSerRef']."', '".$data['obseSerRef']."', '".$data['tipoid_pac']."', '".$data['numid_pac']."')";

       

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


    public function registrarConsultasMenor($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO `consultas_menor`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `fecha`, `id_registra`, `tipoid_registra`, `institucion`) VALUES ('".$data['idJSON_consulta']."', '".$data['id_paciente']."', '".$data['idJSON_paciente']."', '".$data['numid_pac']."', '".$data['tipoid_pac']."', '".$data['fecha']."', '".$data['id_registra']."', '".$data['tipoid_registra']."', '".$data['institucion']."')";
    
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasMenorA($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_menorA(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `profAtiende`,  `MenornombreAcompana`, `MenorAcompanaTelefono`, `MenorparentezcoAcompana`, `Menornombremadre`, `Menornombrepadre`, `MenortipoConsulta`, `MenorfinalidadConsulta`, `MenorcausaExternaConsulta`, `MenormotivoConsulta`, `MenorenfermedadActualConsulta`, `MenorantecedentesConsulta`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['MenornombreAcompana']."', '".$data['MenorAcompanaTelefono']."', '".$data['MenorparentezcoAcompana']."','".$data['Menornombremadre']."','".$data['Menornombrepadre']."', '".$data['MenortipoConsulta']."', '".$data['MenorfinalidadConsulta']."','".$data['MenorcausaExternaConsulta']."', '".$data['MenormotivoConsulta']."', '".$data['MenorenfermedadActualConsulta']."','".$data['MenorantecedentesConsulta']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasMenorB($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_menorB(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `profAtiende`, `Menorembarazodesado`, `MenoredadGestacional`, `Menorpatologiasembarazo`, `MenorPesonacer`, `Menortallanacer`, `MenorApgar1min`, `MenorApgar5min`, `MenorpatologiaReciennacido`, `MenorpartoIns`, `MenorProductoUnico`, `MenorTipoParto`, `MenorEdadMadreNacer`, `MenorAlimentacion`, `MenorOtrasleches`, `MenorComplementaria`, `MenorNumhermanos`, `MenorNumhermanosvivos`, `MenorNumhermanosMuertos`, `MenorPatologiasfamiliares`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['Menorembarazodesado']."', '".$data['MenoredadGestacional']."','".$data['Menorpatologiasembarazo']."', '".$data['MenorPesonacer']."', '".$data['Menortallanacer']."','".$data['MenorApgar1min']."', '".$data['MenorApgar5min']."', '".$data['MenorpatologiaReciennacido']."','".$data['MenorpartoIns']."', '".$data['MenorProductoUnico']."', '".$data['MenorTipoParto']."','".$data['MenorEdadMadreNacer']."', '".$data['MenorAlimentacion']."', '".$data['MenorOtrasleches']."','".$data['MenorComplementaria']."', '".$data['MenorNumhermanos']."', '".$data['MenorNumhermanosvivos']."','".$data['MenorNumhermanosMuertos']."', '".$data['MenorPatologiasfamiliares']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasMenorC($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_menorC(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `profAtiende`,  `MenortempEA`, `MenorpulsoEA`, `MenorpesoEA`, `MenortallaEA`, `MenorimcEA`, `MenorfrecuenciarEA`, `MenorPerimetroCefalico`, `Menorcabeza`, `Menorcabeza_Desc`, `MenorOjos`, `MenorOjos_Desc`, `MenorNariz`, `MenorNariz_Desc`, `MenorOidos`, `MenorOidos_Desc`, `MenorBoca`, `MenorBoca_Desc`, `Menorcuello`, `Menorcuello_Desc`, `MenorcardioRespirat`, `MenorcardioRespirat_Desc`, `Menorabdomen`, `Menorabdomen_Desc`, `Menorgenitourinario`, `Menorgenitourinario_Desc`, `MenorAno`, `MenorAno_Desc`, `MenorExtremidades`, `MenorExtremidades_Desc`, `Menorpiel`, `Menorpiel_Desc`, `Menorsistemanervioso`, `Menorsistemanervioso_Desc`, `MenordolorMascar`, `MenortraumaBoca`, `MenorLimpiamanana`, `MenorLimpiamedioDia`, `MenorLimpiaNoche`, `MenorLimpiaDientesSolo`, `MenorusaCepillo`, `MenorusaCrema`, `MenorusaSeda`, `MenorusaChupoB`, `MenorfechaUConsOdo`, `Menorpesoedad02`, `Menorpesoedad25`, `Menortallaedad018`, `Menorpesotalla018`, `Menorimc05`, `Menorimc518`, `MenorperimetroCefalicoEV`, `MenorTendenciaPeso`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['MenortempEA']."','".$data['MenorpulsoEA']."', '".$data['MenorpesoEA']."', '".$data['MenortallaEA']."','".$data['MenorimcEA']."', '".$data['MenorfrecuenciarEA']."', '".$data['MenorPerimetroCefalico']."','".$data['Menorcabeza']."', '".$data['Menorcabeza_Desc']."', '".$data['MenorOjos']."','".$data['MenorOjos_Desc']."', '".$data['MenorNariz']."', '".$data['MenorNariz_Desc']."', '".$data['MenorOidos']."','".$data['MenorOidos_Desc']."', '".$data['MenorBoca']."', '".$data['MenorBoca_Desc']."','".$data['Menorcuello']."', '".$data['Menorcuello_Desc']."', '".$data['MenorcardioRespirat']."','".$data['MenorcardioRespirat_Desc']."', '".$data['Menorabdomen']."', '".$data['Menorabdomen_Desc']."','".$data['Menorgenitourinario']."', '".$data['Menorgenitourinario_Desc']."', '".$data['MenorAno']."','".$data['MenorAno_Desc']."', '".$data['MenorExtremidades']."', '".$data['MenorExtremidades_Desc']."','".$data['Menorpiel']."', '".$data['Menorpiel_Desc']."', '".$data['Menorsistemanervioso']."','".$data['Menorsistemanervioso_Desc']."', '".$data['MenordolorMascar']."', '".$data['MenortraumaBoca']."','".$data['MenorLimpiamanana']."', '".$data['MenorLimpiamedioDia']."', '".$data['MenorLimpiaNoche']."','".$data['MenorLimpiaDientesSolo']."', '".$data['MenorusaCepillo']."', '".$data['MenorusaCrema']."','".$data['MenorusaSeda']."', '".$data['MenorusaChupoB']."', '".$data['MenorfechaUConsOdo']."','".$data['Menorpesoedad02']."', '".$data['Menorpesoedad25']."', '".$data['Menortallaedad018']."','".$data['Menorpesotalla018']."', '".$data['Menorimc05']."', '".$data['Menorimc518']."','".$data['MenorperimetroCefalicoEV']."', '".$data['MenorTendenciaPeso']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
   
    
    public function registrarConsultasMenorD($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_menorD(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `MenorHemoclasificacion`, `MenorSerologia`, `MenorHipotiroidismo`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['MenorHemoclasificacion']."','".$data['MenorSerologia']."', '".$data['MenorHipotiroidismo']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

    public function registrarConsultasMenorE($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_menorE(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `listadoCIEPa`,`tipoDiagnosPrinc`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."')";
        
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultasMenorF($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_menorF(  `idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `medAsigCons`, `notasEvolucion`, `recomNotas`, `OrdAsigCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['medAsigCons']."','".$data['notasEvolucion']."','".$data['recomNotas']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."')";
        
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
}

