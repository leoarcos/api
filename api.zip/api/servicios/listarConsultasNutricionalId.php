<?php

include_once '../DTO/consultasNutricional_DTO.php';





$inst = new consultasNutricional_DTO();

$dataOut= $inst->listarConsultasId($_POST['id']);




echo json_encode($dataOut);

?>