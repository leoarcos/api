<?php



include '../db/Database.php';



class consultas_DAO {



    function __construct() {

        

    }



  



    public function listarConsultas(){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT gr.* , pc.nombres, pc.papellido, pc.sapellido FROM consultas_generales gr, pacientes pc WHERE pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }
     public function listarConsultasId($id){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT gr.* , pc.* FROM consultas_generales gr, pacientes pc WHERE (pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac) AND id_consulta=".intVal($id)."";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }

    public function listarConsultasPaciente($tipoid, $numid){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT gr.* FROM general_consultation gr WHERE gr.tipoid_pac='".$tipoid."' AND gr.numid_pac='".$numid."'";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }

    

    public function registrarConsultas($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas(id_paciente, idJSON, fechaConsulta, profAtiende, tipoConsulta, finalidadConsulta, causaExternaConsulta, motivoConsulta, enfermedadActualConsulta, antecedentesConsulta, tempEA, pulsoEA, pesoEA, tallaEA, imcEA, frecuenciarEA, tensionaEA, obserConsuAdulto, listadoCIEPa, tipoDiagnosPrinc, medAsigCons, OrdAsigCons, ordenMedConsRef, ordenMedConsRefPro, tipoSerRef, obseSerRef, tipoIDUserReg, numeroIDUserReg, tipoid_pac, numid_pac) VALUES (".$data['id_paciente'].",'".$data['idJSON']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['tipoConsulta']."','".$data['finalidadConsulta']."','".$data['causaExternaConsulta']."','".$data['motivoConsulta']."','".$data['enfermedadActualConsulta']."','".$data['antecedentesConsulta']."','".$data['tempEA']."','".$data['pulsoEA']."','".$data['pesoEA']."','".$data['tallaEA']."','".$data['imcEA']."','".$data['frecuenciarEA']."','".$data['tensionaEA']."','".$data['obserConsuAdulto']."','".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."', '".$data['medAsigCons']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."','".$data['tipoIDUserReg']."','".$data['numeroIDUserReg']."','".$data['tipoid_pac']."','".$data['numid_pac']."')";

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

    public function registerGeneralConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        $data2=JSON_decode($data['data'], true);
       
        //$sql="INSERT INTO consultas_generales(data, id_paciente, idJSON_paciente, numid_pac, tipoid_pac, institucion) VALUES ('".$data['data']."','".$data['id_paciente']."','".$data['idJSON_paciente']."','".$data['numid_pac']."','".$data['tipoid_pac']."','".$data['institucion']."')";
        $sql="INSERT INTO `consultas_generales`( `idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `tipoIDUserReg`, `numeroIDUserReg`, `institucion`, `id_registra`, `tipoid_registra`, `fechaConsulta`, `horaConsulta`, `profAtiende`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `antecedentesConsulta`, `tempEA`, `pulsoEA`, `pesoEA`, `tallaEA`, `imcEA`, `frecuenciarEA`, `tensionaEA`, `obserConsuAdulto`, `listadoCIEPa`, `tipoDiagnosPrinc`, `medAsigCons`, `ordenMedCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `notasEvolucion`, `recomNotas`, `IpsServicioReferir`, `IpsProcedeimientoReferir`, `estado`) VALUES ('".$data2['idJSON_consulta']."','".$data2['id_paciente']."','".$data2['idJSON_paciente']."','".$data2['numid_pac']."','".$data2['tipoid_pac']."','".$data2['tipoIDUserReg']."','".$data2['numeroIDUserReg']."','".$data2['institucion']."','".$data2['id_registra']."','".$data2['tipoid_registra']."','".$data2['fechaConsulta']."','".$data2['horaConsulta']."','".$data2['profAtiende']."','".$data2['tipoConsulta']."','".$data2['finalidadConsulta']."','".$data2['causaExternaConsulta']."','".$data2['motivoConsulta']."','".$data2['enfermedadActualConsulta']."','".$data2['antecedentesConsulta']."','".$data2['tempEA']."','".$data2['pulsoEA']."','".$data2['pesoEA']."','".$data2['tallaEA']."','".$data2['imcEA']."','".$data2['frecuenciarEA']."','".$data2['tensionaEA']."','".$data2['obserConsuAdulto']."','".$data2['listadoCIEPa']."','".$data2['tipoDiagnosPrinc']."','".$data2['medAsigCons']."','".$data2['ordenMedCons']."','".$data2['ordenMedConsRef']."','".$data2['ordenMedConsRefPro']."','".$data2['tipoSerRef']."','".$data2['obseSerRef']."','".$data2['notasEvolucion']."','".$data2['recomNotas']."','".$data2['IpsServicioReferir']."','".$data2['IpsProcedeimientoReferir']."','".$data2['estado']."')";
        
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updateGeneralConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }
        $data2=JSON_decode($data['data'], true);


        //$sql="UPDATE general_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);
        $sql="UPDATE `consultas_generales` SET `tempEA`='".$data2['tempEA']."',`pulsoEA`='".$data2['pulsoEA']."',`pesoEA`='".$data2['pesoEA']."',`tallaEA`='".$data2['tallaEA']."',`imcEA`='".$data2['imcEA']."',`frecuenciarEA`='".$data2['frecuenciarEA']."',`tensionaEA`='".$data2['tensionaEA']."',`obserConsuAdulto`='".$data2['obserConsuAdulto']."',`notasEvolucion`='".$data2['notasEvolucion']."',`recomNotas`='".$data2['recomNotas']."',`estadoSubDos`='".$data2['estadoSubDos']."' WHERE `id_consulta`='".$data['iddb']."'";
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updateGeneralConsultationCIE($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }
        $data2=JSON_decode($data['data'], true);


        //$sql="UPDATE general_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);
        $sql="UPDATE `consultas_generales` SET `listadoCIEPa`='".$data2['listadoCIEPa']."',`tipoDiagnosPrinc`='".$data2['tipoDiagnosPrinc']."' WHERE `id_consulta`='".$data['iddb']."'";
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updateGeneralConsultationPlan($data){  
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }
        $data2=JSON_decode($data['data'], true);


        //$sql="UPDATE general_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);
        $sql="UPDATE `consultas_generales` SET `medAsigCons`='".$data2['medAsigCons']."',`ordenMedCons`='".$data2['ordenMedCons']."',`ordenMedConsRef`='".$data2['ordenMedConsRef']."',`ordenMedConsRefPro`='".$data2['ordenMedConsRefPro']."',`tipoSerRef`='".$data2['tipoSerRef']."',`obseSerRef`='".$data2['obseSerRef']."',`IpsServicioReferir`='".$data2['IpsServicioReferir']."',`IpsProcedeimientoReferir`='".$data2['IpsProcedeimientoReferir']."',`estadoSubCuatro`='".$data2['estadoSubCuatro']."' WHERE `id_consulta`='".$data['iddb']."'";
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updateGeneralConsultationIdPaciente($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE general_consultation SET id_paciente='".$data['id_paciente']."' WHERE id=".intVal($data['iddb']);

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaGeneral($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }


        $sqlF="INSERT INTO `consulta_general`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `profAtiende`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `antecedentesConsulta`) VALUES ('".$data['idJSON_consulta']."', '".$data['id_paciente']."', '".$data['idJSON_paciente']."', '".$data['numid_pac']."', '".$data['tipoid_pac']."', '".$data['id_registra']."', '".$data['tipoid_registra']."', '".$data['institucion']."', '".$data['fechaConsulta']."', '".$data['profAtiende']."', '".$data['tipoConsulta']."', '".$data['finalidadConsulta']."', '".$data['causaExternaConsulta']."', '".$data['motivoConsulta']."', '".$data['enfermedadActualConsulta']."', '".$data['antecedentesConsulta']."')";
        //$sql="INSERT INTO `consultas_generales`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `fecha`, `id_registra`, `tipoid_registra`, `institucion`) VALUES ('".$data['idJSON_consulta']."', '".$data['id_paciente']."', '".$data['idJSON_paciente']."', '".$data['numid_pac']."', '".$data['tipoid_pac']."', '".$data['fecha']."', '".$data['id_registra']."', '".$data['tipoid_registra']."', '".$data['institucion']."')";
        
        $result = array();

        $res = $instance->exec($sqlF);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaGeneralA($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }


        $sql="INSERT INTO consultas_generalesA(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `profAtiende`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `antecedentesConsulta`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['tipoConsulta']."','".$data['finalidadConsulta']."','".$data['causaExternaConsulta']."','".$data['motivoConsulta']."','".$data['enfermedadActualConsulta']."','".$data['antecedentesConsulta']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaGeneralB($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        $sqlF="UPDATE `consulta_general` SET `tempEA`='".$data['tempEA']."',`pulsoEA`='".$data['pulsoEA']."',`pesoEA`='".$data['pesoEA']."',`tallaEA`='".$data['tallaEA']."',`imcEA`='".$data['imcEA']."',`frecuenciarEA`='".$data['frecuenciarEA']."',`tensionaEA`='".$data['tensionaEA']."',`obserConsuAdulto`='".$data['obserConsuAdulto ']."' WHERE `id_consulta`=".intVal($data['id_consulta'])." AND `idJSON_consulta`=".intVal($data['idJSON_consulta'])."";
        $sql="INSERT INTO consultas_generalesB(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `tempEA`, `pulsoEA`, `pesoEA`, `tallaEA`, `imcEA`, `frecuenciarEA`, `tensionaEA`, `obserConsuAdulto`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['tempEA']."','".$data['pulsoEA']."','".$data['pesoEA']."','".$data['tallaEA']."','".$data['imcEA']."','".$data['frecuenciarEA']."','".$data['tensionaEA']."','".$data['obserConsuAdulto']."')";
        
        $result = array();

        $res = $instance->exec($sqlF);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

             

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaGeneralC($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }

        $sqlF="UPDATE `consulta_general` SET `listadoCIEPa`='".$data['listadoCIEPa']."',`tipoDiagnosPrinc`='".$data['tipoDiagnosPrinc']."' WHERE `id_consulta`=".intVal($data['id_consulta'])." AND `idJSON_consulta`=".intVal($data['idJSON_consulta'])."";
        
        $sql="INSERT INTO consultas_generalesC(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `listadoCIEPa`,`tipoDiagnosPrinc`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."')";
       
        $result = array();

        $res = $instance->exec($sqlF);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            
 

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaGeneralD($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }
        $sqlF="UPDATE `consulta_general` SET `medAsigCons`='".$data['medAsigCons']."',`OrdAsigCons`='".$data['OrdAsigCons']."',`ordenMedConsRef`='".$data['ordenMedConsRef']."',`ordenMedConsRefPro`='".$data['ordenMedConsRefPro']."',`tipoSerRef`='".$data['tipoSerRef']."',`obseSerRef`='".$data['obseSerRef']."',`notasEvolucion`='".$data['notasEvolucion']."',`recomNotas`='".$data['recomNotas']."' WHERE `id_consulta`=".intVal($data['id_consulta'])." AND `idJSON_consulta`=".intVal($data['idJSON_consulta'])."";

        $sql="INSERT INTO consultas_generalesD( `idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `medAsigCons`, `OrdAsigCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `notasEvolucion`, `recomNotas`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['medAsigCons']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."','".$data['notasEvolucion']."','".$data['recomNotas']."')";
 
        $result = array();

        $res = $instance->exec($sqlF);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            
 

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }




   

}

