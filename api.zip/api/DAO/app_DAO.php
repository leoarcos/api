<?php

include '../db/Database.php';

class app_DAO {

    function __construct() {
        
    }

  

    public function listarMunicipios(){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }

        $sqlLogIn = "SELECT mnp.* FROM municipios mnp";
        $result = array();
        $res = $instance->get_data($sqlLogIn);
        if ($res['DATA'] ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['STATUS'] = 'ERROR';
        }
        return $result;
        

    }
    public function validarNick($nick){
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }

        $sqlLogIn = "SELECT nick_user from usuarios WHERE nick_user='$nick'";
        $result = array();
        $res = $instance->get_data($sqlLogIn);
        if ($res['DATA'] ) {
           
            $result['DATA'] = $res['DATA'];

            $result['STATUS'] = 'OK';
        } else {
            $result['DATA']='ERROR';
            $result['STATUS'] = 'ERROR';
        }
        return $result;
        

    }
   
}
