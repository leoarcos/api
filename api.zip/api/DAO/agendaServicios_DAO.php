<?php

include '../db/Database.php';

class agendaServicios_DAO {

    function __construct() {
        
    }
 
    
    public function registrarAgendaServicio($data){
         
        
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
 
        $sql="INSERT INTO `admisiones`(`AgendarID`, `AgendarIDJSON`, `AgendartipoidRegPacAdmision`, `AgendaridRegPacAdmision`, `AgendarotroDocumRepAdmision`, `AgendarSexo`, `AgendarNombresAdmision`, `AgendarpprofeAgendarAdmision`, `AgendarServicioAdmision`, `AgendarFechaAgendarAdmision`, `AgendarHoraAgendarAdmision`, `usuarioregistraID`, `usuarioregistratipoID`, `fechaReg`, `estado`) VALUES ('".$data['AgendarID']."','".$data['AgendarIDJSON']."','".$data['AgendartipoidRegPacAdmision']."','".$data['AgendaridRegPacAdmision']."','".$data['AgendarotroDocumRepAdmision']."','".$data['AgendarSexo']."','".$data['AgendarNombresAdmision']."','".$data['AgendarpprofeAgendarAdmision']."','".$data['AgendarServicioAdmision']."','".$data['AgendarFechaAgendarAdmision']."', '".$data['AgendarHoraAgendarAdmision']."','".$data['usuarioregistraID']."','".$data['usuarioregistratipoID']."','".$data['fechaReg']."', 0)"; 
         
        $result = array();
        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    } 
   
    public function buscarAdmisionesDiaPaciente($data){
         
        
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
 
        $sql="SELECT COUNT(*) as cont FROM admisiones WHERE AgendarFechaAgendarAdmision='".$data['AgendarFechaAgendarAdmision']."' and AgendarID='".$data['AgendarID']."' and AgendarIDJSON='".$data['AgendarIDJSON']."' and AgendartipoidRegPacAdmision='".$data['AgendartipoidRegPacAdmision']."' and AgendaridRegPacAdmision='".$data['AgendaridRegPacAdmision']."'"; 
         
        $result = array();
        $res = $instance->get_data($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['DATA'] = $res['DATA'];
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    } 
    public function consultarAgendaProfesional($data){
         
        
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
 
        $sql="SELECT COUNT(*) as cont FROM `admisiones` WHERE `estado`=0 AND`AgendarpprofeAgendarAdmision`='".$data['AgendarpprofeAgendarAdmision']."' AND `AgendarFechaAgendarAdmision`='".$data['AgendarFechaAgendarAdmision']."' AND `AgendarHoraAgendarAdmision` BETWEEN '".$data['time1']."' AND '".$data['time2']."'";
        $result = array();
        $res = $instance->get_data($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['DATA'] = $res['DATA'];
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    } 
    public function listarAgendaProfesionalID($data){
         
        
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
 
        $sql="SELECT ad.*, usr.nombres FROM admisiones ad, usuarios usr WHERE usr.numid=ad.AgendarpprofeAgendarAdmision AND ad.AgendarpprofeAgendarAdmision='".$data['id']."' AND ad.estado=0 ORDER BY ad.AgendarFechaAgendarAdmision ASC, ad.AgendarHoraAgendarAdmision ASC";
        $result = array();
        $res = $instance->get_data($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['DATA'] = $res['DATA'];
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    } 
    public function listarAgendaInstituto($data){
         
        
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
 
        $sql="SELECT ad.*, usr.nombres FROM admisiones ad, usuarios usr WHERE usr.numid=ad.AgendarpprofeAgendarAdmision AND ad.estado=0 ORDER BY ad.AgendarFechaAgendarAdmision ASC, ad.AgendarHoraAgendarAdmision ASC";
        $result = array();
        $res = $instance->get_data($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';
            $result['DATA'] = $res['DATA'];
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    } 
    public function actualizarEstadoAdmision($data){
         
        
        $instance = Database::getInstance();
        if ($instance == NULL) {
            $db = new Database();
            $instance = $db->getInstance();
        }
 
        $sql="UPDATE `admisiones` SET `estado`=".$data['estado']." WHERE id=".$data['id']."";
        $result = array();
        $res = $instance->exec($sql); 
        if ($res['STATUS']=='OK' ) {
            
            $result['STATUS'] = 'OK';  
        } else { 
            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];
            
        }
        return $result;
        

    } 
   
   
}
