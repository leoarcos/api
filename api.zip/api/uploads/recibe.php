<?php

 
$rutaArchivo=$_POST['id_paciente']."-".$_POST['nombreaFile'].".pdf";

if (move_uploaded_file($_FILES["myfile"]['tmp_name'], $rutaArchivo)){ 
    //ya se cargo, se procede a ingresar a la base de datos
    require_once("../db/Database.php");
    
    $inst=new Database();
    $sql="INSERT INTO `filesupload`(`id_paciente`, `file`, `nombre`, `doc_user_sube`) VALUES (".intval($_POST['id_paciente']).",  '".$rutaArchivo."', '".$_POST['nombreaFile']."', ".intval($_POST['doc_user_sube']).")";
    $data=$inst->exec($sql);
    echo JSON_encode($data);
    
    
    
    
    
}else{
    $data['ERROR']="Ocurrio algun error al subir el fichero {$nombre_archivo}. No pudo guardarse.";
    $data['STATUS']="ERROR";
    echo JSON_encode($data);
    //$errors[] = "Ocurrio algun error al subir el fichero {$nombre_archivo}. No pudo guardarse.";
}
/*
if(count($errors) > 0) {
 showErrors($errors);
}
*/
?>