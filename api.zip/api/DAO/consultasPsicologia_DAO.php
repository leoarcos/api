<?php



include '../db/Database.php';



class consultasPsicologia_DAO {



    function __construct() {

        

    }



    public function registerPsicoConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $data2=JSON_decode($data['data'], true);
       
        
        $sql="INSERT INTO `consultas_psicologia`( `idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `tipoIDUserReg`, `numeroIDUserReg`, `institucion`, `id_registra`, `tipoid_registra`, `fechaConsulta`, `horaConsulta`, `profAtiende`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `antecedentesConsulta`, `tempEA`, `pulsoEA`, `pesoEA`, `tallaEA`, `imcEA`, `frecuenciarEA`, `tensionaEA`, `obserConsuAdulto`, `listadoCIEPa`, `tipoDiagnosPrinc`, `medAsigCons`, `ordenMedCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`, `notasEvolucion`, `recomNotas`, `IpsServicioReferir`, `IpsProcedeimientoReferir`, `estado`) VALUES ('".$data2['idJSON_consulta']."','".$data2['id_paciente']."','".$data2['idJSON_paciente']."','".$data2['numid_pac']."','".$data2['tipoid_pac']."','".$data2['tipoIDUserReg']."','".$data2['numeroIDUserReg']."','".$data2['institucion']."','".$data2['id_registra']."','".$data2['tipoid_registra']."','".$data2['fechaConsulta']."','".$data2['horaConsulta']."','".$data2['profAtiende']."','".$data2['tipoConsulta']."','".$data2['finalidadConsulta']."','".$data2['causaExternaConsulta']."','".$data2['motivoConsulta']."','".$data2['enfermedadActualConsulta']."','".$data2['antecedentesConsulta']."','".$data2['tempEA']."','".$data2['pulsoEA']."','".$data2['pesoEA']."','".$data2['tallaEA']."','".$data2['imcEA']."','".$data2['frecuenciarEA']."','".$data2['tensionaEA']."','".$data2['obserConsuAdulto']."','".$data2['listadoCIEPa']."','".$data2['tipoDiagnosPrinc']."','".$data2['medAsigCons']."','".$data2['ordenMedCons']."','".$data2['ordenMedConsRef']."','".$data2['ordenMedConsRefPro']."','".$data2['tipoSerRef']."','".$data2['obseSerRef']."','".$data2['notasEvolucion']."','".$data2['recomNotas']."','".$data2['IpsServicioReferir']."','".$data2['IpsProcedeimientoReferir']."','".$data2['estado']."')";

        //$sql="INSERT INTO psico_consultation(data, id_paciente, idJSON_paciente, numid_pac, tipoid_pac, institucion) VALUES ('".$data['data']."','".$data['id_paciente']."','".$data['idJSON_paciente']."','".$data['numid_pac']."','".$data['tipoid_pac']."','".$data['institucion']."')";

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updatePsicoConsultation($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $data2=JSON_decode($data['data'], true);


        //$sql="UPDATE general_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);
        $sql="UPDATE `consultas_psicologia` SET `tempEA`='".$data2['tempEA']."',`pulsoEA`='".$data2['pulsoEA']."',`pesoEA`='".$data2['pesoEA']."',`tallaEA`='".$data2['tallaEA']."',`imcEA`='".$data2['imcEA']."',`frecuenciarEA`='".$data2['frecuenciarEA']."',`tensionaEA`='".$data2['tensionaEA']."',`obserConsuAdulto`='".$data2['obserConsuAdulto']."',`notasEvolucion`='".$data2['notasEvolucion']."',`recomNotas`='".$data2['recomNotas']."',`estadoSubDos`='".$data2['estadoSubDos']."' WHERE `id_consulta`='".$data['iddb']."'";
        //$sql="UPDATE psico_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updatePsicoConsultationCIE($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }


        $data2=JSON_decode($data['data'], true);


        //$sql="UPDATE general_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);
        $sql="UPDATE `consultas_psicologia` SET `listadoCIEPa`='".$data2['listadoCIEPa']."',`tipoDiagnosPrinc`='".$data2['tipoDiagnosPrinc']."' WHERE `id_consulta`='".$data['iddb']."'";
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function updatePsicoConsultationPlan($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $data2=JSON_decode($data['data'], true);


        //$sql="UPDATE general_consultation SET data='".$data['data']."' WHERE id=".intVal($data['iddb']);
        $sql="UPDATE `consultas_psicologia` SET `medAsigCons`='".$data2['medAsigCons']."',`ordenMedCons`='".$data2['ordenMedCons']."',`ordenMedConsRef`='".$data2['ordenMedConsRef']."',`ordenMedConsRefPro`='".$data2['ordenMedConsRefPro']."',`tipoSerRef`='".$data2['tipoSerRef']."',`obseSerRef`='".$data2['obseSerRef']."',`IpsServicioReferir`='".$data2['IpsServicioReferir']."',`IpsProcedeimientoReferir`='".$data2['IpsProcedeimientoReferir']."',`estadoSubCuatro`='".$data2['estadoSubCuatro']."' WHERE `id_consulta`='".$data['iddb']."'";
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
  


    public function updatePsicoConsultationIdPaciente($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="UPDATE psico_consultation SET id_paciente='".$data['id_paciente']."' WHERE id=".intVal($data['iddb']);

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

    public function listarConsultas(){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        $sql = "SELECT gr.* , pc.nombres, pc.papellido, pc.sapellido FROM consultas_psicologia gr, pacientes pc WHERE pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac";
        //$sql = "SELECT * FROM consultasPsicologia";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }

    public function listarConsultasId($id){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        
        $sql = "SELECT gr.* , pc.* FROM consultas_psicologia gr, pacientes pc WHERE (pc.idRegPac=gr.numid_pac AND pc.tipoidRegPac=gr.tipoid_pac) AND id_consulta=".intVal($id)."";
        //$sql = "SELECT * FROM consultasEnfermeria";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }

    public function listarConsultasPaciente($tipoid, $numid ){

        $instance = Database::getInstance();

        if ($instance == NULL) {

            $db = new Database();
            $instance = $db->getInstance();

        }
        $sql = "SELECT gr.* FROM psico_consultation gr WHERE gr.tipoid_pac='".$tipoid."' AND gr.numid_pac='".$numid."'";

        //$sql = "SELECT * FROM consultasPsicologia";

        $result = array();
        $res = $instance->get_data($sql);
        
        if ($res['STATUS']=='OK' ) {
            
            $result['DATA'] = $res['DATA'];
             $result['STATUS'] = 'OK';

        } else {

            $result['STATUS'] = 'ERROR';
            $result['ERROR'] = $res['ERROR'];

        }

        return $result;
    }

    

    public function registrarConsultas($data){ 
        
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultasPsicologia(id_paciente, idJSON, fechaConsulta, profAtiende, tipoConsulta, finalidadConsulta, causaExternaConsulta, motivoConsulta, enfermedadActualConsulta, antecedentesConsulta, tempEA, pulsoEA, pesoEA, tallaEA, imcEA, frecuenciarEA, tensionaEA, obserConsuAdulto, listadoCIEPa, tipoDiagnosPrinc, medAsigCons, OrdAsigCons, ordenMedConsRef, ordenMedConsRefPro, tipoSerRef, obseSerRef, tipoIDUserReg, numeroIDUserReg, tipoid_pac, numid_pac, notasEvolucion, recomNotas) VALUES (".$data['id_paciente'].",'".$data['idJSON']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['tipoConsulta']."','".$data['finalidadConsulta']."','".$data['causaExternaConsulta']."','".$data['motivoConsulta']."','".$data['enfermedadActualConsulta']."','".$data['antecedentesConsulta']."','".$data['tempEA']."','".$data['pulsoEA']."','".$data['pesoEA']."','".$data['tallaEA']."','".$data['imcEA']."','".$data['frecuenciarEA']."','".$data['tensionaEA']."','".$data['obserConsuAdulto']."','".$data['listadoCIEPa']."','".$data['tipoDiagnosPrinc']."','".$data['medAsigCons']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."','".$data['tipoIDUserReg']."','".$data['numeroIDUserReg']."','".$data['tipoid_pac']."','".$data['numid_pac']."','".$data['notasEvolucion']."','".$data['recomNotas']."')";

        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }


    public function registrarConsultaPsicologia($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO `consultas_psicologia`(`idJSON_consulta`, `id_paciente`, `idJSON_paciente`, `numid_pac`, `tipoid_pac`, `fecha`, `id_registra`, `tipoid_registra`, `institucion`) VALUES ('".$data['idJSON_consulta']."', '".$data['id_paciente']."', '".$data['idJSON_paciente']."', '".$data['numid_pac']."', '".$data['tipoid_pac']."', '".$data['fecha']."', '".$data['id_registra']."', '".$data['tipoid_registra']."', '".$data['institucion']."')";
    
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaPsicologiaA($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_psicologiaA(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`,  `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `profAtiende`, `tipoConsulta`, `finalidadConsulta`, `causaExternaConsulta`, `motivoConsulta`, `enfermedadActualConsulta`, `antecedentesConsulta`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['profAtiende']."','".$data['tipoConsulta']."','".$data['finalidadConsulta']."','".$data['causaExternaConsulta']."','".$data['motivoConsulta']."','".$data['enfermedadActualConsulta']."','".$data['antecedentesConsulta']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

    public function registrarConsultaPsicologiaB($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_psicologiaB(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `tempEA`, `pulsoEA`, `pesoEA`, `tallaEA`, `imcEA`, `frecuenciarEA`, `tensionaEA`, `obserConsuAdulto`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['tempEA']."','".$data['pulsoEA']."','".$data['pesoEA']."','".$data['tallaEA']."','".$data['imcEA']."','".$data['frecuenciarEA']."','".$data['tensionaEA']."','".$data['obserConsuAdulto']."')";
 
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaPsicologiaC($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_psicologiaC(`idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `listadoCIEPa`,`tipoDiagnosPrinc`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['listadoCIEPa']."', '".$data['tipoDiagnosPrinc']."')";
        
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }
    public function registrarConsultaPsicologiaD($data){ 
        $instance = Database::getInstance();

        

        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();

        }



        $sql="INSERT INTO consultas_psicologiaD(  `idJSON_consulta`, `id_generalA`, `id_generalAJSON`, `id_registra`, `tipoid_registra`, `institucion`, `fechaConsulta`, `medAsigCons`, `notasEvolucion`, `recomNotas`, `OrdAsigCons`, `ordenMedConsRef`, `ordenMedConsRefPro`, `tipoSerRef`, `obseSerRef`) VALUES (".$data['idJSON_consulta'].",'".$data['id_generalA']."','".$data['id_generalAJSON']."','".$data['numeroIDUserReg']."','".$data['tipoIDUserReg']."','".$data['insitucion']."','".$data['fechaConsulta']."','".$data['medAsigCons']."','".$data['notasEvolucion']."','".$data['recomNotas']."','".$data['ordenMedCons']."','".$data['ordenMedConsRef']."','".$data['ordenMedConsRefPro']."','".$data['tipoSerRef']."','".$data['obseSerRef']."')";
        
        $result = array();

        $res = $instance->exec($sql);

        if ($res['STATUS']=='OK' ) {

            

            $result['STATUS'] = 'OK';

            

            $result['ID'] = $res['ID'];

        } else { 

            $result['STATUS'] = 'ERROR';

        }

        return $result;

        



    }

   

}

