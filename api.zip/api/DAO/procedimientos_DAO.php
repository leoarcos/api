<?php



include '../db/Database.php';



class procedimientos_DAO {



    function __construct() {


    }

    public function listarProcedimientos(){

        $instance = Database::getInstance();


        if ($instance == NULL) {



            $db = new Database();

            $instance = $db->getInstance();



        }

        

        $sql = "SELECT * FROM procedimientos";



        $result = array();

        $res = $instance->get_data($sql);

        

        if ($res['STATUS']=='OK' ) {

            

            $result['DATA'] = $res['DATA'];

             $result['STATUS'] = 'OK';



        } else {



            $result['STATUS'] = 'ERROR';

            $result['ERROR'] = $res['ERROR'];



        }



        return $result;

    }



    



    public function registrarProcedimientos($data){ 

        
        $instance = Database::getInstance();
        if ($instance == NULL) {

            $db = new Database();

            $instance = $db->getInstance();



        }


        $sql="INSERT INTO procedimientos( `idJSON_procedimiento`, `fechaProce`, `horaProce`, `nombrPacienteAte`, `tipodocupacie`, `numDocpPaci`, `sexoPAciees`, `cieIngCon`, `cieIngConComp`, `AmbreaProc`, `FinaProc`, `perfilPersonat`, `nombrePersonAtien`, `formReaAcQ`, `ordenesIngCon`) VALUES (".$data['idJSON_procedimiento'].", '".$data['fechaProce']."','".$data['horaProce']."','".$data['nombrPacienteAte']."','".$data['tipodocupacie']."','".$data['numDocpPaci']."','".$data['sexoPAciees']."','".$data['cieIngCon']."','".$data['cieIngConComp']."','".$data['AmbreaProc']."','".$data['FinaProc']."','".$data['perfilPersonat']."','".$data['nombrePersonAtien']."','".$data['formReaAcQ']."','".$data['ordenesIngCon']."')";



        $result = array();



        $res = $instance->exec($sql);



        if ($res['STATUS']=='OK' ) {

            $result['STATUS'] = 'OK';
            $result['ID'] = $res['ID'];
        } else { 

            $result['STATUS'] = 'ERROR';
            $result['sql'] = $sql;

        }



        return $result;



        





    }

}